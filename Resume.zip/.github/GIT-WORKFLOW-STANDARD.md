# StateAuto XCAM Git Workflow Standard

**Jira Reference:** RTWC-2319  
**Effective Date:** 2026-07-28  
**Status:** Approved  

---

## Overview

This document standardizes the Git workflow for the StateAuto XCAM repository to ensure code quality, enforce approvals, and maintain release safety.

## 1. Feature Branch Naming Convention

All feature branches **must** use the Jira ticket number as the branch name.

### Pattern
```
RTWC-XXXX
```

### Example
```bash
# Create from the default integration branch
git fetch origin dev
git checkout -b RTWC-2319 origin/dev
```

**Why:** Automatic traceability between branch and Jira ticket; easy to identify scope and ownership.

---

## 2. Pull Request (PR) Checklist

Every PR submitted to the repository **must** include the following checklist in the description:

### Required Checklist Items

- [ ] Jira ticket linked (e.g., RTWC-2319 in title or description)
- [ ] Scope is review-ready: it follows XCAM conventions and contains no debug code, WIP markers, secrets, or sensitive data
- [ ] Tests and documentation were updated, or their omission is explained
- [ ] Machine readiness, build, test, and applicable functional validation are checked; any failure is classified as baseline or net-new

**PR Template:** This checklist is enforced via `.github/pull_request_template.md` and displayed automatically in every PR.

---

## 3. Branch Protection Rules

### Protected Branches

**Branch:** `dev`

### Required Settings

| Setting | Value |
|---------|-------|
| Require pull request reviews before merging | ✅ Yes |
| Minimum reviewers | **1** |
| Require status checks to pass before merging | ✅ Yes |
| Require branches to be up to date before merging | ✅ Yes |
| Require code reviews from designated reviewers only | ✅ Yes |
| Restrict who can dismiss reviews | ✅ Admins only |
| Allow force pushes | ❌ No |
| Allow deletions | ❌ No |

---

## 4. Approval Workflow

### Authorized Reviewers (Approvers)

Only the following users **can approve** pull requests for merge:

1. **Sharanya Marupakala** — `sharanya.marupakala@libertymutual.com`
2. **Girjesh Kumar Vishwakarma** — `girjeshkumar.vishwakarma01@libertymutual.com`

### Approval Rules

- **Minimum 1 approval required** before merge is allowed
- **Author cannot self-approve** their own PR (GitHub enforces this automatically)
- **All status checks must pass:**
  - Build succeeds
  - All tests pass
  - Code quality checks pass (if configured)
- **Branch must be up-to-date** with `dev` before merge

### Workflow

```
1. Author creates feature branch from `dev` (e.g., RTWC-2319 from `dev`)
2. Author writes code + tests and pushes to GitHub
3. Author opens PR to `dev` with completed checklist
4. GitHub requires minimum 1 approval from authorized reviewers
5. Designated reviewer reviews + approves
6. Author merges (only after approval granted)
7. Feature branch auto-deletes after merge
```

---

## 5. Code Owners

**File:** `.github/CODEOWNERS`

Code owners are automatically assigned as reviewers for PRs touching their components.

### Current Code Owners

| Component | Owners |
|-----------|--------|
| `XCAM.Core/` | Sharanya Marupakala, Girjesh Kumar Vishwakarma |
| `XCAM.Services/` | Sharanya Marupakala, Girjesh Kumar Vishwakarma |
| `XCAM.UI/` | Sharanya Marupakala, Girjesh Kumar Vishwakarma |
| `XCAM.Test/` | Sharanya Marupakala, Girjesh Kumar Vishwakarma |
| `XCAM.Installer/` | Sharanya Marupakala, Girjesh Kumar Vishwakarma |
| `.github/` | Sharanya Marupakala |

---

## 6. Local Development Workflow

### Step-by-Step

#### 1. Create Feature Branch from dev (example)

```bash
# Update local repo
git fetch origin dev

# Create feature branch
git checkout -b RTWC-2319 origin/dev

# Verify branch
git branch --show-current
# Output: RTWC-2319
```

#### 2. Make Changes + Commit

```bash
# Edit files
# ... make your changes ...

# Add + commit
git add .
git commit -m "feat: implement policy detail form (RTWC-2319)"

# Verify status
git status
# Output: On branch RTWC-2319, nothing to commit
```

#### 3. Run Tests Locally

```bash
# Build solution
msbuild XCAM.sln /t:Build /p:Configuration=Debug

# Run tests
dotnet test XCAM.Test/XCAM.Test.csproj

# Expected: All tests pass
```

#### 4. Push to GitHub

```bash
# Push feature branch
git push origin RTWC-2319

# GitHub URL: https://github.ent.stateauto.com/StateAuto/rtw-xcam/tree/RTWC-2319
```

#### 5. Create Pull Request

- **Base branch:** `dev`
- **Compare branch:** `RTWC-2319`
- **Title:** Describe the work (e.g., "Implement policy detail form")
- **Description:** 
  - Include the PR checklist (pre-filled by template)
  - Link Jira ticket (e.g., "Resolves RTWC-2319")
  - Add notes for reviewers if needed

#### 6. Wait for Approval

- GitHub notifies designated reviewers
- Reviewer checks code, tests, build
- Reviewer approves or requests changes
- **Do not merge until approval is granted**

#### 7. Merge to dev

Once approved:

```bash
# Option A: Merge via GitHub Web UI (recommended)
# Click "Merge pull request" button

# Option B: Merge via CLI
git checkout dev
git pull origin dev
git merge --no-ff RTWC-2319
git push origin dev

# GitHub auto-deletes the feature branch
# Local cleanup
git branch -d RTWC-2319
```

---

## 7. Validation Checklist

After branch protection rules are configured, validate the workflow:

- [ ] Create a test PR targeting `dev` from a feature branch
- [ ] Verify the PR template checklist is pre-filled
- [ ] Verify only authorized reviewers appear in the "Request reviewers" list
- [ ] Verify "Merge" button is disabled without approval
- [ ] Add a designated reviewer's approval
- [ ] Verify "Merge" button becomes enabled
- [ ] Attempt to self-approve as author (should fail)
- [ ] Verify "Merge" button becomes enabled only after non-author approval
- [ ] Complete merge and verify auto-cleanup of feature branch
- [ ] Verify build + tests are required before merge (if status checks configured)

---

## 8. Troubleshooting

### "Merge" button is disabled even after approval
- **Cause:** Build or tests are failing
- **Fix:** Push new commits to fix build/tests; approval persists
- **Note:** Status checks must all pass before merge allowed

### Can't see feature branch in PR dropdown
- **Cause:** Branch not yet pushed to GitHub
- **Fix:** Run `git push origin RTWC-XXXX` and refresh page

### Author accidentally approved own PR
- **Cause:** Shouldn't happen; GitHub should prevent this
- **Fix:** Ask designated reviewer to dismiss review and re-approve

### Feature branch not deleted after merge
- **Cause:** Auto-delete not enabled in branch protection settings
- **Fix:** Manually delete: `git branch -d RTWC-XXXX`

---

## 9. Exceptions and Escalations

### Hotfixes to main

If an urgent fix is needed for `main`:

1. Still follow the PR checklist
2. Still require 1 approval from authorized reviewers
3. Link to a Jira ticket (create one if needed, e.g., RTWC-HOT-001)
4. Mark as **"[HOTFIX]"** in PR title

### Bypass Approval (Admin Only)

Only repo admins can bypass branch protection. Use sparingly and document in Jira.

---

## 10. References

- **GitHub Branch Protection Docs:** https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches/about-protected-branches
- **CODEOWNERS Docs:** https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-code-owners
- **XCAM Jira Project:** https://stateautoinsurance.atlassian.net/browse/RTWC-2319
- **XCAM Copilot Instructions:** `.github/copilot-instructions.md`

---

## 11. Version History

| Date | Author | Change |
|------|--------|--------|
| 2026-07-28 | Sharanya Marupakala | Initial version — RTWC-2319 |

---

## 12. SDLC Workflow Governance

This section applies to updates of SDLC process assets (agent prompts, hooks, workflow docs, and Copilot instructions).

### Branch routing rule

- SDLC workflow changes must be committed on the designated SDLC workflow ticket branch for that sprint.
- Do not mix feature-ticket code and SDLC workflow updates in the same branch.
- The SDLC workflow branch is determined by the active Jira ticket for workflow improvements — it is not hardcoded.

### PR and merge policy

- Commit and push are mandatory before any PR action.
- PR automation is the default: after QA approval, the workflow proceeds to PR preview and publishes unless the developer explicitly defers.
- A single follow-up question is presented before PR publish: "Raise PR now or defer?"
- No auto-merge is permitted after push or PR publish.

### Mandatory workflow gates

- Build + Launch gate must pass before QA starts.
- QA test plan requires explicit approval before QA execution.
- Final implementation summary must be written locally and include workflow telemetry:
  - Iteration count
  - Tool-call count
  - Elapsed time
  - Token usage (or `UNAVAILABLE IN THIS RUNTIME`)

---

**Questions?** Refer to RTWC-2319 or contact Sharanya Marupakala / Girjesh Kumar Vishwakarma.
