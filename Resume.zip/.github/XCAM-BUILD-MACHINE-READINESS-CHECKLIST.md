# XCAM Build Machine Readiness Checklist

Use this checklist before running SDLC build and test gates. The goal is to separate machine/dependency issues from ticket changes.

## Scope

- Repository: rtw-xcam-phase2
- App runtime: .NET Framework 4.8 (XCAM.Core, XCAM.Services, XCAM.UI)
- Test runtime: .NET 8 (XCAM.Test)

## Expected Baseline Outcome

- Build and test steps should run without environment blockers.
- If blockers exist, capture them as baseline environment issues, not ticket regressions.

## A. Toolchain Validation

Run in PowerShell:

```powershell
where.exe msbuild
& "C:\Program Files\Microsoft Visual Studio\2022\Professional\MSBuild\Current\Bin\MSBuild.exe" -version
where.exe dotnet
dotnet --info
```

Pass criteria:
- MSBuild resolves to Visual Studio 2022 path.
- dotnet is installed and reports SDKs (including .NET 8).

## B. .NET Targeting Packs

Validate .NET Framework 4.8 targeting support in Visual Studio installer:
- Workload: .NET desktop development
- Component: .NET Framework 4.8 targeting pack / developer pack

Pass criteria:
- A simple .NET Framework 4.8 project can compile with local MSBuild.

## C. RTW Shared Dependency Paths

The solution uses absolute HintPath references under Program Files. Validate these folders exist:

- C:\Program Files\RTWApps\RHH\Framework\
- C:\Program Files\RTWApps\RTWI\Framework\
- C:\Program Files\RTWApps\RTWI\Windows\

Quick check:

```powershell
Test-Path "C:\Program Files\RTWApps\RHH\Framework"
Test-Path "C:\Program Files\RTWApps\RTWI\Framework"
Test-Path "C:\Program Files\RTWApps\RTWI\Windows"
```

Pass criteria:
- All three return True.

## D. Key DLL Presence Check

Verify core framework DLLs referenced by project files exist:

```powershell
$mustExist = @(
  "C:\Program Files\RTWApps\RHH\Framework\RHH.Framework.Common.dll",
  "C:\Program Files\RTWApps\RHH\Framework\RHH.Framework.Employers.dll",
  "C:\Program Files\RTWApps\RHH\Framework\RHH.Framework.Profiles.dll",
  "C:\Program Files\RTWApps\RTWI\Framework\RTWI.Framework.Policies.dll",
  "C:\Program Files\RTWApps\RTWI\Framework\RTWI.Framework.Accounting.Payables.dll",
  "C:\Program Files\RTWApps\RTWI\Windows\RTWI.Windows.ControlLibrary.dll"
)
$mustExist | ForEach-Object {
  [PSCustomObject]@{ Path = $_; Exists = (Test-Path $_) }
} | Format-Table -AutoSize
```

Pass criteria:
- All files show Exists = True.

## E. Known API Compatibility Risk

Current code calls framework methods that may be missing in older machine DLL sets.
If build fails with missing method errors, compare against known baseline notes in:

- .github/dev-notes.md
- .github/copilot-instructions.md

Typical risk examples:
- EmployersFramework.GetOnAccountBalance
- EmployersFramework.GetStatementDisplayRevenues
- EmployersFramework.GetOnAccount
- EmployersFramework.GetPolicyRevenueDetails
- EmployersFramework.GetAgencyOrAssociationInformation
- Policy.GetPolicyByTrID

Pass criteria:
- No compile-time missing method/member errors from these framework APIs.

## F. Build Validation Sequence

From repository root:

```powershell
& "C:\Program Files\Microsoft Visual Studio\2022\Professional\MSBuild\Current\Bin\MSBuild.exe" XCAM.sln /t:Build /p:Configuration=Debug "/p:Platform=Any CPU"
```

Pass criteria:
- Build completes successfully.

If failed:
- Capture first 20 compile errors.
- Classify each as either:
  - Environment/dependency baseline issue
  - Ticket code regression

## G. Test Validation Sequence

Run tests after build:

```powershell
dotnet test XCAM.Test/XCAM.Test.csproj
```

Pass criteria:
- Tests execute and failures (if any) are triaged as baseline vs net-new.

## H. Baseline Classification Template

Use this template in handoff summaries:

- Build status: PASS or FAIL
- Build failure type: Baseline environment issue or Net-new regression
- Test status: Executed count and failures
- Test failure type: Baseline environment issue or Net-new regression
- Action needed: Framework update, tool install, or code fix

## I. If Machine Is Not Ready

Recommended remediation order:
1. Update RTW framework binaries under Program Files via approved bootstrap/update process.
2. Re-run dependency path and DLL presence checks.
3. Re-run solution build.
4. Re-run tests.

## J. SDLC Gate Rule

Do not mark a ticket as code-regression failed until machine readiness checks in sections A through D are complete and documented.
