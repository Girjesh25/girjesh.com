# XCAM � Technical Documentation

> **Confluence Space:** XCAM  
> **Status:** Living document � updated as implementation progresses  
> **Framework:** VB.NET � .NET Framework 4.8 � Windows Forms  
> **Original Source:** VB6 Windows application (XCAM.vbp)

---

## Table of Contents

1. [Application Overview](#1-application-overview)
2. [Architecture](#2-architecture)
3. [Solution Structure](#3-solution-structure)
4. [Project: XCAM.Core](#4-project-xcamcore)
5. [Project: XCAM.Services](#5-project-xcamservices)
6. [Project: XCAM.UI � Forms Inventory](#6-project-xcamui--forms-inventory)
7. [Framework Dependencies (RHH / RTWI)](#7-framework-dependencies-rhh--rtwi)
8. [Data Flow Pattern](#8-data-flow-pattern)
9. [Application Startup](#9-application-startup)
10. [Global State � AppState Module](#10-global-state--appstate-module)
11. [Error Handling](#11-error-handling)
12. [Tab Navigation Constants](#12-tab-navigation-constants)
13. [VB6-to-VB.NET Source File Mapping](#13-vb6-to-vbnet-source-file-mapping)
14. [Known Gaps & TODO Items](#14-known-gaps--todo-items)
15. [Business Rules Reference](#15-business-rules-reference)
16. [Implementation Checklist](#16-implementation-checklist)

---

## 1. Application Overview

XCAM is a **Windows Forms LOB (line-of-business) application** used to manage employers, insureds, policies, collections, cancellations, accounting, and communications (diary, tasks, system notifications) for a workers' compensation insurance operation.

### History of This Codebase

| Phase | Description |
|---|---|
| **Original** | VB6 MDI application (`XCAM.vbp`). Communicated with backend via direct HTTP calls to legacy `.asp` endpoints, exchanging XML documents. |
| **C# .NET 9 attempt** | A conversion to C# .NET 9 was started using GitHub Copilot and Claude. Documented in `XCAM-Conversion-Instructions.md`. |
| **Current: VB.NET .NET 4.8** | Due to framework dependency constraints (`RHH.Framework.*`, `RTWI.Framework.*`), the active codebase targets **VB.NET / .NET Framework 4.8**. Legacy ASP calls have been replaced with direct framework DLL calls. The XML response layer has been removed � services now return `DataTable` / `Boolean` directly. |

### Key Design Decisions Made During Migration

| Decision | Rationale |
|---|---|
| VB.NET over C# | `RHH.Framework` and `RTWI.Framework` DLLs are .NET 4.x assemblies; .NET 9 was incompatible |
| `DataTable` return types instead of `XDocument` | Framework methods already return `DataSet`/`DataTable`; converting to XML and back added no value |
| `Async/Await` throughout services | Keeps the UI thread responsive during framework DLL calls (which may hit a database or network) |
| Constructor injection of `UserProfile` | Replaces the VB6 global `g_lUserID` integer; each service receives context from the caller |
| `AppState` module as global state | Mirrors VB6 `basMain.bas` public variables; earmarked for DI refactor in a future phase |

---

## 2. Architecture

```
???????????????????????????????????????????????????????????
?                     XCAM.UI                             ?
?  Windows Forms � frmMain, frmInsured, frmPolicy, ...   ?
?  Consumes: XCAM.Services, XCAM.Core                    ?
???????????????????????????????????????????????????????????
                    ? calls async service methods
                    ? binds DataTable to DataGridView.DataSource
                    ?
???????????????????????????????????????????????????????????
?                   XCAM.Services                         ?
?  InsuredService, AccountingService, MessagingService,  ?
?  NotesService, CollectionCancelService, UserService    ?
?  Returns: Task(Of DataTable) or Task(Of Boolean)       ?
???????????????????????????????????????????????????????????
                    ? calls framework DLL methods
                    ?
???????????????????????????????????????????????????????????
?           Framework DLLs (referenced)                  ?
?  RHH.Framework.Profiles                                ?
?  RHH.Framework.FileDocuments                           ?
?  RHH.Framework.Contacts                               ?
?  RHH.Framework.Messaging (Diary, Tasks, Notifications)?
?  RTWI.Framework.Policies (Insured, Policy, Cancellation?
?                            MasterTable, Contact)       ?
?  RTWI.Framework.Accounting.Payables (Banks)           ?
?  Returns: DataSet                                      ?
???????????????????????????????????????????????????????????
```

### What Was Replaced

| VB6 Layer | .NET 4.8 Equivalent |
|---|---|
| `CXML.cls` HTTP calls to `.asp` endpoints | Framework DLL method calls |
| XML `<DATA ACTION="OK">` response parsing | Direct `DataSet.Tables(0)` extraction |
| `XDocument.Descendants(...)` in UI | `DataGridView.DataSource = dt` or `For Each row As DataRow In dt.Rows` |
| `g_oCXML` global singleton | `AppState.Http` (`HttpClient`) � kept for future use |
| `ErrorShieldClient` COM object | `AppState.ErrorHandler` (`IErrorHandler` ? `RhhLoggerErrorHandler`) |

---

## 3. Solution Structure

```
XCAM.sln
?
??? XCAM.Core\                  ? Shared infrastructure
?   ??? AppState.vb             ? Global state module (replaces basMain.bas globals)
?   ??? IErrorHandler.vb        ? Error reporting interface + RhhLoggerErrorHandler
?   ??? StateInfo.vb            ? US state lookup (replaces basMain.ConvertState)
?   ??? XcamException.vb        ? Custom exception type
?   ??? NativeMethods.vb        ? Win32 P/Invoke declarations
?
??? XCAM.Services\              ? Business/data service layer
?   ??? InsuredService.vb       ? Employer, insured, policy, contact lookups
?   ??? AccountingService.vb    ? GL accounts, user lookup, access check
?   ??? MessagingService.vb     ? Diary, tasks, system notifications
?   ??? NotesService.vb         ? Notes and file documents
?   ??? CollectionCancelService.vb ? Collections and cancellations
?   ??? UserService.vb          ? User detail and membership
?   ??? XcamHttpClient.vb       ? HttpClient wrapper (legacy endpoint fallback)
?
??? XCAM.UI\                    ? Windows Forms UI
    ??? Program.vb              ? Application entry point (replaces Sub Main in basMain.bas)
    ??? Forms\
        ??? frmMain             ? Main shell, policy search grid, inbox
        ??? frmInsured          ? Central employer/insured form (6 tabs)
        ??? frmEmployer         ? Employer detail form (6 tabs, simpler than frmInsured)
        ??? frmPolicy           ? Policy detail: header, events, notes, tasks
        ??? frmCollections      ? Collections by policy
        ??? frmCancellations    ? Cancellations by policy
        ??? frmCancelRevenues   ? Revenue lines on a cancellation
        ??? frmContact          ? Add/edit contact dialog
        ??? frmNote             ? Notes & documents viewer/editor
        ??? frmSystemMessage    ? System notifications list
        ??? frmErSearch         ? Employer/policy search dialog
        ??? frmEmployerSearch   ? Employer lookup dialog
        ??? frmAgencyAssoc      ? Agency picker dialog
        ??? frmInvoice          ? Invoice display
        ??? frmAdjustCharges    ? Charge adjustment dialog
        ??? frmCashAdjustment   ? Cash/GL adjustment dialog
        ??? frmPaymentTypes     ? Payment type picker
        ??? frmAdjCommission    ? Commission adjustment
        ??? frmRunCommissions   ? Commission run (uses WebBrowser)
        ??? frmGLPost           ? GL posting
        ??? frmDates            ? Date range picker dialog
        ??? frmTransfer         ? Transfer dialog
        ??? frmBillingAddress   ? Billing address form
        ??? frmSuspenseApplication  ? Suspense application
        ??? frmSuspensePendingMatch ? Suspense matching
        ??? frmSuspenseComment  ? Suspense comment
        ??? frmManualLockBox    ? Manual lockbox entry
        ??? frmLockboxProcessSuccessful ? Lockbox confirmation
```

---

## 4. Project: XCAM.Core

Shared infrastructure with no external dependencies other than the .NET 4.8 BCL.

### AppState.vb

Module-level global state. Replaces VB6 `basMain.bas` public variables.

| Member | Type | VB6 Equivalent | Description |
|---|---|---|---|
| `AppName` | `String` | `g_sAPP` | `"XCAM"` |
| `AppVersion` | `String` | `g_sVERSION` | `"2.3.9"` |
| `HostName` | `String` | `g_sHostName` | Machine name |
| `UserName` | `String` | `g_sUserName` | Windows login |
| `UserId` | `Long` | `g_lUserID` | RTW numeric user ID |
| `BaseUrl` | `String` | `sIIS` | Server base URL (from registry `HKLM\Software\RTW\Host`) |
| `Http` | `HttpClient` | `g_oCXML` (partial) | Singleton `HttpClient` |
| `ErrorHandler` | `IErrorHandler` | `g_oError` (ErrorShieldClient) | Error reporter |
| `GlClearing` | `String` const | `GL_CLEARING` | `"14098"` |
| `GlReturnOfCash` | `String` const | `GL_RETURN_OF_CASH` | `"14099"` |
| `GlWriteOff` | `String` const | `GL_WRITEOFF` | `"11098"` |
| `GlClaimsCash` | `String` const | `GL_CLAIMS_CASH` | `"10240"` |
| `GlOperatingCash` | `String` const | `GL_OPERATING_CASH` | `"10220"` |
| `LocationTab` | `Integer` const | `LOCATION_TAB = 0` | Tab index 0 |
| `NotesTab` | `Integer` const | `NOTES_TAB = 1` | Tab index 1 |
| `TasksTab` | `Integer` const | `TASKS_TAB = 2` | Tab index 2 |
| `DiaryTab` | `Integer` const | `DIARY_TAB = 3` | Tab index 3 |
| `CollectionsTab` | `Integer` const | `COLLECTIONS_TAB = 4` | Tab index 4 |
| `AccountTab` | `Integer` const | `ACCOUNT_TAB = 5` | Tab index 5 |

### IErrorHandler.vb

```vb
Public Interface IErrorHandler
    Sub ReportError(appName, appVersion, moduleName, procedureName, ex, context)
End Interface
```

`RhhLoggerErrorHandler` is the active implementation. It delegates to `RHH.Framework.Common.Logger.WriteExceptionLogFile` with these arguments:

| Argument | Value |
|---|---|
| `errSource` | `"RTWI.Windows.XCAM"` (constant) |
| `errMessage` | `moduleName & "." & procedureName` |
| `errString` | `ex.Message & ex.StackTrace` + optional `context` line |

A `Try/Catch` guard around the `Logger` call ensures a logging failure can never crash the application � it falls back to `Debug.WriteLine`.

### StateInfo.vb / StateHelper

Replaces `basMain.ConvertState()`. Supports lookup by:
- Numeric `MasterTrID` string (e.g., `"5"` ? Colorado)
- 2-letter code (e.g., `"CO"`)
- Full name (e.g., `"Colorado"`)

### XcamException.vb

Custom exception type for XCAM-specific business errors. Inherits `ApplicationException`.

### NativeMethods.vb

Win32 P/Invoke declarations (`ShowWindow`, `SetForegroundWindow`). Used for legacy window management ported from VB6 `NativeMethods`/`basMain`.

---

## 5. Project: XCAM.Services

Each service class is instantiated by forms and injected with a `RHH.Framework.Profiles.UserProfile`. All public methods are `Async` and return `Task(Of DataTable)` or `Task(Of Boolean)`.

### Service Summary

| Class | VB6 Source | Framework Classes Used | Key Methods |
|---|---|---|---|
| `InsuredService` | `cInsured.cls` | `EmployersFramework`, `Insured`, `Policy`, `MasterTable`, `Contact`, `ContactsFramework`, `Banks` | `GetPolicySearchAsync`, `GetEmployerInsuredsAsync`, `GetEmployerLocationsAsync`, `GetEmployerContactsAsync`, `GetEmployerPoliciesAsync`, `GetPolicyDetailAsync`, `GetPolicyEventsAsync`, `GetAgencySearchAsync`, `InsertContactAsync`, `UpdateContactAsync`, `DeleteContactAsync` |
| `AccountingService` | `cAccounting.cls` / `basMain` | `EmployersFramework`, `UserProfile` (static) | `LoadDrAccountsAsync`, `LoadCrAccountsAsync`, `LoadEmployersAsync`, `LoadEmployersByStatementNumberAsync`, `LoadEmployersByCheckNumberAsync`, `LoadOnAccountAsync`, `LoadOnAccountLedgerAsync`, `LoadRevenueDetailsAsync`, `LoadAgencySearchAsync`, `LoadPolicySearchInformationAsync`, `GetUserIdAsync`, `GetUsersNameAsync` |
| `MessagingService` | `cMessaging.cls`, `cDiary.cls` | `DiaryFramework`, `TasksFramework`, `SystemNotificationsFramework` | `GetDiaryBySourceAsync`, `GetTasksBySourceAsync`, `GetTaskDetailsAsync`, `GetSystemNotificationsAsync`, `UpdateSystemNotificationReadAsync`, `MoveLocationAsync` |
| `NotesService` | `cNotes.cls` | `FileDocumentsFramework` | `GetNoteDocumentAsync`, `GetNotesBySubCategoryAsync`, `GetSubCategoriesAsync`, `GetNotesDocumentsBySourceAsync`, `UpdateNoteDocumentAsync` |
| `CollectionCancelService` | `cCollectionCancel.cls` | `Cancellation`, `Policy` | `GetCancellationsByPolicyAsync`, `GetCollectionsByPolicyAsync`, `InsertCollectionStatusAsync`, `InsertCancellationStatusAsync`, `InsertCancellationManualAsync`, `AddRevenueToCancellationAsync`, `DeleteRevenueFromCancellationAsync` |
| `UserService` | `cUser.cls` | `UserProfile` (instance) | `GetMembersAsync`, `GetUserDetailAsync`, and others |

### Constructor Pattern (All Services)

```vb
Public Sub New(userProfile As RHH.Framework.Profiles.UserProfile)
    _userProfile = userProfile
    ' initialise framework objects using CInt(AppState.UserId)
End Sub
```

### Return Type Convention

| Scenario | Return Type | Notes |
|---|---|---|
| Query returning rows | `Task(Of DataTable)` | `ds.Tables(0)` from framework; `Nothing` on error |
| Insert / Update / Delete | `Task(Of Boolean)` | `True` = success |
| User/access check | `Task(Of Boolean)` or primitive | Direct comparison |

### Error Handling Pattern (All Service Methods)

```vb
Try
    Dim ds As DataSet = Await Task.Run(Function() _framework.GetSomething(...))
    Return If(ds IsNot Nothing AndAlso ds.Tables.Count > 0, ds.Tables(0), Nothing)
Catch ex As Exception
    AppState.ErrorHandler.ReportError(AppState.AppName, AppState.AppVersion,
        "ServiceClassName", "MethodName", ex, contextString)
    Return Nothing   ' or False for Boolean methods
End Try
```

---

## 6. Project: XCAM.UI � Forms Inventory

### Form Status Key

| Status | Meaning |
|---|---|
| ? Working | Service calls wired, data binding complete, demoed |
| ?? Scaffolded | Form exists, service calls present, business logic incomplete |
| ?? Stub | Form shell created, TODO markers throughout |
| ? Not Started | Listed in VB6 source, not yet ported |

### Forms Inventory

| Form | VB6 Source | Status | Description | Key Dependencies |
|---|---|---|---|---|
| `frmMain` | `frmMain.frm` | ? Working | Main shell: policy search grid (`fg`), inbox queue, company selector, `OpenEmployer` | `InsuredService`, `MessagingService`, `NotesService`, `CollectionCancelService`, `AccountingService`, `UserService` |
| `frmInsured` | `frmInsured.frm` (7071 lines, 128 methods) | ?? Scaffolded | Central employer record: 6 tabs (Location, Notes, Tasks, Diary, Collections, Account). Largest form in the app. | All services |
| `frmEmployer` | `frmEmployer.frm` | ?? Scaffolded | Employer detail with same 6-tab layout (lighter version of `frmInsured`) | All services |
| `frmPolicy` | `frmPolicy.frm` (4550 lines, 57 methods) | ✅ Scaffolded | Policy header labels, events (history tab wired), notes TreeView, tasks grid | `InsuredService`, `NotesService`, `MessagingService`, `PolicyService` |
| `frmCollections` | `frmCollections.frm` (3307 lines, 58 methods) | ?? Scaffolded | Collections by policy, insert collection | `CollectionCancelService` |
| `frmCancellations` | `frmCancellations.frm` (3833 lines, 71 methods) | ?? Scaffolded | Cancellations by policy, insert/manual | `CollectionCancelService` |
| `frmCancelRevenues` | Part of cancellation subsystem | ?? Scaffolded | Revenue lines on a cancellation header, add/remove | `CollectionCancelService` |
| `frmContact` | `frmContact.frm` | ? Working | Add/edit contact dialog (first/last/title/phone/fax/email/comment) | `InsuredService` |
| `frmNote` | `frmNote.frm` | ✅ Scaffolded | Notes viewer: TreeView of notes, ListView of documents, RichTextBox preview, Save (UpdateNoteDocumentAsync wired) | `NotesService` |
| `frmSystemMessage` | `frmSystemMessage.frm` | ? Working | System notifications grid; double-click marks as read | `MessagingService` |
| `frmErSearch` | `frmErSearch.frm` | ? Working | Policy search ? ListView ? returns `SelectedErMasterTrId` | `InsuredService` |
| `frmEmployerSearch` | `frmEmployerSearch.frm` | ? Working | Employer lookup ? ListView ? returns `SelectedErMasterTrId` | `InsuredService` |
| `frmAgencyAssoc` | `frmAgencyAssoc.frm` | ? Working | Agency picker ? ListView ? returns `SelectedAgencyTrId` | `InsuredService` |
| `frmInvoice` | `frmInvoice.frm` | ?? Scaffolded | Invoice display; header from policy detail, line items grid (line items not yet in service) | `InsuredService` |
| `frmAdjustCharges` | `frmAdjustCharges.frm` | ?? Scaffolded | Charge adjustment grid; binds policy detail DataTable | `InsuredService` |
| `frmCashAdjustment` | `frmCashAdjustment.frm` | ?? Scaffolded | Debit/credit GL account ComboBoxes, amount entry | `AccountingService` |
| `frmPaymentTypes` | `frmPaymentTypes.frm` | ?? Stub | Payment type selection (TODO: populate grid from employer locations) | `InsuredService` |
| `frmAdjCommission` | `frmAdjCommission.frm` | ?? Stub | Commission adjustment | � |
| `frmRunCommissions` | `frmRunCommissions.frm` | ?? Stub | Commission run (uses WebBrowser control) | � |
| `frmGLPost` | `frmGLPost.frm` | ?? Stub | GL posting | � |
| `frmDates` | Utility dialog | ?? Stub | Date range picker | � |
| `frmTransfer` | `frmTransfer.frm` | ?? Stub | Transfer dialog | � |
| `frmBillingAddress` | `frmBillingAddress.frm` | ?? Stub | Billing address form | � |
| `frmSuspenseApplication` | `frmSuspenseApplication.frm` | ?? Stub | Suspense application | � |
| `frmSuspensePendingMatch` | `frmSuspensePendingMatch.frm` | ?? Stub | Suspense matching | � |
| `frmSuspenseComment` | `frmSuspenseComment.frm` | ?? Stub | Suspense comment | � |
| `frmManualLockBox` | `frmManualLockBox.frm` | ?? Stub | Manual lockbox entry | � |
| `frmLockboxProcessSuccessful` | Utility | ?? Stub | Lockbox confirmation dialog | � |

### frmMain Grid (fg � DataGridView) Column Mapping

The main grid `fg` has designer-defined columns with `DataPropertyName` already set. Binding is `fg.DataSource = dt` directly from `InsuredService.GetPolicySearchAsync`.

| Column Name | DataPropertyName | Visible | Description |
|---|---|---|---|
| `PolicyNumber` | `PolicyNumber` | Yes | Policy number |
| `EmployerName` | `EmployerName` | Yes | Employer name |
| `EffectiveDate` | `EffectiveDate` | Yes | Policy effective date |
| `ExpirationDate` | `ExpirationDate` | Yes | Policy expiration date |
| `Status` | `Status` | Yes | Policy status |
| `ErMasterTrID` | `ErMasterTrID` | No (hidden) | Used by double-click to open `frmInsured` |
| `PolicyTrID` | `PolicyTrID` | No (hidden) | Used by double-click to open `frmInsured` |
| `PreviewText` | `PreviewText` | No (hidden) | Shown in `rtxtPreview` on row select |

### Notes Tab Pattern (Repeated Across Multiple Forms)

The following forms all implement an identical notes/documents pattern:

- `frmInsured` (Notes tab)
- `frmEmployer` (Notes tab)
- `frmPolicy` (Notes tab)
- `frmNote` (standalone)

**Pattern:** `NotesService.GetNotesDocumentsBySourceAsync(sourceType, trId)` ? `DataTable` ? iterate rows into `TreeView` nodes. Node `.Tag` stores the note ID. `AfterSelect` calls `NotesService.GetNoteDocumentAsync(docType, id)` ? `DataTable` ? row `("NoteBody")` ? `RichTextBox.Text`.

**Refactoring opportunity:** Extract into a `NotesTabUserControl`.

---

## 7. Framework Dependencies (RHH / RTWI)

These are referenced DLLs, not NuGet packages. They are closed-source framework assemblies.

### RHH.Framework.*

| Assembly | Key Class | Used In | Purpose |
|---|---|---|---|
| `RHH.Framework.Common` | `Logger` | `XCAM.Core` (`RhhLoggerErrorHandler`) | Exception logging to text file |
| `RHH.Framework.Profiles` | `UserProfile`, `MasterClientProfile` | All services + `Program.vb` | User identity, master client list |
| `RHH.Framework.FileDocuments` | `FileDocumentsFramework` | `NotesService` | Notes and document retrieval/update |
| `RHH.Framework.Contacts` | `ContactsFramework` | `InsuredService` | Contact insert/update operations |
| `RHH.Framework.Messaging` | `DiaryFramework`, `TasksFramework`, `SystemNotificationsFramework` | `MessagingService` | Diary, tasks, notifications |

### RTWI.Framework.*

| Assembly | Key Class | Used In | Purpose |
|---|---|---|---|
| `RTWI.Framework.Policies` | `Insured`, `Policy`, `MasterTable`, `Contact`, `Cancellation` | `InsuredService`, `CollectionCancelService` | Policy/employer/insured data; cancellations |
| `RTWI.Framework.Accounting.Payables` | `Banks`, `EmployersFramework` | `InsuredService`, `AccountingService` | Bank accounts, employer GL data |

### Framework Method ? Service Method Cross-Reference

| Framework Method | Service Method | Returns |
|---|---|---|
| `MasterClientProfile.GetMasterClientsByUserID(userId)` | `InsuredService.GetCompanyMasterListAsync` | `DataTable` |
| `Banks.GetBankAccounts()` | `InsuredService.GetBankAccountsAsync` | `DataTable` |
| `EmployersFramework.GetOffices(masterClientTrId, login)` | `InsuredService.GetOfficesByLoginAsync` | `DataTable` |
| `Insured.GetEmployerLocations(erMasterTrId)` | `InsuredService.GetEmployerLocationsAsync` | `DataTable` |
| `Insured.GetEmployerInsureds(erMasterTrId)` | `InsuredService.GetEmployerInsuredsAsync` | `DataTable` |
| `Contact.GetEmployerContacts(erMasterTrId)` | `InsuredService.GetEmployerContactsAsync` | `DataTable` |
| `Policy.GetPoliciesByEmployer(erMasterTrId)` | `InsuredService.GetEmployerPoliciesAsync` | `DataTable` |
| `Policy.GetPolicy(policyTrId, True)` | `InsuredService.GetPolicyDetailAsync` | `DataTable` |
| `Policy.GetPolicyEvents(policyTrId)` | `InsuredService.GetPolicyEventsAsync` | `DataTable` |
| `MasterTable.GetPWSearch(criteria)` | `InsuredService.GetPolicySearchAsync` | `DataTable` |
| `MasterTable.GetAgencies()` | `InsuredService.GetAgencySearchAsync` | `DataTable` |
| `ContactsFramework.InsertContact(ds)` | `InsuredService.InsertContactAsync` | `DataTable` |
| `ContactsFramework.UpdateContact(ds)` | `InsuredService.UpdateContactAsync` | `DataTable` |
| `ContactsFramework.DeleteContact(contactTrId)` | `InsuredService.DeleteContactAsync` | `Boolean` |
| `EmployersFramework.GetDrAccounts(masterClientTrId)` | `AccountingService.LoadDrAccountsAsync` | `DataTable` |
| `EmployersFramework.GetCrAccounts(masterClientTrId)` | `AccountingService.LoadCrAccountsAsync` | `DataTable` |
| `EmployersFramework.GetEmployers(masterClientTrId)` | `AccountingService.LoadEmployersAsync` | `DataTable` |
| `DiaryFramework.GetDiaryBySource(sourceType, trId)` | `MessagingService.GetDiaryBySourceAsync` | `DataTable` |
| `TasksFramework.GetTasksBySource(sourceType, trId)` | `MessagingService.GetTasksBySourceAsync` | `DataTable` |
| `TasksFramework.GetTaskDetails(taskHeaderTrId)` | `MessagingService.GetTaskDetailsAsync` | `DataTable` |
| `SystemNotificationsFramework.GetSystemNotificationsByUserID(userId, 0)` | `MessagingService.GetSystemNotificationsAsync` | `DataTable` |
| `SystemNotificationsFramework.UpdateSystemNotifications(ds)` | `MessagingService.UpdateSystemNotificationReadAsync` | `Boolean` |
| `TasksFramework.MoveTaskLocation(taskTrId, LocationMaster)` | `MessagingService.MoveLocationAsync` | `Boolean` |
| `FileDocumentsFramework.GetFileDocument(docTrId)` | `NotesService.GetNoteDocumentAsync` | `DataTable` |
| `FileDocumentsFramework.GetFileDocumentsBySubCategory(...)` | `NotesService.GetNotesBySubCategoryAsync` | `DataTable` |
| `FileDocumentsFramework.GetSubCategories(docTypeMaster)` | `NotesService.GetSubCategoriesAsync` | `DataTable` |
| `FileDocumentsFramework.GetFileDocuments()` | `NotesService.GetNotesDocumentsBySourceAsync` | `DataTable` |
| `FileDocumentsFramework.UpdateNote(...)` | `NotesService.UpdateNoteDocumentAsync` | `Boolean` |
| `Cancellation.GetCancellations(policyTrId)` | `CollectionCancelService.GetCancellationsByPolicyAsync` | `DataTable` |
| `Policy.GetCollections(policyTrId)` | `CollectionCancelService.GetCollectionsByPolicyAsync` | `DataTable` |
| `Cancellation.InsertCancellationStatus(...)` | `CollectionCancelService.InsertCancellationStatusAsync` | `Boolean` |
| `Cancellation.InsertCancellationManual(...)` | `CollectionCancelService.InsertCancellationManualAsync` | `Boolean` |
| `Cancellation.ReinstatePendingUWCancellation(...)` | `CollectionCancelService.DeleteRevenueFromCancellationAsync` | `Boolean` |

---

## 8. Data Flow Pattern

### Query (UI ? Service ? Framework)

```
Form calls:
    Dim dt As DataTable = Await _insuredSvc.GetPolicySearchAsync(criteria)
    fg.DataSource = dt

Service executes:
    Dim ds As DataSet = Await Task.Run(Function()
        Return _masterTable.GetPWSearch(criteria)
    End Function)
    Return If(ds IsNot Nothing AndAlso ds.Tables.Count > 0, ds.Tables(0), Nothing)

Framework returns:
    DataSet with one or more DataTable objects
```

### Mutation (UI ? Service ? Framework)

```
Form calls:
    Dim ok As Boolean = Await _insuredSvc.DeleteContactAsync(contactTrId)
    If ok Then Await LoadLocationAsync()

Service executes:
    Return Await Task.Run(Function()
        Return _contactsFramework.DeleteContact(CInt(contactTrId))
    End Function)
```

### Grid Binding Approaches

| Control Type | Binding Approach |
|---|---|
| `DataGridView` with `DataPropertyName` set in designer | `dgv.DataSource = dt` � automatic column mapping |
| `DataGridView` without `DataPropertyName` (older forms) | `For Each row As DataRow In dt.Rows : dgv.Rows.Add(col1, col2...) : Next` |
| `ListBox` | `For Each row As DataRow In dt.Rows : lst.Items.Add(...) : Next` |
| `ComboBox` | Same row iteration pattern |
| `ListView` | `New ListViewItem(name)` with `.SubItems.Add(...)` and `.Tag = id` |
| `TreeView` | Manual node construction with `.Tag = id` for lazy-load |
| Labels | Direct `lbl.Text = If(dt.Columns.Contains("Col"), CStr(row("Col")), String.Empty)` |

### Safe Column Access Pattern

```vb
' Always guard against missing columns (framework DataTable schema may vary)
Dim value As String = If(dt.Columns.Contains("ColumnName"), CStr(row("ColumnName")), String.Empty)
```

---

## 9. Application Startup

**File:** `XCAM.UI\Program.vb`  
**VB6 Equivalent:** `Sub Main()` in `basMain.bas`

### Startup Sequence

```
1. Application.EnableVisualStyles()

2. Read IIS host from registry: HKLM\Software\RTW\Host
   Fallback: App.config key "XcamHost"
   ? AppState.BaseUrl

3. AppState.UserName = Environment.UserName

4. Create RHH.Framework.Profiles.UserProfile()
   ? AppState.UserId = userProfile.User.UserMasterTrID

5. AccountingService.CheckUserAccessAsync(userId)
   ? If False: show "You do not have access" and exit

6. AccountingService.GetUserIdAsync(AppState.UserName)
   ? Set AppState.UserId (confirmed numeric ID)

7. Show frmMain(userProfile)
   Application.Run(frmMain)
```

### Registry Key

```
HKEY_LOCAL_MACHINE\SOFTWARE\RTW\Host
Value: (string) e.g. "http://rtwserver"
```

---

## 10. Global State � AppState Module

`AppState` is a VB.NET `Module` (static class equivalent). It holds application-lifetime singletons and constants.

**Location:** `XCAM.Core\AppState.vb`

> ?? **Known Technical Debt:** `AppState` is a global module. The long-term plan is to replace it with dependency-injected services. Do not add new mutable state to `AppState`; pass context through constructors instead.

### GL Account Constants

These constants represent specific General Ledger account numbers used in accounting operations:

| Constant | Value | Business Meaning |
|---|---|---|
| `GlClearing` | `"14098"` | Clearing Account (ACIC) |
| `GlReturnOfCash` | `"14099"` | Return � Clearing (ACIC) |
| `GlWriteOff` | `"11098"` | Write Off (ACIC) |
| `GlClaimsCash` | `"10240"` | Cash � Master Claims (Havre MT) |
| `GlOperatingCash` | `"10220"` | Cash � Operating (ACIC) |

---

## 11. Error Handling

### Service Layer

Every service method wraps the entire body in `Try/Catch`:

```vb
Try
    ' framework call
Catch ex As Exception
    AppState.ErrorHandler.ReportError(
        AppState.AppName, AppState.AppVersion,
        "ServiceClass", "MethodName", ex, contextString)
    Return Nothing  ' or False
End Try
```

### UI Layer

Forms use `Try/Finally` to always restore the cursor:

```vb
Cursor = Cursors.WaitCursor
Try
    Dim dt As DataTable = Await _service.GetSomethingAsync(...)
    grid.DataSource = dt
Catch ex As Exception
    MessageBox.Show("Error: " & ex.Message, "Title", ...)
Finally
    Cursor = Cursors.Default
End Try
```

### Current Error Handler � `RhhLoggerErrorHandler`

All exceptions are written to a text log file via `RHH.Framework.Common.Logger.WriteExceptionLogFile`.

```vb
' Called automatically by every Catch block through AppState.ErrorHandler.ReportError(...)
RHH.Framework.Common.Logger.WriteExceptionLogFile(
    "RTWI.Windows.XCAM",          ' errSource  � always this constant
    "ServiceClass.MethodName",    ' errMessage � moduleName & "." & procedureName
    ex.Message & ex.StackTrace)   ' errString  � full detail + optional context line
```

The handler is wired as the default in `AppState.ErrorHandler` at application startup. No changes are needed in any service or form � all 34+ `ReportError` call sites route through it automatically.

A nested `Try/Catch` inside `RhhLoggerErrorHandler` prevents a logging failure from crashing the application.

---

## 12. Tab Navigation Constants

Defined in `AppState` and used by all multi-tab forms (`frmInsured`, `frmEmployer`, `frmPolicy`).

| Constant | Value | Tab |
|---|---|---|
| `AppState.LocationTab` | `0` | Location / Employer header |
| `AppState.NotesTab` | `1` | Notes & Documents |
| `AppState.TasksTab` | `2` | Tasks |
| `AppState.DiaryTab` | `3` | Diary |
| `AppState.CollectionsTab` | `4` | Collections |
| `AppState.AccountTab` | `5` | Accounting / GL accounts |

---

## 13. VB6-to-VB.NET Source File Mapping

| VB6 File | VB.NET Equivalent | Lines (VB6) | Notes |
|---|---|---|---|
| `basMain.bas` | `AppState.vb`, `Program.vb`, `StateInfo.vb`, `NativeMethods.vb` | ~800 | Split by concern |
| `basNotes.bas` | Partially in `NotesService.vb` | ~200 | Image manager not yet ported |
| `CXML.cls` | `XcamHttpClient.vb` (legacy fallback), framework DLL calls | ~300 | Most replaced by framework calls |
| `cUser.cls` | `UserService.vb` | ~400 | |
| `cMessaging.cls` + `cDiary.cls` | `MessagingService.vb` | ~500 | Combined |
| `cInsured.cls` | `InsuredService.vb` | ~600 | |
| `cNotes.cls` | `NotesService.vb` | ~400 | |
| `cCollectionCancel.cls` | `CollectionCancelService.vb` | ~500 | |
| `frmMain.frm` | `frmMain.vb` | ~2000 | Core search/inbox wired |
| `frmInsured.frm` | `frmInsured.vb` | 7071 / 128 methods | Largest form � partially implemented |
| `frmPolicy.frm` | `frmPolicy.vb` | 4550 / 57 methods | Scaffolded |
| `frmCollections.frm` | `frmCollections.vb` | 3307 / 58 methods | Scaffolded |
| `frmCancellations.frm` | `frmCancellations.vb` | 3833 / 71 methods | Scaffolded |

### Original ASP Endpoints ? Framework Replacements

| VB6 ASP Endpoint | Framework Replacement |
|---|---|
| `/XCAM/XCAMPolicy.asp` | `RTWI.Framework.Policies.Policy`, `Insured`, `MasterTable` |
| `/XCAM/XCAMBilling.asp` | `RHH.Framework.Profiles.MasterClientProfile`, `RTWI.Framework.Accounting.Payables.Banks` |
| `/XCAM/XCAMAccounting.asp` | `RTWI.Framework.Accounting.Payables.EmployersFramework` |
| `/XCAM/XCAMCollectionStatus.asp` | `RTWI.Framework.Policies.Policy` (GetCollections) |
| `/XCAM/XCAMCancelStatus.asp` | `RTWI.Framework.Policies.Cancellation` |
| `/RTWEvents/RTWEvents.asp` | `RHH.Framework.FileDocuments.FileDocumentsFramework` |
| `/rtwtasking/task.asp` | `RHH.Framework.Messaging.TasksFramework` |
| `/rtwdiary/rtwdiary.asp` | `RHH.Framework.Messaging.DiaryFramework` |
| `/systemnotifications/systemnotifications.asp` | `RHH.Framework.Messaging.SystemNotificationsFramework` |
| `/XCM/User.asp`, `/officemodeler/user.asp` | `RHH.Framework.Profiles.UserProfile` |
| `/officemodeler/ApplicationUserRights.asp` | `RHH.Framework.Profiles.UserProfile` (access check) |
| `/XCAM/XCAMPolicy.asp` (contacts) | `RHH.Framework.Contacts.ContactsFramework` |

---

## 14. Known Gaps & TODO Items

### Critical (Must Fix Before Full Production)

| # | Location | Issue | Action |
|---|---|---|---|
| 1 | `IErrorHandler` / `RhhLoggerErrorHandler` | ? **Resolved** � `RHH.Framework.Common.Logger.WriteExceptionLogFile` wired as default handler | No further action required |
| 2 | `frmInsured` | 7071-line VB6 original has 128 methods � most business logic not yet implemented | Systematic review against VB6 source (see checklist below) |
| 3 | `frmPolicy` | 57 methods in VB6; history/events tab now wired; diary, notes, tasks tabs loaded | Complete revenue, collections sub-tabs; commissions tab |
| 4 | `frmCollections` | Insert collection uses hardcoded XML string | Replace with structured framework call |
| 5 | `frmCancellations` | Insert/Manual cancellation buttons show TODO message boxes | Implement `InsertCancellationStatusAsync` and `InsertCancellationManualAsync` |
| 6 | `frmPaymentTypes` | Grid population not implemented | Wire `GetEmployerLocationsAsync` result to `dgvPaymentTypes` |
| 7 | All forms | `DataPropertyName` not set in designer for most grids in `frmInsured`, `frmEmployer` | Either set in designer or use `DataSource` with `AutoGenerateColumns` |
| 8 | `Program.vb` | Access check previously in `AccountingService.CheckUserAccessAsync`; now directly calls `userProfile.IsApplicationAccessible(33)` — contract test for the old method is stale | Remove `CheckUserAccessAsync_TakesUserId_ReturnsTaskOfBoolean` from `AccountingServiceContractTests.cs` |

### Medium Priority

| # | Location | Issue | Action |
|---|---|---|---|
| 9 | `NotesService` | `UpdateNoteDocumentAsync` parses XML string to extract fields � brittle | Replace with strongly-typed parameters |
| 10 | `InsuredService` | `InsertContactAsync` / `UpdateContactAsync` build XML strings for framework | Replace with DataSet-based calls matching framework signature |
| 11 | `frmNote` | `lvDocuments` (ListView) never populated — `GetNotesDocumentsBySourceAsync` returns a single table, documents are the same rows | Clarify schema: are notes and documents in same table or separate? Save (UpdateNoteDocumentAsync) is now wired. |
| 12 | Multiple forms | `Rows.Clear()` + manual row add pattern still used where `DataPropertyName` is missing | Set `DataPropertyName` in designer then switch to `DataSource = dt` |
| 13 | `frmRunCommissions` | Uses `WebBrowser` (IE-based ActiveX) | Evaluate `WebView2` replacement for edge cases |
| 14 | `CollectionCancelService` | `DeleteRevenueFromCancellationAsync` calls `ReinstatePendingUWCancellation` � verify this is the correct framework method for the intended business action | Review against VB6 `cCollectionCancel.cls` |

### Low Priority / Future

| # | Issue | Action |
|---|---|---|
| 15 | Notes tab duplicated in 4 forms | Extract to `NotesTabUserControl` |
| 16 | `AppState` module (global state) | Replace with DI container when .NET version is upgraded |
| 17 | `frmInsured` and `frmEmployer` overlap significantly | Evaluate whether one form can replace the other |
| 18 | `UserService.GetMembersAsync` returns raw `DataSet.GetXml()` string | Normalise to `DataTable` like other services |

---

## 15. Business Rules Reference

Business rules identified from the VB6 source and conversion instructions. This section should be expanded by reviewing each VB6 form method-by-method.

### User Access

- Users must have `RTWApplicationListTrID = 10` to access XCAM
- User identity is resolved from `Environment.UserName` (Windows login) via `UserProfile`
- `AppState.UserId` is the long integer used in all framework calls as `CInt(AppState.UserId)`

### GL Accounts

The following GL account numbers are hardcoded business constants:

| Account | Number | Use |
|---|---|---|
| Clearing (ACIC) | 14098 | Cash clearing entries |
| Return Clearing (ACIC) | 14099 | Return-of-cash entries |
| Write Off (ACIC) | 11098 | Bad debt write-offs |
| Claims Cash (Havre MT) | 10240 | Master claims cash pool |
| Operating Cash (ACIC) | 10220 | General operating cash |

### Policy Search

- `GetPolicySearchAsync(criteria)` calls `MasterTable.GetPWSearch(criteria)`
- Results are bound to `frmMain.fg` via `DataSource`
- Double-clicking a row reads `ErMasterTrID` and `PolicyTrID` hidden cells and opens `frmInsured` at `LocationTab`

### Collections vs Cancellations

- Collections are retrieved per `PolicyTrId` via `Policy.GetCollections`
- Cancellations are retrieved per `PolicyTrId` via `Cancellation.GetCancellations`
- Both can be inserted; cancellations additionally support manual entry
- Revenue lines on a cancellation header are managed via `AddRevenueToCancellationAsync` / `DeleteRevenueFromCancellationAsync`

### System Notifications

- Loaded per `UserId` with `flagID = 0` (all notifications)
- Marked as read by fetching the single row, setting `ReadFlag = 1`, then calling `UpdateSystemNotifications`
- `frmSystemMessage.dgvMessages` column `colNotificationTrID.DataPropertyName = "NotificationTrID"` � the ID is read from this bound cell on double-click

### Contacts

- Contacts are employer-scoped (`ErMasterTrId`)
- Insert/Update use XML string construction ? `ContactsFramework`
- Delete uses `ContactsFramework.DeleteContact(contactTrId)` directly
- After any contact mutation, `LoadLocationTabAsync` / `LoadLocationAsync` is called to refresh the contacts grid

---

## 16. Implementation Checklist

Use this checklist when reviewing each VB6 form against the .NET port to ensure no business rules are missed.

### Per-Form Review Template

```
Form: frmXxx
VB6 source: frmXxx.frm  (NNN lines, NN methods)

? All public properties present and typed correctly
? Form_Load logic fully ported (OnLoad / form_Load event)
? All Tab_SelectedIndexChanged cases handled
? All data-loading methods implemented (not TODO stubs)
? All button click handlers implemented
? All grid CellDoubleClick handlers implemented
? All TreeView/ListView event handlers implemented
? Dirty-state tracking (_isDirty) present if form has editable fields
? FormClosing / OnFormClosing prompts if _isDirty
? Cursor management (WaitCursor in finally blocks)
? Error handling (Try/Catch with AppState.ErrorHandler.ReportError)
? No residual XDocument / XElement / Descendants() / Attribute() references
? No residual CXML / ASP endpoint calls
? DataGridView columns mapped (DataPropertyName or manual row add consistent)
? Business rules from VB6 preserved (see per-method notes in VB6 source)
? Build passes with no errors or warnings
```

### Priority Order for Full Implementation

1. **`frmInsured`** � the central form; most end-user workflows pass through it
2. **`frmPolicy`** — opened from `frmInsured`; history/events now wired; revenue and collections sub-tabs remain incomplete
3. **`frmCollections`** � insert/manage collections needs framework call
4. **`frmCancellations`** � insert/manual cancellation buttons need implementation
5. **`frmCancelRevenues`** � revenue line management needs full add/remove cycle
6. **`frmNote`** — save functionality (UpdateNoteDocumentAsync) now wired; `lvDocuments` population still pending
7. **`frmCashAdjustment`** � GL posting logic not yet connected
8. **`frmGLPost`** � entire form is a stub
9. **`frmRunCommissions`** � commission run workflow
10. **`frmSuspense*`** forms � suspense matching and application workflow
11. **`frmManualLockBox`** � lockbox entry workflow
12. **Remaining stubs** � `frmDates`, `frmTransfer`, `frmBillingAddress`, etc.

---

*Generated from: `XCAM-Conversion-Instructions.md` (original C# conversion reference) and analysis of the current VB.NET .NET 4.8 codebase.*  
*Last updated: based on build-passing state after DataTable refactor.*
