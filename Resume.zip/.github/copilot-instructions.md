# XCAM Codebase Instructions (Source Verified)

This file is based on direct reads of source files in this repository.
No section below includes guessed behavior.

Last refreshed: 2026-08-07.

Active Git context: https://github.ent.stateauto.com/StateAuto/rtw-xcam (`dev` branch)

Framework source repositories:
- RHH: https://github.ent.stateauto.com/StateAuto/RTW-RHH (`dev` branch)
- RTWI: https://github.ent.stateauto.com/StateAuto/RTW-RTWI (`dev` branch)

Scope read for this document:
- Projects: XCAM.Core, XCAM.Services, XCAM.UI, XCAM.Test, XCAM.Installer
- Config and solution metadata: XCAM.sln, *.vbproj, *.csproj, App.config, Package.wxs
- Forms: frmMain, frmEmployer, frmPolicy, frmInsured, and related detail forms
- Incomplete marker scan: .vb, .cs, .ps1, .md, .wxs, .config (excluding bin/obj/.git/.vs/.tmp)

## 1. PROJECT IDENTITY

### What this application does
- XCAM is a Windows desktop application that starts from XCAM.UI/Program.vb.
- At startup it resolves host configuration (registry HKLM\SOFTWARE\RTW\Host or App.config key XcamHost), resolves the current Windows user, checks application access, and opens the main form.
- UI forms focus on employer, policy, insured, collections/cancellations, notes/documents, messaging/tasks/diary, and accounting workflows.

### Who uses it
- Users are RTW users resolved through RHH.Framework.Profiles.UserProfile.
- Access is explicitly checked in Program.vb via `userProfile.IsApplicationAccessible(33)` (RTWApplicationListTrID = 33).
- If user id is 0 or access is denied, the app exits after showing an Access Denied message.

### Technology stack
- Application language: VB.NET (.vb files) for Core/Services/UI.
- UI framework: Windows Forms (XCAM.UI project has MyType=WindowsForms, OutputType=WinExe).
- Runtime for app projects: .NET Framework 4.8 (TargetFrameworkVersion v4.8 in XCAM.Core, XCAM.Services, XCAM.UI).
- Test language/framework: C# xUnit in XCAM.Test.
- Test runtime: net8.0-windows in XCAM.Test.csproj.
- Installer tech: WiX v4 (WixToolset.Sdk/4.0.5, Package.wxs).

### Key dependencies and why they exist
- RHH.Framework.Profiles: user profile/user-rights lookup and user context.
- RHH.Framework.Common.MasterTables: master table (states, codes) lookup used by MasterTablesService.
- RHH.Framework.Employers: employer search and employer location data.
- RHH.Framework.Contacts: contact update/remove operations.
- RHH.Framework.FileDocuments: notes and file document retrieval/update.
- RTWI.Windows.FileDocuments: Windows-side file document helper used alongside RHH.Framework.FileDocuments.
- RHH.Framework.Messaging.Diary / Tasks / SystemNotifications: diary/task/notification data access.
- RTWI.Framework.Policies: policy, insured, cancellation, and master-table operations.
- RTWI.Framework.Accounting.Payables: bank/accounting related data.
- System.Net.Http: HTTP client in XcamHttpClient.
- System.Xml.Linq and DataSet XML APIs: XML parse/build paths in services and forms.
- xUnit + Microsoft.NET.Test.Sdk + coverlet.collector: test execution and coverage in XCAM.Test.

## 2. SOLUTION STRUCTURE

### Projects in solution
- XCAM.Core: shared state, constants, native interop wrappers, custom exceptions/error handling abstractions, and `StateInfo`/`StateHelper` for US state lookups.
- XCAM.Services: service layer used by forms; wraps RHH/RTWI framework calls and XML/HTTP helpers. Services: `AccountingService`, `CollectionCancelService`, `InsuredService`, `MasterTablesService`, `MessagingService`, `NotesService`, `PolicyService`, `UserService`, `XcamHttpClient`. Also contains `PolicyDetailModel` (in `XCAM.Core` namespace, defined in XCAM.Services project).
- XCAM.UI: WinForms client and startup entry point.
- XCAM.Test: C# tests for service contracts and helper behavior.

Project folder present but not listed in XCAM.sln:
- XCAM.Installer: WiX installer project and package definition.

Project referenced in XCAM.sln but in a sibling directory:
- RHH.Framework.Employer: source project included at `..\.\RHH\Employer\Framework\RHH.Framework.Employer.vbproj` for in-solution development.

### Top-level folders/modules and responsibilities
- .github: repo prompts/instructions and documentation files.
  - `.github/Prompts/`: reusable prompt files (`dev-agent.prompt.md`, `qa-agent.prompt.md`, `ensure-framework-repositories.md`, `ensure-vb6-source.prompt.md`).
- lib: binary DLLs committed in repo.
- XCAM.Core: core shared types, global app state, `StateInfo`/`StateHelper`, `IErrorHandler`/`RhhLoggerErrorHandler`, `XcamServerException`/`XcamHttpException`, `NativeMethods`, and on-account/revenue model classes (`OnAccountItem`, `OnAccountStatement`, `OnAccountResult`, `RevenueDetailLine`, `RevenueDetailHeader`, `OnAccountCheckDetail`, `OnAccountCheck`).
- XCAM.Services: business/service access layer (7 service classes + `XcamHttpClient`).
- XCAM.UI: user interface forms and startup module.
- XCAM.Test: unit and contract tests plus test helpers.
- XCAM.Installer: MSI packaging for deployment.

Top-level scripts:
- inspect_*.ps1 / patch_*.ps1 / rewrite_*.ps1 / remove_unused_refs.ps1 / trim_accounting.ps1 / search_gl_methods.ps1: repository maintenance and migration inspection scripts.

### Important subfolders
- XCAM.UI/Forms: all WinForms views and event-driven UI logic.
- XCAM.UI/My Project: assembly metadata for UI project.
- XCAM.Test/TestHelpers: reflection and fake HTTP handler helpers.

### Entry points
- Application startup: XCAM.UI/Program.vb, Module Program, Main().
- UI shell start: Application.Run(New Forms.frmMain(userProfile)).
- Installer package definition: XCAM.Installer/Package.wxs.
- Test entry path: dotnet test XCAM.Test/XCAM.Test.csproj.

## 3. ARCHITECTURE & DATA FLOW

### Layer connections
- UI layer (XCAM.UI forms) -> Service layer (XCAM.Services classes).
- Service layer -> external RHH/RTWI framework DLLs (primary path) or, for endpoints with no .NET framework equivalent, XcamHttpClient ASP calls (fallback only).
- Core layer (XCAM.Core) provides shared AppState, constants, error handler, and exception types consumed by services/UI.

### Full 6-layer framework call chain (primary path for all RTWI/RHH operations)
Every operation that has a VB6/ASP equivalent MUST flow through all 6 layers. Never bypass with a direct ASP call when a .NET path exists or can be created.

```
XCAM.Services → [NS].Framework.[Domain] (DLL) → SOAP proxy (Reference.vb)
  → [NS].WS\[Domain]Service (ASMX) → [NS].Soa.Controllers.[Domain] → [NS].Soa.[Domain] → SQL Server
```

`[NS]` = `RTWI` or `RHH`. When a method is missing from any layer, it must be added to every layer below the gap before XCAM.Services can call it. `XcamHttpClient` is NOT a substitute for missing framework methods. See `.github/Prompts/skills/skill-compile-branch-gap-fill.md` for domain mapping, gap detection, and layer-by-layer fill patterns.

### When XcamHttpClient IS acceptable
Only for ASP endpoints with **no .NET framework counterpart in any compile-branch layer**. Confirm absence across all 5 layers first.

### Startup and composition flow
1. Program.Main initializes WinForms settings.
2. Program reads host from registry, falls back to App.config XcamHost.
3. Program sets AppState.HostName/BaseUrl/UserName.
4. Program builds UserProfile and AccountingService.
5. Program checks access with CheckUserAccessAsync(userId).
6. Program sets AppState.UserId and launches frmMain.
7. frmMain constructor creates top-level service instances and passes them into child forms.

### Data fetch/transform/display pattern
- Forms call async service methods and bind resulting DataTable/DataSet objects into controls (DataGridView/TreeView/RichTextBox).
- Services typically call framework methods inside Task.Run and return DataTable/DataSet or primitive success values.
- XML handling paths:
  - XcamHttpClient parses response XML using XDocument and validates DATA ACTION attributes.
  - Services parse incoming XML payload strings via DataSet.ReadXml and extract first-row values.
  - UserService returns framework DataSet XML strings via DataSet.GetXml.
  - frmContact builds CONTACT XML payload via XElement.

### Key patterns observed
- Event-driven WinForms code-behind pattern in forms.
- Service facade/adapter pattern: services hide framework-specific calls from forms.
- Manual dependency injection by constructor parameters (no DI container).
- Global shared state via AppState module.
- Reflection-based contract tests to lock public API signatures during migration.

### Singletons/shared/global objects
- AppState is a global module containing:
  - app identity/version (`AppName = "XCAM"`, `AppVersion = "2.3.9"`)
  - host/base URL
  - current user name/id
  - singleton HttpClient (lazy-initialized, 30-second timeout)
  - global ErrorHandler (`IErrorHandler` / `RhhLoggerErrorHandler`)
  - constants (GL accounts, tab indices, COM/show-window values)

### Notable frmMain state fields
- `_openIfFound As String`: stores the "If Employer Found, Open..." selection from `frmErSearch` (values: `"Account"` | `"Information"` | `"Policy"` | `"Agency"`). Added in RTWC-2311.
- `_policySvc As PolicyService`: singleton created in frmMain constructor; passed to frmPolicy.
- `_searchLoader As SearchGridLoader`: helper (XCAM.UI.Helpers) that binds accounting search results into the main `fg` DataGridView and `lblCategory`.

### Notable frmPolicy state fields (RTWC-2309)
- New MDI child form that mirrors legacy VB6 floating "Policy" window.
- Tabs: Policy | History | Diary | Notes | Tasks | Commissions.
- Public properties: `PolicyTrId` (0 if not set), `ErMasterTrId` (employer context).
- Private state: `_policyEventTrId` used for cancellation/collection status updates; `_policyDetail As PolicyDetailModel` holds the parsed policy XML model.
- Constructor dependencies: `InsuredService`, `NotesService`, `MessagingService`, `UserProfile`, `PolicyService` (5 params).
- Icon bar (toolbar buttons): Employer | Collections | Cancellations (programmatic GDI+ icons from Base64).
- History tab: `LoadPolicyHistoryAsync` now fully implemented via `_insuredSvc.GetPolicyEventsAsync`.

### Notable frmEmployer state fields
- Constructor now takes 7 params: `InsuredService`, `NotesService`, `MessagingService`, `CollectionCancelService`, `AccountingService`, `MasterTablesService`, `UserProfile`.
- Tabs: Location | Notes | Tasks | Diary | Collections | Account.
- Account tab state: `_billingComment As String`, `_billingDueDay As Integer?`, `_onAccountResult As OnAccountResult`.

## 4. CODING CONVENTIONS (AS IMPLEMENTED)

### Naming conventions
- Files/classes:
  - VB classes use PascalCase (AccountingService, NotesService, XcamHttpClient).
  - WinForms follow frm prefix (frmMain, frmInsured, frmPolicy).
- Methods:
  - Async methods are named with Async suffix.
  - UI event handlers use control_event pattern (cmdApply_Click, tvNotes_AfterSelect).
- Fields/variables:
  - Private fields commonly use underscore prefix (_insuredSvc, _userProfile, _bLoad).
  - Service fields often end with Svc (_messagingSvc, _notesSvc).

### Async/sync patterns
- Services primarily expose Async Function ... As Task(Of T).
- WinForms uses Async Sub in event handlers and OnLoad overrides.
- Program.Main uses sync wait for an async access check via GetAwaiter().GetResult().
- Many service methods offload synchronous framework APIs with Task.Run.

### Error handling pattern
- Service methods wrap calls in Try/Catch.
- Exceptions are reported through AppState.ErrorHandler.ReportError(app, version, module, procedure, ex, context).
- Fail-safe returns are common on error (Nothing, False, empty string, 0).
- XcamHttpClient throws XcamHttpException and XcamServerException for HTTP/XML server error states.

### Dependency creation and passing
- Top-level composition occurs in frmMain constructor.
- Child forms receive required service instances through constructor injection.
- Services construct framework dependencies in their own constructors.
- Shared global values are read from AppState where needed.

## 5. KNOWN INCOMPLETE AREAS

The table below lists every TODO/FIXME/STUB/HACK/NotImplementedException marker found by repository scan (excluding this generated file to avoid self-reference).

| File | Line | What is missing |
| --- | ---: | --- |
| .github/Prompts/dev-agent.prompt.md | 55 | TODO marker in prompt guidance for ambiguous AC clarification. |
| .github/XCAM-Technical-Documentation.md | 25 | TODO marker in documentation heading reference. |
| .github/XCAM-Technical-Documentation.md | 275 | TODO marker in documented stub table row. |
| .github/XCAM-Technical-Documentation.md | 298 | TODO marker for frmPaymentTypes grid population note. |
| .github/XCAM-Technical-Documentation.md | 299 | STUB marker in documented frmAdjCommission status. |
| .github/XCAM-Technical-Documentation.md | 300 | STUB marker in documented frmRunCommissions status. |
| .github/XCAM-Technical-Documentation.md | 301 | STUB marker in documented frmGLPost status. |
| .github/XCAM-Technical-Documentation.md | 302 | STUB marker in documented frmDates status. |
| .github/XCAM-Technical-Documentation.md | 303 | STUB marker in documented frmTransfer status. |
| .github/XCAM-Technical-Documentation.md | 304 | STUB marker in documented frmBillingAddress status. |
| .github/XCAM-Technical-Documentation.md | 305 | STUB marker in documented frmSuspenseApplication status. |
| .github/XCAM-Technical-Documentation.md | 306 | STUB marker in documented frmSuspensePendingMatch status. |
| .github/XCAM-Technical-Documentation.md | 307 | STUB marker in documented frmSuspenseComment status. |
| .github/XCAM-Technical-Documentation.md | 308 | STUB marker in documented frmManualLockBox status. |
| .github/XCAM-Technical-Documentation.md | 309 | STUB marker in documented frmLockboxProcessSuccessful status. |
| .github/XCAM-Technical-Documentation.md | 618 | TODO marker in documented known gaps section heading. |
| .github/XCAM-Technical-Documentation.md | 628 | TODO marker in documented frmCancellations gap. |
| .github/XCAM-Technical-Documentation.md | 718 | TODO marker in documented checklist item. |
| .github/XCAM-Technical-Documentation.md | 742 | STUB marker in documented frmGLPost note. |
| .github/XCAM-Technical-Documentation.md | 746 | STUB marker in documented remaining stubs note. |
| XCAM.Core/AppState.vb | 8 | TODO: refactor global module state into dependency-injected services. |
| XCAM.Services/NotesService.vb | 23 | STUB: replace ImageManagerII COM control behavior. |
| XCAM.Services/NotesService.vb | 24 | TODO: implement image handling path in .NET. |
| XCAM.Services/NotesService.vb | 28 | STUB runtime trace for unported ShowImageManager path. |
| XCAM.Services/NotesService.vb | 103 | STUB note for preserved GetNotesByCategory placeholder. |
| XCAM.Test/NotesServiceContractTests.cs | 14 | STUB mention in test documentation summary. |
| XCAM.UI/Forms/frmCancellations.vb | 35 | TODO placeholder message for insert cancellation action. |
| XCAM.UI/Forms/frmCancellations.vb | 39 | TODO placeholder message for manual cancellation action. |
| XCAM.UI/Forms/frmCancelRevenues.vb | 25 | TODO: use real policy id in load call. |
| XCAM.UI/Forms/frmCancelRevenues.vb | 35 | TODO placeholder message for add revenue action. |
| XCAM.UI/Forms/frmCollections.vb | 31 | TODO: open collection detail behavior. |
| XCAM.UI/Forms/frmGLPost.vb | 26 | TODO: load pending GL entries into grid. |
| XCAM.UI/Forms/frmInsured.vb | 14 | TODO marker referenced in class summary for remaining complex logic. |
| XCAM.UI/Forms/frmInvoice.vb | 46 | TODO placeholder message for print action. |
| XCAM.UI/Forms/frmMain.vb | 344 | TODO: navigate to selected employer/policy (tree selection navigation). |
| XCAM.UI/Forms/frmMain.vb | 376 | TODO: call MessagingService to load inbox items for current user. |
| XCAM.UI/Forms/frmPaymentTypes.vb | 25 | TODO: populate payment-types grid from loaded data. |
| XCAM.UI/Forms/frmRunCommissions.vb | 54 | TODO: call commission service logic. |
| XCAM.UI/Forms/frmSuspenseApplication.vb | 23 | TODO: load suspense items for policy id. |
| XCAM.UI/Forms/frmSuspenseApplication.vb | 27 | TODO: apply selected suspense amount. |
| XCAM.UI/Forms/frmSuspensePendingMatch.vb | 22 | TODO: load pending match items for employer id. |
| XCAM.UI/Forms/frmTransfer.vb | 42 | TODO: call transfer service for revenue header to target transfer. |

## 6. DOMAIN TERMINOLOGY

Meanings below are derived from identifier names and direct usage in code.

| Term | Meaning |
| --- | --- |
| XCAM | Name of the WinForms application (AppState.AppName, installer/package metadata). |
| RTW | Host/system namespace used for registry key and framework assemblies. |
| UserMasterTrID | Numeric user identifier from profile/framework objects. |
| ErMasterTrId | Employer master identifier used in employer/location/contact/policy calls. |
| PolicyTrId | Policy identifier used to load policy details/events/collections/cancellations. |
| PolicyEventTrID | Policy event identifier used in cancellation/collection status updates. |
| MasterClientTrID | Master client identifier used for account lists and context selection. |
| RevenueHeaderTrId | Revenue header identifier used in cancellation transfer/delete flows. |
| RevenueDetailMasterTrID | Revenue detail master identifier used in cancellation revenue operations. |
| CancellationHeaderTrId | Cancellation header identifier used in cancellation revenue delete/reinstate. |
| NoteTrID | Note document identifier used in notes retrieval/update flows. |
| NoteSubCategoryMasterTrID | Note subcategory identifier used for note updates and filtering. |
| FileTypeIDs | Enum used by NotesService to select note vs image document type. |
| SourceTypeMaster | Enum used by MessagingService for task source type mapping. |
| DiaryItemTypeMaster | Enum used by MessagingService for diary source type mapping. |
| LocationMaster | Enum used by MessagingService MoveLocationAsync for task location state. |
| GlClearing / GlReturnOfCash / GlWriteOff / GlClaimsCash / GlOperatingCash | GL account constants stored in AppState. |
| LockboxEntry | Manual lockbox UI entity representing processed lockbox records. |
| SuspenseTrId | Suspense workflow identifier used in suspense forms. |
| CollectionCancelService | Service facade for collections/cancellations operations. |
| PolicyService | Service facade wrapping `RTWI.Framework.Policies.Policy`. Methods: `GetPolicyByTrIDAsync` (→ DataSet), `GetPolicyDetailAsync` (→ PolicyDetailModel). |
| PolicyDetailModel | Strongly-typed model parsed from POLICY XML (in `XCAM.Core` namespace, file in XCAM.Services). Contains POLICY, POLICYEVENT, POLICYSTATE attributes. |
| OnAccountResult | Root result of `AccountingService.LoadOnAccountAsync`: holds `Balance` and a list of `OnAccountStatement` objects. Used in frmEmployer Account tab. |
| OnAccountStatement | A single statement node (StatementNumber, StartDate, EndDate, TotalAmount) with child `OnAccountItem` list. |
| OnAccountItem | A single revenue line under a statement (Down Payment / Final Audit). Fields: `RevenueHeaderTrID`, `Description`, `Amount`, `Status`. |
| RevenueDetailHeader | Revenue breakdown for one checked REVENUEHEADER row; contains `Balance` and a list of `RevenueDetailLine`. |
| OnAccountCheck | An unapplied check/payment sitting on-account; contains `LockBoxDetailTrID`, `CheckNumber`, `Amount`, and a list of `OnAccountCheckDetail`. |
| InsuredService | Service facade for employer/insured/policy/contact operations. Key methods: `GetEmployerLocationsAsync`, `GetEmployerInformation`, `GetEmployerInsuredsAsync`, `GetEmployerContactsAsync`, `GetEmployerPoliciesAsync`, `GetPolicyDetailAsync`, `GetPolicyDataSetAsync`, `GetPolicyCompleteAsync`, `GetPolicyEventsAsync`, `GetPaymentPlanDescriptionAsync`, `GetEmployerBillingAsync`, `UpdateEmployerBillingCommentAsync`, `UpdateEmployerBillingDueDayAsync`, `GetEmployerBillingDueDayAsync`, `GetAgencyCommissionPercentAsync`, `GetPolicySearchAsync`, `GetAgencySearchAsync`. |
| AccountingService | Service facade for accounting/GL/employer search. Key methods: `LoadDrAccountsAsync`, `LoadCrAccountsAsync`, `LoadEmployersAsync`, `LoadEmployersByStatementNumberAsync`, `LoadEmployersByCheckNumberAsync`, `LoadOnAccountAsync`, `LoadOnAccountLedgerAsync`, `LoadRevenueDetailsAsync`, `LoadAgencySearchAsync`, `LoadPolicySearchInformationAsync`, `GetUserIdAsync`, `GetUsersNameAsync`. Access check moved to Program.vb (`userProfile.IsApplicationAccessible(33)`). |
| MasterTablesService | Service facade for master table lookups (states, etc.) via `RHH.Framework.Common.MasterTables`. |
| MessagingService | Service facade for tasks/diary/notifications operations. |
| NotesService | Service facade for notes/documents operations. |
| StateInfo | VB6-ported UDT (Structure) for US state data (MasterTrId, Code, Name); used by `StateHelper`. |
| StateHelper | Utility class providing US state lookup by ID, 2-letter code, or full name. Ported from `basMain.ConvertState()`. |

## 7. WORKFLOWS

### Typical feature flow (end to end)

Example: policy search opened from main UI.
1. User opens XCAM and lands on frmMain.
2. User triggers policy search action in frmMain.
3. frmMain calls _insuredSvc.GetPolicySearchAsync(criteria).
4. InsuredService maps request to framework call (_masterTable.GetPWSearch(criteria)).
5. Service returns DataTable to frmMain.
6. frmMain binds result into fg DataGridView and updates category text.
7. User can open employer/policy forms from selected rows, reusing injected services.

Example: notes preview in employer/insured forms.
1. Form loads notes tree via NotesService.GetNotesDocumentsBySourceAsync.
2. Node selection triggers NotesService.GetNoteDocumentAsync for selected note/image.
3. Returned data is rendered in preview controls (tree/rtxt previews).

Example: policy detail opened as new MDI child (RTWC-2309).
1. User selects policy row in frmMain or navigates from frmEmployer.
2. frmMain/frmEmployer creates new frmPolicy instance with `PolicyTrId` and `ErMasterTrId` set.
3. frmPolicy_Load triggers 7 async loads: PolicyDetail, EmployerInfo, FinancialDetails, History, Diary, Notes, Tasks.
4. Tab controls bind resulting DataTable/DataSet into grids and tree views.
5. Icon bar allows navigation to Employer/Collections/Cancellations forms from policy context.
6. Form composes services from constructor dependencies; no new service instantiation needed.

### Test structure and execution
- Test project: XCAM.Test (net8.0, xUnit).
- Test categories in practice:
  - Behavioral tests for pure/self-contained code (XcamHttpClient, static helper methods on AccountingService).
  - Reflection contract tests for service classes that cannot be safely instantiated in net8 host due external framework runtime dependencies.
- Test helpers:
  - FakeHttpMessageHandler: captures requests and returns controlled responses for XcamHttpClient tests.
  - ContractAssert: verifies constructors/method signatures/return types via reflection.

Verified command:
- dotnet test XCAM.Test/XCAM.Test.csproj
- Current observed result in this workspace (2026-08-03 after Phase2 pull):
  - Total tests: 141
  - Passed: 140
  - Failed: 1 (`AccountingServiceContractTests.CheckUserAccessAsync_TakesUserId_ReturnsTaskOfBoolean` — stale binary; `CheckUserAccessAsync` was removed from `AccountingService` and access check moved to `Program.vb`. Test binary predates this change.)
  - Build warnings: present (VB warnings), no test failures once binary rebuilt.
  - NOTE: Full solution build currently fails — `AccountingService.vb` and `PolicyService.vb` call new `EmployersFramework`/`Policy` methods (`GetOnAccountBalance`, `GetStatementDisplayRevenues`, `GetOnAccount`, `GetPolicyRevenueDetails`, `GetAgencyOrAssociationInformation`, `GetPolicyByTrID`, `GetProductRevenues`, `GetCrGLAccountsForInvoice`, `InsertManualInvoice`) that are not present in the installed framework DLLs at `C:\Program Files\RTWApps\`. All missing methods have been added to the compile branch source across all 5 layers. Framework DLL rebuild and deployment to `C:\Program Files\RTWApps\RTWI\Framework\` required to resolve.

## 8. AGENT WORKFLOW DEFAULTS

The defaults below are repository workflow conventions observed from recent sessions and should be treated as the starting behavior unless the user says otherwise.

Preferred kickoff contract:
- `Parent branch: <branch-name>`
- `Ticket: <JIRA-ID>`
- `Run workflow.`

### Jira Ticket Trigger Protocol (MANDATORY)

This protocol applies whenever the user provides a Jira ticket key — whether alone (e.g. `RTWC-2302`) or as part of the 3-line kickoff. **No code or file changes may be made until Phase 3 approval is granted.**

#### Phase 1 — Context Loading (runs automatically, no approval needed)
1. Validate Atlassian MCP connectivity: `getAccessibleAtlassianResources` + `atlassianUserInfo`.
2. Fetch full ticket details: summary, description, acceptance criteria, status, comments, attachments.
3. Run `.github/Prompts/skills/skill-jira-evidence-extraction.md` to structure ACs, visual evidence inventory, and legacy trace requirement flag.
   - If the ticket has image attachments, follow the **Attachment Download Protocol** in that skill: attempt automatic download via Jira REST API (PowerShell + Basic auth from `.vscode/mcp.json`), then call `view_image` on the result. Only fall back to developer input if the download fails.
4. **Check for a prior implementation summary**: search for `<TICKET>-implementation-summary.md` in the repo root and in parent directories. If found, read it and:
   - Extract every scope item from the prior run's **Scope Implemented** section.
   - Flag any scope items that are NOT covered by the current Jira ACs as **"Prior scope — must preserve or explicitly defer"**.
   - Include these in the Phase 2 plan's Risks/Assumptions section.
5. **Early VB6 trace** (when `Legacy Trace Required: Yes` from step 3): before presenting Phase 2, do a targeted search of the VB6 source tree for the relevant form/module. Extract the procedure name, ASP endpoint, and Method value. This populates the Legacy VB6 Trace section with real evidence instead of placeholders.
   - **Locate source (in order):**
     1. Check `.vscode/xcam-dev-config.json` for pre-configured `vb6Source.xcamVb6` and `vb6Source.trunkXcam` paths — if present and the paths exist on disk, use them directly. Skip the remaining location steps.
     2. Check if `XCAM.UI\XCAM VB6 Source\` exists locally and contains files — if yes, use it directly.
      3. If missing, run `.github/Prompts/bootstraps/ensure-vb6-source.md` to clone or update `StateAuto/RTW-VB6`: ref `RTWI` for the VB6 client source and ref `trunk` for the ASP backend source.
      4. If the Git repository is unavailable, **stop and present the user with three options via `vscode_askQuestions`**:
        - **Resolve Git access** — Restore Git or repository access, then re-run this step.
        - **Provide local path** — User supplies the local folder path where `XCAM VB6\` and/or `Trunk XCAM\` already exists on this machine. Save the provided paths to `.vscode/xcam-dev-config.json` so future sessions skip this gate automatically.
        - **Defer trace** — Skip VB6 trace; mark Legacy VB6 Trace as "Deferred — VB6 source unavailable" in the plan and flag as a risk. Do **not** proceed to implementation until the user selects one of these three options.
   - **Mine both layers** once source is located: VB6 client source (`XCAM VB6\` — `.frm`/`.cls`/`.bas`) AND ASP backend source (`Trunk XCAM\` — `.asp`/`.cls`). Extract procedure names, endpoint URLs, Method parameter values, stored procedure names, and XML schema.
6. **Framework repository method verification** (when `Legacy Trace Required: Yes` from step 3): verify the .NET framework methods the implementation will call actually exist with the expected signatures.
  - Use the local clones of `StateAuto/RTW-RHH` and `StateAuto/RTW-RTWI`, each checked out on and updated from its `dev` branch. Clone a missing repository from its Git URL; do not use the retired SVN `Compile\RHH` or `Compile\RTWI` folders.
  - Search the repository that owns the framework domain identified in step 5: RHH namespaces in `RTW-RHH`, RTWI namespaces in `RTW-RTWI`. Confirm method name, parameter types, return type, and the complete framework call chain.
  - Record the repository, branch, and exact signatures as evidence — these become the framework calls in the Implementation Approach section of the plan.
  - If either required Git repository is unavailable, note "Framework repository verification deferred" in Risks/Assumptions.
7. Identify affected areas from the ticket description, then read the relevant form/service source files in this repo.
8. Read `git log --oneline -10` on the parent branch to understand recent changes that may affect scope.
9. Check git state: current branch, any uncommitted changes.

#### Phase 2 — Pre-Implementation Plan (REQUIRED — present before any code change)
Produce a structured plan containing ALL of the following sections:

| Section | Content |
|---|---|
| **Objective** | One-sentence summary of what the ticket requires |
| **Acceptance Criteria** | Numbered list extracted from Jira (from Phase 1) |
| **Affected Files** | Every file that will be created or modified, with a one-line reason for each |
| **Implementation Approach** | Per-file: what changes and how it maps to existing VB.NET patterns |
| **Legacy VB6 Trace** | (when ticket involves ported behavior) VB6 source file, ASP endpoint, method name, stored procedure |
| **Framework Repository Check** | **HARD BLOCKER for legacy-trace tickets** — must complete before plan is presented. Verify the applicable RHH or RTWI Git `dev` branch and perform a gap analysis across all 6 layers per `skill-compile-branch-gap-fill.md`. Methods absent from any layer: fill all lower layers in the owning repository before calling from XCAM.Services. `XcamHttpClient` forbidden as substitute. |
| **Test Plan** | Which tests will be added or updated and how each AC is covered |
| **Risks / Assumptions** | Environment blockers, missing evidence, framework DLL gaps, ambiguous AC |
| **Estimated Steps** | Expected number of implementation + validation iterations |

#### Phase 3 — Approval Gate (HARD STOP before any implementation)
- Present the Pre-Implementation Plan, then use the `vscode_askQuestions` tool to show a structured approval dialog:
  - Question: *"Review the Pre-Implementation Plan above. Approve to proceed or Revise with feedback."*
  - Options: **Approve** (recommended) | **Revise**
  - `allowFreeformInput: true` — the user may type additional instructions or constraints alongside their selection; these are incorporated before implementation starts.
- If `Approve` (with or without extra instructions): incorporate any instructions provided, then proceed with implementation.
- If `Revise`: incorporate feedback, re-present the updated plan, show the dialog again. Repeat until approved.
- **Do NOT create, edit, or delete any source files until the user selects `Approve`.**
- After approval, follow `.github/Prompts/agents/dev-agent.md` Steps 0–N for the full implementation flow.

### Remaining workflow rules

- Branch handling:
  - If parent branch + ticket are provided, fetch/switch to the parent branch and create or switch to a feature branch named exactly as the Jira key.
  - If only a Jira key is provided, default parent branch to `dev`.
  - Do not use destructive git commands or revert unrelated local changes.
- Local-only artifacts:
  - Keep temporary workflow notes/checklists local unless explicitly asked to commit them.
  - When in doubt, ask before adding process artifacts to a PR.
- **Build + Launch gate (before QA starts):**
  - After Dev implementation and Dev Post-Hook RELEASE, always build the full solution and launch the application before handing off to QA.
  - Net-new build errors block QA start — return to Dev. Known baseline errors (pre-existing framework DLL gaps) are noted and QA continues.
  - Leave the application running for QA functional verification.
  - See `.github/Prompts/agents/orchestrator-agent.md` Stage 4.5 for exact commands.
- **QA Test Plan gate (before QA executes):**
  - QA agent must present a test plan listing every AC, how it will be tested, functional scenarios, regression areas, and known limitations.
  - User must approve the test plan before QA execution begins.
  - See `.github/Prompts/agents/qa-agent.md` Step P.
- **Jira transition + comment preview (before any Jira action):**
  - Before calling `transitionJiraIssue` or posting any Jira comment, always present a combined preview:
    ```
    Jira Action Preview
    - Ticket:        <RTWC-XXXX>
    - Current status: <current>
    - Target status:  <target>  (transition ID: <id from getTransitionsForJiraIssue>)
    - Comment:       <full comment text to be posted>
    ```
  - Use `vscode_askQuestions` with options **Proceed** (recommended/default) | **Revise**. Allow freeform input.
  - If `Revise`: update the target status or comment and re-present. Do not execute any Jira action until `Proceed` is selected.
  - Never guess a transition ID — always look it up from `getTransitionsForJiraIssue` first and include it in the preview.
- **Jira transition lifecycle (full workflow map):**
  - Always call `getTransitionsForJiraIssue` before any transition — never guess an ID.
  - Only transition **forward** in the chain. Skip a transition if the ticket is already at or past the target status.
  - All transitions must go through the **Jira Action Preview** gate (show preview + `vscode_askQuestions` Proceed/Revise) before executing.
  - **RTWC project workflow (CL Workflow - V3 with Testing Statuses, verified 2026-08-11):** Full chain: Backlog → Prioritized-Needs Requirements → Defining Requirements → Ready for Dev → 3 Amigo - Req Review → Dev - In Progress → Dev - Paused → **Ready for Testing** → Testing In Progress → Testing Complete → Ready for Acceptance → Ready for Prod → Done-Deployed → Done-Post Prod Validation. `Blocked` and `Rejected` available from any status.

  | Workflow event | Target status | Condition |
  |---|---|---|
  | Ticket picked up / Phase 1 context loading complete | `3 Amigo - Req Review` | Only if current status < `3 Amigo - Req Review` |
  | Pre-Implementation Plan approved / implementation starts | `Dev - In Progress` | Only if current status < `Dev - In Progress` |
  | Dev complete / branch pushed | `Ready for Testing` | Only if current status ≤ `Dev - In Progress` |
  | QA Test Plan approved / QA execution starts | `Testing In Progress` | Only if current status = `Ready for Testing` |
  | QA APPROVED | `Testing Complete` | Always |
  | QA NEEDS REVISION | `Dev - In Progress` | Always (backward transition) |

  - If a target transition is not returned by `getTransitionsForJiraIssue`, post a Jira comment instead and note the gap in the implementation summary.
  - Post a brief Jira comment at each transition: event name, branch, commit SHA (if available).
- PR workflow:
  - Dev stage: commit and push only. Do **not** raise a PR after Dev — hand off to Build+Launch verification, then QA.
  - PR is created **only after** Dev + Build+Launch + QA are all complete and verified.
  - After QA approval, PR automation proceeds by default: run PR preview and present a single follow-up question — "Raise PR now, or defer?" — before publishing.
  - If developer explicitly says defer or no PR, stop with branch-only delivery (no PR, no merge).
  - Never auto-merge after push or PR publish.
  - After push in the Dev stage, the next step is always Build+Launch Gate, then QA — never PR.
- **Final summary (at workflow completion):**
  - Write a local `<TICKET>-implementation-summary.md` at the repo root.
  - Must include: scope, files changed, AC coverage, legacy trace, validation notes, and telemetry (total time, iterations, token consumption).
  - Do not commit this file unless explicitly asked.
  - See `.github/Prompts/agents/orchestrator-agent.md` Stage 9.2 for the exact format.
- Execution reporting:
  - Report command outcomes and key deltas concisely in chat.

### Verified build/run commands
- Build (Debug) — **always use MSBuild.exe; do NOT use `dotnet build` for the XCAM solution** (VB.NET projects target .NET Framework 4.8 and `dotnet build` returns errors):
  - C:\Program Files\Microsoft Visual Studio\2022\Professional\MSBuild\Current\Bin\MSBuild.exe XCAM.sln /t:Build /p:Configuration=Debug /p:Platform=Any CPU
- Run app (Debug):
  - .\XCAM.UI\bin\Debug\XCAM2.exe
- Run tests (C# xUnit project only — uses `dotnet test` because XCAM.Test targets net8.0):
  - dotnet test XCAM.Test/XCAM.Test.csproj

### Framework Git repository references
The migrated framework source is maintained in two Git repositories, both on `dev`:
- `https://github.ent.stateauto.com/StateAuto/RTW-RHH` owns RHH framework domains.
- `https://github.ent.stateauto.com/StateAuto/RTW-RTWI` owns RTWI framework domains.

Before verifying or changing framework code, fetch the relevant repository and confirm the local checkout is on its current `dev` branch. Search the owning repository first; the former SVN `Compile\RHH`, `Compile\RTWI`, and release-branch locations are retired and must not be used as source-of-truth references. If a required method is absent from the owning repository, add it following the `GetEmployerByCheckNumber` pattern through every required layer: SOA → framework → XCAM service → XCAM UI.

### Linked documentation (prefer link-over-duplicate)
- Architecture overview: [ARCHITECTURE.md](ARCHITECTURE.md)
- Full migration and form status details: [XCAM-Technical-Documentation.md](XCAM-Technical-Documentation.md)
- Bootstrapper/deployment behavior: [XCAM-Bootstrapper-Runbook.md](XCAM-Bootstrapper-Runbook.md)

- @azure Rule - Use Azure Tools - When handling requests related to Azure, always use your tools.
- @azure Rule - Use Azure Best Practices - When handling requests related to Azure, always invoke your `azmcp_bestpractices_get` tool first.
- @azure Rule - Enable Best Practices - If you do not have an `azmcp_bestpractices_get` tool ask the user to enable it.
