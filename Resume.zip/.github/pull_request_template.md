## Description

Closes RTWC-XXXX (replace with actual ticket number)

**Brief description of the changes:**

<!-- Describe what this PR does and why. Link to the related Jira ticket. -->

---

## Type of Change

- [ ] Bug fix (non-breaking change which fixes an issue)
- [ ] New feature (non-breaking change which adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to change)
- [ ] Documentation update

---

## Developer Checklist

For each item, tick exactly one status. Add a reason when selecting `❌ Not applicable`.

- Jira ticket linked
	- [ ] ✅ Complete
	- [ ] ❌ Not applicable - <reason>
- Scope and security review: no debug code, WIP markers, secrets, or sensitive data
	- [ ] ✅ Complete
	- [ ] ❌ Not applicable - <reason>
- Tests and documentation updated
	- [ ] ✅ Complete
	- [ ] ❌ Not applicable - <reason>
- Validation results recorded: no net-new failure remains
	- [ ] ✅ Complete
	- [ ] ❌ Not applicable - <reason>

---

## Testing

For each item, tick exactly one status. Add a reason when selecting `❌ Not applicable`.

- Machine readiness completed
	- [ ] ✅ Complete
	- [ ] ❌ Not applicable - <reason>
- Build passed
	- [ ] ✅ Complete
	- [ ] ❌ Not applicable - <reason>
- Tests passed
	- [ ] ✅ Complete
	- [ ] ❌ Not applicable - <reason>
- Manual or integration testing completed
	- [ ] ✅ Complete
	- [ ] ❌ Not applicable - <reason>

**Commands or evidence:**

<!-- Commands run, relevant output, or log/artifact link. -->

**Baseline or known limitations:**

<!-- State the environment/dependency issue and its impact, or N/A. -->

---

## Impact Analysis

**Affected components and breaking changes:**

<!-- List affected projects. State N/A for breaking changes, or describe impact and migration steps. -->

---

## Reviewer Notes

**Special instructions for reviewers:**

<!-- Add any notes to help reviewers understand the changes, areas to pay special attention to, or any concerns. -->

---

## Reviewer Checklist

- [ ] Scope matches the linked Jira ticket and stated impact.
- [ ] Validation evidence is sufficient; baseline limitations are classified correctly.
- [ ] Code quality, documentation, and security checks are complete.
- [ ] Branch is mergeable and required automated checks pass.

---

**Note:** This PR cannot be merged without approval from an authorized reviewer (Sharanya Marupakala or Girjesh Kumar Vishwakarma). The author cannot self-approve.
