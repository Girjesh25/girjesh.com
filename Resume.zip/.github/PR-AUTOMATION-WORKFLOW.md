# PR Automation Workflow

This workflow keeps implementation local until commit/push is complete, then allows PR automation with an approve/revise gate.

## Standard flow

1. Implement ticket locally.
2. Commit to feature branch.
3. Push feature branch.
4. Run PR preview (no PR created):

```powershell
pwsh ./scripts/automation/create-pr.ps1 -Ticket RTWC-XXXX -Mode Preview -BaseBranch dev
```

5. Review preview output and PR body file.
6. Approve, revise, or defer:
- Approve: publish PR.
- Revise: edit title/body and re-run preview.
- Defer: keep branch pushed only and stop without PR.

### Mandatory publish approval gate

Before publishing (`-Mode Publish`), present this checkpoint and wait for explicit user approval:
- Base and head branch
- Final PR title
- Final PR body content (or body file path + rendered preview)
- PR file scope preview (`gh pr diff --name-only` or equivalent preview output)

Allowed decisions:
- `Approve`: proceed to publish.
- `Revise`: update title/body/scope and return to preview.

Do not publish until an explicit `Approve` is received.

7. Publish PR only after approval:

```powershell
pwsh ./scripts/automation/create-pr.ps1 -Ticket RTWC-XXXX -Mode Publish -BaseBranch dev
```

## Optional arguments

- Draft PR:

```powershell
pwsh ./scripts/automation/create-pr.ps1 -Ticket RTWC-XXXX -Mode Publish -BaseBranch dev -Draft
```

- Explicit head branch:

```powershell
pwsh ./scripts/automation/create-pr.ps1 -Ticket RTWC-XXXX -Mode Preview -BaseBranch dev -HeadBranch RTWC-XXXX
```

- Explicit title/body file:

```powershell
pwsh ./scripts/automation/create-pr.ps1 -Ticket RTWC-XXXX -Mode Preview -Title "[RTWC-XXXX] My title" -BodyFile .github/pr-drafts/RTWC-XXXX-pr.md
```

## Notes

- Preview mode never creates a PR.
- Publish mode requires GitHub CLI authentication.
- If .github/RTWC-XXXX-implementation-summary.md exists, it is used as PR body by default.
- Automated PR bodies must include the template's clickable Developer Checklist and Testing task lists.
- For every checklist criterion, generate two task-list choices: `✅ Complete` and `❌ Not applicable - <reason>`. Check exactly one. A not-applicable result must explain whether it is a baseline limitation or does not apply to the PR scope.
- Never auto-merge after PR creation. Merge is a separate explicit decision.
