---
name: "Jira Evidence Extraction"
description: How Dev/QA agents pull acceptance criteria and visual evidence from a Jira ticket consistently
when-to-use: "Step 1 of Dev Agent and Step 1/1.1 of QA Agent, or any agent that needs a ticket's testable requirements"
---

# Skill: Jira Evidence Extraction

Use this skill whenever an agent needs to turn a Jira issue into structured, testable evidence.

## Prerequisite and resume handshake

Before extraction:
- Validate Jira MCP readiness using `getAccessibleAtlassianResources` and `atlassianUserInfo`.
- Validate ticket readability with a lightweight `getJiraIssue` request.
- If a previous extraction attempt paused, resume from the first incomplete extraction step instead of restarting.
- Apply shared retry rules for transient errors; after retry exhaustion, return BLOCKED with checkpoint details.

## What to fetch

Request these fields explicitly (do not rely on the default field set):
`summary`, `description`, `status`, `issuetype`, `comment`, `attachment`, and the Acceptance Criteria
custom field (`customfield_19934` in this RTWC project — confirm the field id per project if reused elsewhere).

## Extraction steps

1. **Acceptance criteria** — read the Acceptance Criteria field (ADF format). Flatten nested bullet
   lists into a numbered list of atomic, testable statements. Do not paste raw ADF into output.
2. **Visual evidence inventory** — from `attachment` and inline `description`/comment images, record:
   - filename, attachment id, mime type
   - whether the content is fetchable (see limitation below)
3. **Supplementary UI notes** — scan description/comments for explicit label text, control names,
   or layout notes called out by BA/PO that aren't already in the AC field.
4. **Legacy trace trigger detection** — detect whether ticket text requires legacy behavior tracing,
   compile-branch equivalent discovery, endpoint identification, or stored procedure evidence.
   If triggered, add a "Legacy Trace Required: Yes" flag and list required evidence fields.

## Attachment Download Protocol (Dev mode — automatic before falling back to developer input)

When running in **Dev mode** and the ticket has one or more image attachments:

### Step 1 — Detect MCP authentication type

Before attempting a download, determine whether credentials are available.
Run this PowerShell probe (checks workspace `.vscode/mcp.json` first, then global `$env:APPDATA\Code\User\mcp.json`):

```powershell
$candidates = @(
    (Join-Path (Get-Location) ".vscode\mcp.json"),
    (Join-Path $env:APPDATA "Code\User\mcp.json")
)
$email = $null; $token = $null
foreach ($path in $candidates) {
    if (Test-Path $path) {
        $raw = Get-Content $path -Raw
        $e = [regex]::Match($raw, '"ATLASSIAN_USER_EMAIL"\s*:\s*"([^"]+)"').Groups[1].Value
        $t = [regex]::Match($raw, '"ATLASSIAN_API_TOKEN"\s*:\s*"([^"]+)"').Groups[1].Value
        if ($e -and $t) { $email = $e; $token = $t; break }
    }
}
if ($email -and $token) { Write-Output "AUTH:basic" } else { Write-Output "AUTH:oauth" }
```

- If output is `AUTH:basic` → proceed to Step 1A (automatic download).
- If output is `AUTH:oauth` → skip to Step 3 (fallback). OAuth MCP uses browser-delegated tokens that cannot be extracted for REST calls; no download script will work.

### Step 1A — Download via Jira REST API (Basic auth only)

For each image attachment:

```powershell
$cloudId  = "<cloudId from getAccessibleAtlassianResources>"
$attachId = "<attachment id from ticket>"
$outFile  = Join-Path $env:TEMP "jira-$attachId.png"
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("${email}:${token}"))
try {
    Invoke-WebRequest `
        -Uri "https://api.atlassian.com/ex/jira/$cloudId/rest/api/3/attachment/content/$attachId" `
        -Headers @{ Authorization = "Basic $auth" } `
        -OutFile $outFile -ErrorAction Stop
    Write-Output "DOWNLOADED:$outFile"
} catch {
    Write-Output "FAILED:$($_.Exception.Message)"
}
```

- If output starts with `DOWNLOADED:` → proceed to Step 2.
- If output starts with `FAILED:` → proceed to Step 3 (fallback).

Repeat for each attachment. Delete temp files after `view_image` is called.

### Step 2 — Read the downloaded image (automatic)

Call `view_image` on the downloaded path. Extract:
- Form/window name and context visible in the screenshot
- All UI controls present (labels, buttons, grids, inputs, toolbars)
- Layout, ordering, visibility, and enabled/disabled state of controls
- Any text labels, column headers, or message text shown

Incorporate these findings directly into the Pre-Implementation Plan:
- **Affected Files**: confirm controls match what the plan intends to add/change
- **Implementation Approach**: reference the exact visual layout seen in the screenshot
- Add "Screenshot analysed: `<filename>`" to the plan's Visual Evidence section

### Step 3 — Fallback if automatic download fails

If the download fails (expired token, network error, or `ATLASSIAN_API_TOKEN` not set), ask the developer **once** with four options:

> "Automatic screenshot download failed (`<error>`).
> The ticket has **N screenshot(s)**: `[filename1.png]`, `[filename2.png]`
> Direct link: `https://stateautoinsurance.atlassian.net/browse/<TICKET>` (Attachments tab)
>
> To include visual context in the plan, please either:
> - **Option A** — Download the file(s) from the Jira Attachments panel and share the local path. I will read them with `view_image`.
> - **Option B** — Describe the expected UI (controls, layout, labels) here.
> - **Option C** — Skip visual context and defer comparison to QA.
> - **Option D (permanent fix)** — Add your Atlassian API token to mcp.json so future runs download automatically (see setup note below)."

Handle the response:
- A → `view_image` on the provided path
- B → incorporate description in plan, note "Developer-described, not screenshot-verified" in Visual Evidence
- C → note in Risks/Assumptions: "N screenshot(s) on ticket — visual AC deferred to QA"
- D → follow the API token setup steps below, then re-run Step 1A

#### One-time API token setup (Option D)
1. Go to https://id.atlassian.com/manage-profile/security/api-tokens and create a token.
2. Open `%APPDATA%\Code\User\mcp.json` (global VS Code MCP config).
3. In the `atlassian-mcp` server's `env` block, add:
   ```json
   "ATLASSIAN_USER_EMAIL": "your.email@libertymutual.com",
   "ATLASSIAN_API_TOKEN": "<token>"
   ```
4. Reload VS Code MCP. Step 1A will now work automatically for all tickets.

> **This protocol only applies in Dev mode.** QA mode uses `skill-visual-comparison-protocol.md` Step D.

---

## Known tooling limitations (verified 2026-08-10 by live test on RTWC-2327)

All automated attachment paths were tested against a real ticket with 3 PNG attachments:

| Path attempted | Result | Reason |
|---|---|---|
| PowerShell `Invoke-WebRequest` + Basic auth | ❌ 403 | `ATLASSIAN_API_TOKEN` not set in mcp.json (OAuth-only setup) |
| `fetch_webpage` on REST attachment URL | ❌ 403 | No OAuth bearer available to the tool |
| `open_browser_page` on REST attachment URL | ❌ 403 | Integrated browser has no Jira session |
| `open_browser_page` on `atlassian.net/browse/<ticket>` | ❌ Redirected to login | Integrated browser is isolated — no SSO session |
| `mcp_atlassian-mcp_fetch` | ❌ Not applicable | Only accepts issue/page ARIs; attachments have no ARI |
| Description inline images | ❌ Not usable | MCP returns them as `blob:` client-side URLs — inaccessible |
| PowerShell + `ATLASSIAN_API_TOKEN` in mcp.json | ✅ Works | Step 1A path — confirmed working when token is present |

| MCP setup | Automatic download | What to do |
|---|---|---|
| API token in mcp.json (`ATLASSIAN_USER_EMAIL` + `ATLASSIAN_API_TOKEN`) | ✅ Step 1A | No action needed |
| Cloud OAuth (`https://mcp.atlassian.com/v1/mcp`) without API token | ❌ All paths blocked | Step 3 fallback — recommend Option D to fix permanently |

- Do NOT retry any of the failing paths — they are structural blockers, not transient errors.
- Always record attachment filename/id in the Visual Evidence Inventory regardless of download outcome.
- Hand off to `skill-visual-comparison-protocol.md` for how to disclose in QA output.

## Output shape

Return:
- Acceptance Criteria: numbered list
- Visual Evidence Inventory: table of `filename | attachment id | fetchable (Y/N)`
- Supplementary UI Notes: bullet list (or "none found")
- Legacy Trace Requirement: `Yes/No` + required evidence fields when Yes:
   - ASP endpoint file
   - Method parameter value
   - Stored procedure name(s)
   - Compile-branch equivalent call decision
- Resume Checkpoint (when applicable):
   - last successful step
   - failed step
   - next action on resume
