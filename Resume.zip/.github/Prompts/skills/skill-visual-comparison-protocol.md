---
name: "Visual Comparison Protocol"
description: How QA compares Jira screenshot evidence against the implemented XCAM UI, including the current tooling limitation and required disclosure
when-to-use: "QA Agent Step 1.1 (visual baseline) and Step 3.3 (screenshot comparison), or any agent asked to validate UI against Jira evidence"
---

# Skill: Visual Comparison Protocol

## Step 0 — Prerequisite and resume handshake

- Validate Jira MCP readiness before reading issue/attachment metadata:
  - `getAccessibleAtlassianResources`
  - `atlassianUserInfo`
- If this comparison was previously paused by a recoverable error, resume from the first incomplete step (A/B/C/D) instead of restarting.
- Apply shared retry rules for transient MCP failures.

## Step A — Build the expected-visual checklist

From `skill-jira-evidence-extraction.md`'s Visual Evidence Inventory, derive a checklist per screenshot:
- Form/window name and context
- Required controls (labels, text boxes, grids, buttons, tabs)
- Expected control text, order, visibility, enabled/disabled state
- Notable formatting/layout details visible in the screenshot

## Step B — Attempt retrieval

1. Check whether an attachment-download tool is available in the current toolset (`tool_search` if unsure).
2. If available, fetch the attachment content and proceed to Step C.
3. If not available (current default state — see limitation below), do not fabricate a comparison.
   Proceed to Step D (disclosure) instead.

## Known limitation (do not re-attempt each run)

As of 2026-07-22, no Jira attachment-content or attachment-upload tool is exposed to these agents,
and direct `fetch_webpage` calls to the attachment content endpoint return 403. This makes
pixel/visual comparison against Jira screenshots **not executable** with current tooling.

## Step C — If retrieval succeeds

Capture a current screenshot of the implemented feature in the same workflow state and compare for:
- Presence/absence of controls
- Label text and spelling
- Control order and grouping
- Visibility/enabled state
- Value formatting and message text

Mark each comparison MATCH / PARTIAL / MISMATCH. Any unapproved MISMATCH against Jira evidence fails
the related AC.

## Step D — If retrieval is blocked (current default)

- Do not mark the related AC as FAIL solely because of this tooling gap.
- Do not silently skip it either. Include an explicit section in QA output:
  `Visual Comparison Not Performed — Tooling Limitation`, naming the Jira attachment(s) that could
  not be retrieved.
- Still validate the same checklist items against the running app by code inspection and/or manual
  runtime check where possible (Step A checklist), and report that as a substitute, lower-confidence
  signal — not a replacement for true pixel comparison.
- Recommend a human reviewer complete the pixel-level check before final sign-off if the ticket is
  UI-visual-sensitive.

## Output shape

- Visual Comparison Evidence table (MATCH/PARTIAL/MISMATCH) — only if Step C ran.
- Visual Comparison Not Performed — Tooling Limitation section — if Step D ran, listing attachment
  filenames/ids and the substitute evidence gathered instead.
