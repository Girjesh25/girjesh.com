---
name: "Multi-Agent Handoff"
description: The structured artifact Dev Agent, QA Agent, and the Orchestrator pass between each other so state does not get lost between stages
when-to-use: "End of Dev Agent (handing to QA), end of QA Agent (handing to Orchestrator), and every stage transition inside Orchestrator Agent"
---

# Skill: Multi-Agent Handoff

Prompt files in this repo run as independent agent invocations with no shared memory by default.
This skill defines the one artifact every stage must emit so the next stage (or the Orchestrator)
can pick up state reliably instead of re-discovering it from scratch.

## Handoff artifact (required at every stage boundary)

```
### Handoff — <Stage Name> → <Next Stage>
- Ticket: <key>
- Stage result: PASS / FAIL / BLOCKED / NEEDS REVISION
- Resume checkpoint: <none | last successful step/stage; failed step/stage>
- Prerequisites revalidated: Yes / No
- Files changed (if known): <list or "see Ecosystem Discovery Log">
- Ecosystem Discovery Log: <included inline | link to prior stage output>
- Legacy Trace Summary (if in scope): <endpoint/method/SP/equivalent decision>
- Confidence (change evidence): High / Medium / Low
- Build status: PASS / FAIL
- Test status: <passed>/<total>, net-new failures: <count>
- Blockers carried forward: <none | list>
- Required action for next stage: <e.g. "run QA Agent", "return to Dev with gaps", "publish to Jira">
```

## Stage-specific emission rules

- **Dev Agent → QA Agent**: emit this block as the last section of Dev Agent's final summary,
  right after the Shared Output Evidence Schema. `Files changed` must be populated from Step 6/8
  discovery, not left blank. If legacy trace is in scope, include endpoint/method/stored-procedure
  evidence and reuse-vs-new equivalent-call decision.
- **QA Agent → Orchestrator**: emit this block right after the QA Verdict. `Stage result` must
  match the QA Verdict (APPROVED → PASS, NEEDS REVISION → NEEDS REVISION).
- **Orchestrator, between any two stages**: read the prior stage's Handoff block before invoking
  the next stage. Do not re-run discovery the next stage already completed unless the Handoff block
  reports Confidence: Low or Blockers are present.
- **All stage boundaries**: if `Resume checkpoint` is not `none`, the next stage must continue from
  the first incomplete step/stage after revalidating prerequisites.

## Failure handling

- If a stage does not emit a Handoff block, the Orchestrator must treat this as a Post-Hook gate
  failure (`Delivery transparency gate`) and stop rather than guessing state.
- If `Stage result` is BLOCKED or NEEDS REVISION, the Orchestrator must not proceed to the next
  stage automatically — it must apply the stop/branch rules defined in `agents/orchestrator-agent.md`.
