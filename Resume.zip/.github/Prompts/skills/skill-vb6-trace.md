---
description: Mine VB6 client source and ASP backend source to extract reference behavior for XCAM tickets requiring legacy trace
---

# Skill: VB6 Trace

Invoke this skill when `Legacy Trace Required: Yes`. Extract the reference behavior from both VB6 source layers before any implementation begins.

## Locate source (in order — stop at the first that works)
1. Check `.vscode/xcam-dev-config.json` for `vb6Source.xcamVb6` and `vb6Source.trunkXcam` — use directly if paths exist on disk.
2. Check `XCAM.UI\XCAM VB6 Source\` — use if present and non-empty.
3. Run `.github/Prompts/bootstraps/ensure-vb6-source.md` (Git clone/update from `StateAuto/RTW-VB6`).
4. If the Git repository is unavailable — stop and present via `vscode_askQuestions`: (a) Resolve Git/repository access; (b) Provide local path (save to `.vscode/xcam-dev-config.json`); (c) Defer trace. Do NOT continue until user selects an option.

---

## Layer 1 — VB6 client (`RTW-VB6` ref `RTWI`, path `XCAM`)

Open the **targeted method block only** — do not load the full file.

| Topic | File |
|---|---|
| HTTP / XML calls to ASP | `CXML.cls` |
| Employer / policy / insured / contact | `CInsured.cls` |
| Collections / cancellations | `CCollectionCancel.cls` |
| Notes / documents / images | `CNotes.cls` + `basNotes.bas` |
| Diary / tasks / notifications | `Messaging.cls` |
| User / rights / teams | `User.cls` |
| Accounting / GL / formatting | `basMain.bas` |
| UI form behavior | `frm<FormName>.frm` matching the topic |

**Extract:**
- Exact `Sub`/`Function` name and parameter list
- Business rules (conditionals, validations, error messages shown to user — these must be preserved)
- ASP endpoint URL and `Method` value in `g_oCXML.GetXML` / `g_oCXML.SendXML`
- XML payload structure for any POST calls

---

## Layer 2 — ASP backend (`RTW-VB6` ref `trunk`, path `XCAM`)

Open only the relevant `.asp` or `.cls` file section for the method identified in Layer 1.

| Topic | Subfolder |
|---|---|
| Accounting / GL | `ASP\XCAMAccounting.asp`, `XCAMAccounting\` |
| Billing | `ASP\XCAMBilling.asp`, `XCAMBilling\` |
| Cancellations | `ASP\XCAMCancellations.asp`, `XCAMCancellations\` |
| Cancellation status | `ASP\XCAMCancelStatus.asp`, `XCAMCancelStatus\` |
| Cash receipts / lockbox | `ASP\XCAMCashReceipts.asp`, `XCAMCashReceipts\` |
| Collections | `ASP\XCAMCollectionsNew.asp`, `XCAMCollections\`, `XCamCollectionStatus\` |
| Commissions | `ASP\XCAMCommissions.asp`, `XCAMCommissions\` |
| GL postings | `ASP\XCAMGLPostings.asp`, `XCAMGLPostings\` |
| Policy | `XCAMPolicy\CPolicy.cls`, `XCAMPolicy\Policy.cls` |
| Statement / invoice | `ASP\XCAMStatement.asp`, `XCAMStatement\` |

**Extract:**
- Stored procedure name(s) invoked
- XML schema returned (column names, DATA/ACTION attribute shapes)
- Server-side validation the client relied on

---

## Modernize vs preserve

| Modernize | Preserve |
|---|---|
| `On Error GoTo` → `Try/Catch` | Business rule conditionals and validations |
| `DoEvents` → `Await` | XML field names and column names |
| `g_` global variables → `AppState` | User-visible error message text (exact wording) |
| `CXML.GetXML` → framework DLL call | Data flow and binding order |

---

## Output: Legacy Trace Summary

Populate this before presenting the Pre-Implementation Plan:

| Field | Value |
|---|---|
| VB6 file + procedure | |
| ASP endpoint URL + Method value | |
| Stored procedure name(s) | |
| XML response column names | |
| Patterns to modernize | |
| Patterns to preserve | |
