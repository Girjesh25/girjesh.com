---
description: Exact VB.NET service method templates, unit test patterns, and implementation rules for XCAM
---

# Skill: XCAM Service Pattern

Use this skill during Step 8 (Implement) and Step 9 (Tests) to get exact code templates.

---

## Service method — DataTable result

```vb
''' <summary>
''' [Brief description. One sentence.]
''' VB6: [File.cls / Function name]
''' Framework: [NS].Framework.[Domain].[Class].[Method]
''' → [NS].Soa.Controllers.[Domain] → [NS].Soa.[Domain] → SP [DatabaseName]..[spName]
''' </summary>
Public Async Function [Name]Async([params]) As Task(Of DataTable)
    Try
        Dim ds As DataSet = Await Task.Run(Function()
            Return _[domain].[Method]([args])
        End Function).ConfigureAwait(False)
        If ds Is Nothing OrElse ds.Tables.Count = 0 OrElse ds.Tables(0).Rows.Count = 0 Then Return Nothing
        Return ds.Tables(0)
    Catch ex As Exception
        AppState.ErrorHandler.ReportError(AppState.AppName, AppState.AppVersion,
            "[ServiceClassName]", "[Name]Async", ex, [contextString])
        Return Nothing
    End Try
End Function
```

## Service method — Boolean insert/update result

```vb
Public Async Function [Name]Async([params]) As Task(Of Boolean)
    Try
        Dim ds As DataSet = Await Task.Run(Function()
            Return _[domain].[Method]([args])
        End Function).ConfigureAwait(False)
        If ds Is Nothing OrElse ds.Tables.Count = 0 OrElse ds.Tables(0).Rows.Count = 0 Then Return False
        ' SP returns -100 on success — check ReturnValue column, or adapt to the actual SP contract
        Return CInt(ds.Tables(0).Rows(0)("ReturnValue")) = -100
    Catch ex As Exception
        AppState.ErrorHandler.ReportError(AppState.AppName, AppState.AppVersion,
            "[ServiceClassName]", "[Name]Async", ex, [contextString])
        Return False
    End Try
End Function
```

## Rules — never violate these

- `Async Function ... As Task(Of T)` — service methods are never synchronous
- Wrap ALL synchronous framework calls in `Task.Run(Function() ...).ConfigureAwait(False)`
- `AppState.ErrorHandler.ReportError(...)` in every `Catch` — never swallow silently
- Return `Nothing` / `False` / `0` on error — never re-throw from a service method
- Add `' RTWC-XXXX: [brief reason]` comment on each new/changed block

---

## Contract test — new Async instance method (XCAM.Test\Service\)

File: `XCAM.Test\Service\[Domain]ServiceContractTests.cs`

```csharp
[Fact]
public void [Name]Async_Takes[ParamType]_ReturnsTaskOf[ReturnType]()
    => ContractAssert.TaskSignature(Service, "[Name]Async",
        typeof([ReturnType]), typeof([ParamType]));

// Multiple parameters — list types in declaration order:
[Fact]
public void [Name]Async_TakesLongAndBoolean_ReturnsTaskOfDataTable()
    => ContractAssert.TaskSignature(Service, "[Name]Async",
        typeof(DataTable), typeof(long), typeof(long), typeof(bool));
```

Where `Service = typeof([Domain]Service)`.

## Contract test — new constructor parameter

```csharp
[Fact]
public void Constructor_Takes[NewParamType]()
{
    bool match = typeof([Domain]Service).GetConstructors().Any(ctor =>
        ctor.GetParameters().Any(p => p.ParameterType.Name == "[NewParamTypeName]"));
    Assert.True(match, "Expected constructor parameter '[NewParamTypeName]' not found.");
}
```

## Behavioral test — new static/shared helper method

```csharp
[Trait("Category", "Behavioral")]
[Theory]
[InlineData([input], [expectedOutput])]
public void [Name]_Given[Scenario]_Returns[Expected]([InputType] input, [OutputType] expected)
{
    var result = [Domain]Service.[Name](input);
    Assert.Equal(expected, result);
}
```

---

## Form contract test (XCAM.Test\UI\FormContractTests.cs)

**Do NOT instantiate forms or call `InitializeComponent()` in tests — fails in net8 host.**

New constructor parameter:
```csharp
[Fact]
public void Frm[Name]_ConstructorTakes[ServiceType]()
{
    Type formType = UiMetadata.GetForm("frm[Name]")!;
    bool match = formType.GetConstructors().Any(ctor =>
        ctor.GetParameters().Any(p => p.ParameterType.Name == "[ServiceType]"));
    Assert.True(match, "Expected constructor parameter '[ServiceType]' not found.");
}
```

New public property:
```csharp
[Fact]
public void Frm[Name]_Exposes[PropertyName]Property()
{
    Type formType = UiMetadata.GetForm("frm[Name]")!;
    var prop = formType.GetProperty("[PropertyName]", BindingFlags.Public | BindingFlags.Instance);
    Assert.NotNull(prop);
}
```

New form added to project:
```csharp
[InlineData("frm[NewFormName]")]
```
Add to the `Form_IsPublicNonAbstractFormSubclass` theory.

---

## XcamHttpClient — last resort only

Use `XcamHttpClient` ONLY after running `skill-compile-branch-gap-fill.md` and confirming the method is absent from all 5 compile-branch layers. Document the absence evidence in the Pre-Implementation Plan Risks section.
