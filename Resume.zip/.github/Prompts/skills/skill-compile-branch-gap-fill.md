---
description: Detect gaps in the 6-layer RTW framework call chain and provide exact patterns to fill each missing layer
---

# Skill: Framework Repository Gap-Fill

Invoke this skill when a VB6 trace identifies methods needed from the framework that may not exist yet — or any time `XcamHttpClient` would otherwise be considered.

## Framework repository locations
- `https://github.ent.stateauto.com/StateAuto/RTW-RHH` on `dev` for RHH domains.
- `https://github.ent.stateauto.com/StateAuto/RTW-RTWI` on `dev` for RTWI domains.

Run `.github/Prompts/bootstraps/ensure-framework-repositories.md` before this skill. Search the repository that owns the namespace, not the retired SVN `Compile` folders.

---

## 6-layer call chain (all RTWI/RHH domains)

```
Layer 1 — SOA repository:    [NS].Soa.[Domain]\[Class].vb
                              Direct SqlConnection + stored procedure call
Layer 2 — SOA Controller:    [NS].Soa.Controllers.[Domain]\[Class].vb
                              Instantiates SOA repo and delegates; no direct SQL
Layer 3 — ASMX WebMethod:    [NS]\WS\[Domain]Service\*.asmx.vb
                              Imports Controller namespace; calls New [Class](SUID).Method(...)
Layer 4 — SOAP proxy:        [NS].Framework.[Domain]\Web References\*WS\Reference.vb
                              Generated proxy; Me.Invoke("MethodName", args)
Layer 5 — Framework wrapper: [NS].Framework.[Domain]\[Class].vb
                              Public DLL API; calls _[domain]Service.Method(_suid, ...)
Layer 6 — XCAM.Services:     XCAM.Services\[Domain]Service.vb
                              Async Task.Run wrapper; returns DataSet.Tables(0)
```

`[NS]` = `RTWI` or `RHH` — check which one XCAM.Services already references for this topic.

---

## Domain mapping

| VB6 ASP topic | SOA repo + Controller | Framework DLL |
|---|---|---|
| `XCAMAccounting*` | `RTWI.Soa.Accounting.*` + `RTWI.Soa.Controllers.Accounting.*` | `RTWI.Framework.Accounting.*` |
| `XCAMCollections*` | `RTWI.Soa.Collections.*` + `RTWI.Soa.Controllers.Collections.*` | `RTWI.Framework.Policies` |
| `XCAMCancellations*` | `RTWI.Soa.Cancellations.*` + `RTWI.Soa.Controllers.Cancellations.*` | `RTWI.Framework.Policies` |
| Policy / insured (RTWI) | `RTWI.Soa.Policies` + `RTWI.Soa.Controllers.Policies` | `RTWI.Framework.Policies` |
| Employer / location (RHH) | `RHH.Soa.Employers` + `RHH.Soa.Controllers.Employer` | `RHH.Framework.Employers` |
| User / profile / rights | `RHH.Soa.Profiles` + `RHH.Soa.Controllers.Profiles` | `RHH.Framework.Profiles` |
| Notes / documents | `RHH.Soa.FileDocuments` + `RHH.Soa.Controllers.FileDocuments` | `RHH.Framework.FileDocuments` |
| Diary / tasks / notifications | `RHH.Soa.[Diary\|Tasks\|SystemNotifications]` + controllers | `RHH.Framework.Messaging.*` |

---

## Gap detection — check every layer for each method needed

1. Search Layer 1 (SOA repo) for the method name
2. Search Layer 2 (SOA Controller) for the delegation wrapper
3. Search Layer 3 (ASMX) for the `<WebMethod>` declaration
4. Search Layer 4 (Reference.vb) for the proxy `Invoke` function
5. Search Layer 5 (Framework wrapper) for the public method
6. Check installed DLL at `C:\Program Files\RTWApps\[NS]\Framework\` for the compiled signature (use .NET reflection or grep if needed)

**Rule:** If ANY layer is missing the method, add it bottom-up (Layer 1 → 2 → 3 → 4 → 5) before calling from Layer 6.

**Never use `XcamHttpClient` to substitute for a missing framework method.** It is only acceptable when the method has no .NET framework counterpart in any of the 5 framework layers.

---

## Gap-fill patterns per layer

| Layer | File | Exact pattern |
|---|---|---|
| 1 — SOA repository | `[NS].Soa.[Domain]\[Class].vb` | `Dim cn As New SqlConnection(_connectstring)` + `SqlCommand` with `CommandType.StoredProcedure`. `da.TableMappings.Add("Table", "[Name]")`. Catch `SqlException` + `Exception`, `Logger.WriteExceptionLogFile(ex)`, return `Nothing`. Finally: close + null the connection. |
| 2 — SOA Controller | `[NS].Soa.Controllers.[Domain]\[Class].vb` | `Dim Repository As New [NS].Soa.[Domain].[Class](_suid)` → `Return Repository.Method(...)`. Pure delegation; only add logic if VB6 trace shows business rules at this layer. |
| 3 — ASMX WebMethod | `[NS]\WS\[Domain]Service\*.asmx.vb` | `<WebMethod(Description:="...")> Public Function Method(SUID As Integer, ...) As DataSet`. Body: `Return New [Class](SUID).Method(...)`. `[Class]` resolves to Controller via `Imports [NS].Soa.Controllers.[Domain]` at top of file. |
| 4 — SOAP proxy | `Reference.vb` inside `Framework\Web References` | Add inside the generated `[Domain]Service` class: `<SoapDocumentMethodAttribute("http://[ns].com/[Domain]/Method",...)> Public Function Method(...) As DataSet`. Body: `Me.Invoke("Method", New Object() {arg1, arg2...})`. Sync function only is sufficient for XCAM to compile. |
| 5 — Framework wrapper | `[NS].Framework.[Domain]\[Class].vb` | `Public Function Method(...) As DataSet` → `Return _[domain]Service.Method(_suid, ...)`. Follow existing `'PIPE-NNNN Starts/Ends` region convention if present. |
| 6 — XCAM.Services | `XCAM.Services\[Domain]Service.vb` | Use the async pattern in `skill-xcam-service-pattern.md`. |

---

## Before writing any gap-fill code
Confirm from the VB6 trace (skill-vb6-trace.md Layer 2 output):
- Exact stored procedure name
- Result column names and data types

## After all framework layers are filled
Add to Pre-Implementation Plan Risks/Assumptions:
> "Framework DLL rebuild and deployment to `C:\Program Files\RTWApps\[NS]\Framework\` required before the full solution compiles against the new methods. This is a known build blocker — it does not block XCAM.Services source changes."
