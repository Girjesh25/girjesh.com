param(
    [string]$WorkspaceRoot = ".",
    [switch]$SkipBuild,
    [switch]$SkipTests
)

$ErrorActionPreference = "Continue"

function Get-BoolResult {
    param([bool]$Value)
    if ($Value) { return "PASS" }
    return "FAIL"
}

$msbuildPath = "C:\Program Files\Microsoft Visual Studio\2022\Professional\MSBuild\Current\Bin\MSBuild.exe"
$dotnetPath = "C:\Program Files\dotnet\dotnet.exe"

$toolchain = [ordered]@{
    msbuildPathExists = Test-Path $msbuildPath
    dotnetPathExists = Test-Path $dotnetPath
}

$paths = @(
    "C:\Program Files\RTWApps\RHH\Framework",
    "C:\Program Files\RTWApps\RTWI\Framework",
    "C:\Program Files\RTWApps\RTWI\Windows"
)

$pathChecks = @()
foreach ($p in $paths) {
    $pathChecks += [ordered]@{
        path = $p
        exists = (Test-Path $p)
    }
}

$dlls = @(
    "C:\Program Files\RTWApps\RHH\Framework\RHH.Framework.Common.dll",
    "C:\Program Files\RTWApps\RHH\Framework\RHH.Framework.Employers.dll",
    "C:\Program Files\RTWApps\RHH\Framework\RHH.Framework.Profiles.dll",
    "C:\Program Files\RTWApps\RTWI\Framework\RTWI.Framework.Policies.dll",
    "C:\Program Files\RTWApps\RTWI\Framework\RTWI.Framework.Accounting.Payables.dll",
    "C:\Program Files\RTWApps\RTWI\Windows\RTWI.Windows.ControlLibrary.dll"
)

$dllChecks = @()
foreach ($d in $dlls) {
    $exists = Test-Path $d
    $version = $null
    if ($exists) {
        try { $version = (Get-Item $d).VersionInfo.FileVersion } catch { $version = $null }
    }

    $dllChecks += [ordered]@{
        path = $d
        exists = $exists
        version = $version
    }
}

Push-Location $WorkspaceRoot

$buildExit = $null
$buildSummary = "SKIPPED"
$testExit = $null
$testSummary = "SKIPPED"

if (-not $SkipBuild) {
    if (Test-Path "XCAM.sln") {
        & $msbuildPath XCAM.sln /t:Build /p:Configuration=Debug "/p:Platform=Any CPU" /v:minimal | Out-Null
        $buildExit = $LASTEXITCODE
        $buildSummary = if ($buildExit -eq 0) { "PASS" } else { "FAIL" }
    }
    else {
        $buildExit = 1
        $buildSummary = "FAIL"
    }
}

if (-not $SkipTests) {
    if (Test-Path "XCAM.Test\XCAM.Test.csproj") {
        dotnet test XCAM.Test/XCAM.Test.csproj -v minimal | Out-Null
        $testExit = $LASTEXITCODE
        $testSummary = if ($testExit -eq 0) { "PASS" } else { "FAIL" }
    }
    else {
        $testExit = 1
        $testSummary = "FAIL"
    }
}

Pop-Location

$machineReady = $true
if (-not $toolchain.msbuildPathExists -or -not $toolchain.dotnetPathExists) { $machineReady = $false }
if (($pathChecks | Where-Object { -not $_.exists }).Count -gt 0) { $machineReady = $false }
if (($dllChecks | Where-Object { -not $_.exists }).Count -gt 0) { $machineReady = $false }

$report = [ordered]@{
    timestamp = (Get-Date).ToString("s")
    machineReadiness = Get-BoolResult $machineReady
    toolchain = $toolchain
    dependencyPaths = $pathChecks
    keyDlls = $dllChecks
    buildBaseline = $buildSummary
    testBaseline = $testSummary
    buildExitCode = $buildExit
    testExitCode = $testExit
    baselineClassificationHint = if ($machineReady -and $buildSummary -eq "PASS" -and $testSummary -eq "PASS") { "none" } else { "investigate baseline environment or dependency" }
}

$report | ConvertTo-Json -Depth 6
