---
agent: "agent"
name: "Shared Post-Hook"
argument-hint: "Enter a Jira ticket number (e.g. RTWC-2323)"
tools: ['atlassian', 'terminal', 'filesystem', 'problems']
model: "Claude Sonnet 4.6"
description: Reusable release-gate check for Dev and QA agents, run at the end of their workflow
---

# Shared Post-Hook - Dev/QA Release Gate

Use this prompt at the **end** of Dev Agent or QA Agent, right before final output is delivered.
It is the completion-side counterpart to `.github/Prompts/hooks/shared-preflight.md` (the start-side Pre-Hook).

## Goal

Verify the agent's own output satisfies the Mandatory Post-Hook Release Gate in
`.github/Prompts/shared/shared-agent-guardrails.md` and produce a compact, machine-checkable result
that the Orchestrator (or a human) can use to decide whether to proceed, stop, or hand off.

## Inputs

- Ticket number: ${input:ticketNumber:Jira ticket number (e.g. RTWC-2323)}
- Mode: Dev or QA
- The agent's own draft final output (AC coverage table, fallbacks, build/test results, etc.)

## Checks (mapped to shared-agent-guardrails.md gates)

0. Prerequisite and resume validation - MCP/Jira readiness check evidence is present and paused runs resumed from checkpoint.
0.1 Machine-readiness evidence - preflight includes automated readiness output (toolchain, dependency paths, key DLL checks, build baseline, test baseline) and baseline classification.
1. Evidence completeness - every AC is PASS with evidence or FAIL/BLOCKED with an explicit gap.
2. Regression - net-new build/test failures are separated from baseline failures; no net-new failures block completion.
3. Architecture - no prohibited direct-dependency patterns introduced; async/error-handling standards intact.
4. Delivery transparency - fallbacks, assumptions, risks, and follow-ups are explicitly listed.
5. Ecosystem coverage - Pass A/Pass B outcomes documented; compile-branch evaluation evidence present (Dev mode) or verified (QA mode).
6. Legacy trace evidence - when legacy parity is in scope, evidence includes ASP endpoint file, `Method` value, stored procedure(s), compile-branch equivalent decision, and `GetEmployerByCheckNumber` comparison rationale.
7. Efficiency compliance - fast-path/search budgets/confidence levels reported where applicable.
8. Security - secure implementation rules applied; no new Critical/High vulnerabilities; findings documented.
9. Coding standards - RTW alignment checks applied; net-new deviations documented with owner/follow-up.
10. Sensitive data handling - no prohibited sensitive files/values were read; any accidental exposure was stopped and disclosed.
11. Execution telemetry - final output includes iterations, total elapsed time, and token usage, or explicit runtime-unavailable disclosure with proxy metrics.
12. Machine-readiness traceability - final output references readiness evidence and uses it when classifying build/test failures as baseline vs net-new.

### QA-mode additional checks

- Functional Test Evidence table is present with Expected vs Actual per scenario.
- Visual Comparison Evidence table is present, or the tooling-limitation disclosure from
  `skill-visual-comparison-protocol.md` is included instead.
- Jira Publication Status block is present (comment posted, attachment status).

## Output (required)

Return a **Post-Hook Result** block with:

- Ticket: [key]
- Mode: Dev / QA
- Prerequisite/resume gate: PASS / FAIL
- Machine-readiness evidence gate: PASS / FAIL
- Evidence completeness: PASS / FAIL
- Regression gate: PASS / FAIL (net-new count)
- Architecture gate: PASS / FAIL
- Transparency gate: PASS / FAIL
- Ecosystem coverage gate: PASS / FAIL
- Legacy trace evidence gate: PASS / FAIL / N/A
- Efficiency gate: PASS / FAIL
- Security gate: PASS / FAIL
- Coding standards gate: PASS / FAIL
- Sensitive data gate: PASS / FAIL
- Execution telemetry gate: PASS / FAIL
- Machine-readiness traceability gate: PASS / FAIL
- Overall: RELEASE / HOLD
- Blockers: [none or numbered list]

If any gate is FAIL, set Overall to HOLD and list the specific gap(s) - do not let the agent's own verdict override a failed gate silently.
