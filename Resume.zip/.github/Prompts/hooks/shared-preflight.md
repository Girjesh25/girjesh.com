---
agent: "agent"
name: "Shared Preflight"
argument-hint: "Enter a Jira ticket number (e.g. RTWC-2323)"
tools: ['atlassian', 'terminal', 'filesystem', 'problems']
model: "Claude Sonnet 4.6"
description: Reusable prerequisite gate for Dev and QA agents
---

# Shared Preflight - Dev/QA Prerequisites

Use this prompt before running Dev Agent or QA Agent.

## Goal

Run a fast, reusable prerequisite gate and produce a compact preflight result that downstream agents can consume.

## Inputs

- Ticket number: ${input:ticketNumber:Jira ticket number (e.g. RTWC-2323)}
- Parent branch: `${input:parentBranch:Phase2}` (optional; default `Phase2`)
- Mode: Dev or QA

## Checks

### 0) MCP readiness and resume checkpoint
- Validate Atlassian MCP connectivity before any Jira-dependent work:
  - `getAccessibleAtlassianResources`
  - `atlassianUserInfo`
  - lightweight ticket read (`getJiraIssue` summary/status)
- If any call fails, apply retry rules from shared guardrails.
- If retries are exhausted, report BLOCKED and set `Proceed: No`.
- If this is a resumed run, recover last successful checkpoint from prior output and continue from the next incomplete check (do not restart from Check 1).

### 1) Jira and ticket accessibility
- Verify the Jira issue can be opened with current MCP permissions.
- Confirm summary, status, and acceptance criteria content are readable.
- Report BLOCKED if issue is inaccessible or acceptance criteria are missing.

### 2) Workspace readiness
- Confirm required prompt files exist:
  - `.github/Prompts/shared/shared-agent-guardrails.md`
  - `.github/Prompts/agents/dev-agent.md`
  - `.github/Prompts/agents/qa-agent.md`
- Confirm `XCAM.sln` exists.

### 3) Tooling readiness (Git-first)
- Check availability of:
  - Git CLI (`git --version`)
  - MSBuild path used by this repo
  - .NET test runner (`dotnet --version`)
- Validate parent branch exists on origin (`git ls-remote --heads origin <parent-branch>`).
- Do not require SVN tools.

### 4) Baseline validation (automated machine-readiness gate)

> **HARD RULES — no exceptions:**
> - Run the script **once**. Do not retry on failure.
> - **Never install, download, or remediate** anything in response to a FAIL result. Report and move on.
> - Missing RTW framework DLLs (`C:\Program Files\RTWApps\`) are a **known baseline gap** — classify as `baseline environment`, do not set `Proceed: No` for DLL-only failures.
> - Toolchain FAIL (MSBuild or dotnet missing) = hard stop → `Proceed: No`.

- Run the readiness script in read-only mode and capture JSON output:
  - `.github/Prompts/hooks/run-machine-readiness.ps1`
  - **Dev mode**: run with default options (toolchain + paths + DLLs + build + tests).
  - **QA mode**: run with `-SkipBuild -SkipTests` — Stage 4.5 already built and launched the app; do not rebuild. Only toolchain, path, and DLL checks are needed here.
- Capture and report:
  - Machine readiness: PASS/FAIL
  - Build baseline: PASS/FAIL (Dev mode) / SKIPPED — completed at Stage 4.5 (QA mode)
  - Test baseline: PASS/FAIL (Dev mode) / SKIPPED — completed at Stage 4.5 (QA mode)
  - Classification of failures: `toolchain blocker` | `baseline environment/dependency` | `net-new regression`
  - First compile/test errors when failed
  - Readiness evidence location: command output or saved JSON artifact path

### 5) Change-evidence readiness
- If Git history is available:
  - Confirm at least one path to discover changes (`git log`, `git diff`, or ticket-linked commit/PR refs).
- If Git history is not available:
  - Mark change-evidence confidence as Medium/Low and require Jira-linked evidence.

### 6) Security boundary quick check
- Confirm review/implementation can proceed without reading sensitive secret-bearing files.
- If task requires secret inspection, mark BLOCKED and request sanitized alternative.

### 7) Legacy-trace readiness (VB6 -> ASP -> Compile)
- Confirm VB6 source folders are available for Pass A tracing when legacy parity is in scope.
- Confirm compile branch is available for Pass B equivalent-method discovery.
- Confirm workflow can capture these evidence points when required by ticket text:
  - ASP endpoint file
  - `Method` parameter value
  - Stored procedure name(s)
  - Compile-branch equivalent call decision (reuse vs new path)

## Output (required)

Return a **Preflight Result** block with:

- Ticket: [key]
- Mode: Dev / QA
- MCP readiness: PASS / FAIL
- Resume checkpoint: [none | prior run found, resumed at Check N]
- Jira access: PASS / FAIL
- Workspace readiness: PASS / FAIL
- Tooling readiness: PASS / FAIL
- Parent branch validation: PASS / FAIL
- Machine readiness: PASS / FAIL
- Build baseline: PASS / FAIL
- Test baseline: PASS / FAIL
- Baseline classification: [environment/dependency | net-new regression | mixed]
- Readiness evidence: [inline JSON summary or artifact path]
- Change-evidence readiness: High / Medium / Low
- Legacy-trace readiness: PASS / FAIL / N/A
- Blockers: [none or numbered list]
- Proceed: Yes / No

If any hard-stop from shared guardrails applies, set Proceed to No.
