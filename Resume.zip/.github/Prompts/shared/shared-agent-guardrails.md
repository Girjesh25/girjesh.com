# Shared Agent Guardrails

Use this file as the single source of truth for pre-hooks, fallback behavior, retry rules, and post-hook release gates.

## How to use

- Dev Agent: run all required checks in this file before Step 1 and enforce all post-hook gates before final summary.
- QA Agent: run all required checks in this file before ticket review and enforce all post-hook gates before verdict.

## Minimal kickoff policy (required)

When the user input includes Parent branch + Jira key, agents must proceed with that branch context and default workflow configuration.
When the user input is only a Jira key/story number, agents must proceed using `Phase2` as the default parent branch.
Do not ask for additional kickoff information unless a hard-stop condition is reached.

Expected kickoff format:

```text
Parent branch: <branch-name>
Ticket: <JIRA-ID>
Run workflow.
```

Allowed clarifications when truly needed:
- Access/permission blockers
- Missing acceptance criteria/evidence after required extraction steps
- Required transition choice cannot be resolved from available Jira transitions
- Environment constraints prevent mandatory validation

## Mandatory Execution Preview Gate

Before any state-changing action (create/edit/commit/push/transition/comment), every agent must
produce an approval-gated plan and wait for user confirmation.

### Dev Agent — Pre-Implementation Plan (9 required sections)

| Section | Content |
|---|---|
| **Objective** | One-sentence summary of what the ticket requires |
| **Acceptance Criteria** | Numbered list extracted from Jira |
| **Affected Files** | Every file that will be created or modified, with a one-line reason |
| **Implementation Approach** | Per-file: what changes and how it maps to existing VB.NET patterns |
| **Legacy VB6 Trace** | (when ticket involves ported behavior) VB6 source file, ASP endpoint, method name, stored procedure |
| **Framework Repository Check** | Required repository (`RTW-RHH` and/or `RTW-RTWI`) verified on `dev` before implementation |
| **Test Plan** | Which tests will be added or updated and how each AC is covered |
| **Risks / Assumptions** | Environment blockers, missing evidence, framework DLL gaps, ambiguous AC |
| **Estimated Steps** | Expected number of implementation + validation iterations |

This is a **HARD STOP** — no source file may be created, edited, or deleted until the user explicitly approves.

### QA Agent — QA Test Plan (5 required sections)

1. Every AC with how it will be verified and what evidence will be produced
2. Positive + negative functional scenarios per AC
3. Regression areas (adjacent forms/services sharing changed code)
4. Out-of-scope / known limitations (environment, tooling, DLL gaps)
5. Build + Launch status confirmation (Stage 4.5 result)

This is a **HARD STOP** — no Jira state-changing actions until the user explicitly approves.

### Approval protocol (both agents)

Use the `vscode_askQuestions` tool to present a structured approval dialog after each plan:
- Question: *"Review the plan above. Approve to proceed or Revise with feedback."*
- Options: **Approve** (recommended) | **Revise**
- `allowFreeformInput: true` — the user may type additional instructions or constraints alongside their selection; incorporate these before execution starts.

- If `Approve` (with or without extra instructions): incorporate any instructions provided, then proceed.
- If `Revise`: update the plan, re-present, show the dialog again. Repeat until approved.
- Do not execute state-changing steps until the user selects `Approve`.
- Read-only discovery is allowed before approval when needed to build an accurate plan.

## Mandatory Git Review Gate (Required)

Before any `git commit` or `git push`, agents must stop and present a review checkpoint.

Required review checkpoint content:
- Branch name and target base branch
- Exact files to be committed
- High-level change summary per file
- `git diff --name-only` and staged/untracked status summary
- Proposed commit message

Approval rule:
- Ask user for explicit `Approve` or `Revise`.
- Do not run `git commit` or `git push` until user approves.

## PR Publish Flow (Required)

PR automation is the default after QA approval. Agents must:

1. Present PR preview details:
   - Base branch and head branch
   - Proposed PR title
   - Proposed PR body/summary
   - `gh pr diff --name-only` scope preview
2. Ask a **single follow-up question**: "PR preview is ready. Raise PR now, or defer?"
   - `Raise PR` (default): publish immediately.
   - `Defer`: keep branch pushed only. Stop without creating a PR.
3. Never auto-merge after PR creation.

If the developer requests title/body changes, regenerate preview and re-present before publishing.

## Mandatory Completion Telemetry

At completion, every agent must report execution telemetry.

### Required telemetry block

Include:
- Iterations performed (count and brief label per iteration)
- Tool-call count (total)
- Files changed count
- Total elapsed time (from workflow start to final delivery)
- Token usage:
   - If runtime exposes token usage metadata, report input/output/total tokens.
   - If not exposed, report `Token usage: UNAVAILABLE IN THIS RUNTIME` and provide proxy metrics (tool calls, changed files, elapsed time).

### Iteration counting rules

- Count one iteration for each revise-and-replan cycle requested by user.
- Count one iteration for each execute/validate correction loop.
- Include final successful execution pass.

## Mandatory Pre-Hook

Do not proceed until these checks are complete.

0. Session resume and prerequisite recovery check
   - If this run follows a prior paused/failed attempt, resume from the next incomplete step instead of restarting from Step 1.
   - Restore prior evidence already collected (AC list, changed files, build/test baseline, visual inventory) and avoid re-running successful checks.
   - Validate MCP/Jira prerequisites before any Jira-dependent call:
     - `getAccessibleAtlassianResources`
     - `atlassianUserInfo`
     - ticket metadata read (`getJiraIssue` summary/status)
   - If prerequisite calls fail, apply retry rules. After retry exhaustion, set BLOCKED with explicit reason.

1. Jira access check
   - Verify MCP connectivity and permissions for the target ticket.
2. Source and dependency availability
   - Confirm required source folders and prerequisite branches are present and up to date for the workflow.
3. Baseline quality check
   - Capture baseline build and test status before changes/review.
   - Mandatory automation: run `.github/Prompts/hooks/run-machine-readiness.ps1` in read-only mode to execute the machine-readiness sequence from `.github/XCAM-BUILD-MACHINE-READINESS-CHECKLIST.md` (toolchain, RTW path checks, key DLL checks, baseline build, baseline tests).
   - Record explicit classification for any failure:
     - baseline environment/dependency issue
     - net-new regression
     - mixed
4. Workspace and scope check
   - Record current diff scope and changed files.
5. Security baseline check
   - Identify security-sensitive areas touched by the ticket (authn/authz, input validation, data access, file/document handling, logging, external service calls).
   - Capture known baseline security findings if available.
6. Coding standards baseline check
   - Identify compile-branch equivalent coding patterns for touched domain areas.
   - Capture any baseline deviations in existing converted files to separate from net-new deviations.
7. Sensitive data boundary check
   - Identify and exclude sensitive files/paths from discovery and review scope.
   - Do not read secrets, tokens, credential stores, private keys, license files, or protected config values.

## Build Machine Readiness Automation (Required)

Agents must treat machine readiness as an automated SDLC gate, not a manual note.

### Hard rules — enforced on every run

- **READ-ONLY gate only.** The readiness script checks state; it never installs, downloads, or modifies anything. If it reports FAIL, record the failure and stop — do NOT attempt to fix it.
- **No remediation loops.** Never attempt to install a missing tool (MSBuild, dotnet, npm packages, SVN, DLLs, etc.) in response to a readiness FAIL. Direct the user to install manually and set `Proceed: No`.
- **Run once — no retries.** Run `run-machine-readiness.ps1` exactly once. If the script itself errors, report the error inline and continue with the rest of the preflight. Do not re-run the script.
- **Missing framework DLLs under `C:\Program Files\RTWApps\` are a known baseline state** for this repo — compile-branch DLL gaps are expected and pre-documented. Classify them as `baseline environment` not `blocker`. Do not attempt to run the bootstrapper or reinstall RTW apps to resolve them.
- **Toolchain FAIL (MSBuild or dotnet missing) is a hard blocker.** Set `Proceed: No`, list the missing tool, and tell the user to install it manually. Do not attempt silent installation.

1. Run in read-only mode before implementation/review verdicts:
   - `.github/Prompts/hooks/run-machine-readiness.ps1` from repo root
   - MSBuild and dotnet availability
   - RTW dependency paths under `C:\Program Files\RTWApps\`
   - Key framework DLL presence required by project HintPath references
   - Baseline solution build and baseline test run (Dev mode only — QA mode uses `-SkipBuild -SkipTests`)
2. Report required outputs:
   - Machine readiness: PASS/FAIL
   - Build baseline: PASS/FAIL (Dev) / SKIPPED (QA)
   - Test baseline: PASS/FAIL (Dev) / SKIPPED (QA)
   - Failure classification: `baseline environment/dependency` | `toolchain blocker` | `net-new regression`
   - Readiness evidence artifact or inline JSON summary from script output
3. Gate rule:
   - Do not classify ticket changes as regressions until machine-readiness checks are complete and documented.
   - Missing DLLs under RTWApps alone do not set `Proceed: No` — they are pre-existing baseline gaps.

## Pull Request Body Formatting Guardrail (Required)

Apply this rule to every `gh pr create` and `gh pr edit` call.

1. Formatting rule
   - PR body must be valid markdown with real line breaks.
   - Literal escaped newline text such as `\\n` is not allowed in final PR body content.
2. Construction rule
   - Use `--body-file <path>` whenever possible.
   - If using inline body text in PowerShell, use a here-string (`@' ... '@`) and pass the variable to `--body`.
   - Do not pass a double-quoted string containing `\n` escape sequences.
3. Verification rule
   - After PR create/edit, run `gh pr view <number> --json body`.
   - If `\\n` appears in output, immediately re-run `gh pr edit` with a here-string/body-file fix before completing the task.

## Sensitive Data Access Policy (Required)

Agents must not read, extract, or copy sensitive information during implementation or review.

### Prohibited data access

- API keys, tokens, passwords, connection secrets, and credential files.
- Private keys, certificates with private material, signing keys, and key stores.
- License files, proprietary license keys, and entitlement files.
- Environment files or config sections containing secret values.
- Any file explicitly marked confidential, secret, or restricted.

### Allowed behavior

- Work with code structure, signatures, and non-sensitive metadata only.
- If sensitive values are needed to reason about behavior, use redacted placeholders and continue without reading the actual value.
- Request user confirmation to proceed with sanitized alternatives when needed.

### Enforcement

- If a task requires reading prohibited sensitive content, stop and report BLOCKED.
- If sensitive content is encountered accidentally, stop immediately, do not repeat or store it, and continue only with redacted/sanitized context.

## Mandatory Ecosystem Discovery Protocol

All implementation and review workflows must perform this protocol before final conclusions.

### Two-pass search rule (required)

1. Pass A: targeted discovery
   - Search topic-specific files/classes first in:
   - RHH and RTWI framework repository usage on `dev`
     - VB6 source for behavior parity
     - SQL scripts for stored procedure names
2. Pass B: ecosystem sweep
   - If Pass A is incomplete, run a broader sweep across:
   - The owning local `RTW-RHH` or `RTW-RTWI` Git repository on `dev`
     - `XCAM.UI\XCAM VB6 Source\`
     - `XCAM.UI\SQL Scripts\`

### Mandatory legacy trace evidence (required when legacy parity is in scope)

Before implementation/review is considered complete, capture and report:
1. VB6 client file(s), procedure name(s), and user flow points.
2. ASP endpoint file and `Method` parameter value used by the legacy path.
3. Stored procedure name(s) identified from ASP/subproject source.
4. Owning framework repository equivalent framework/SOA method and signature.
5. Reuse-vs-new implementation decision with rationale.
6. Comparison against the `GetEmployerByCheckNumber` layering pattern when selecting implementation approach.

### Source-of-truth precedence (required)

Resolve implementation choices in this order:
1. Compile branch framework implementations and existing usage patterns.
2. SOA wrapper methods (`RHH.SOA.*` / `RTWI.SOA.*`) mapped from stored procedures.
3. VB6 + ASP behavior parity for business rules and user-visible messaging.
4. SQL scripts for validation and cross-check, not as direct replacement for framework/SOA calls.

### Compile-branch-first hard gate

If a relevant equivalent implementation exists in compile branch and is not evaluated before custom implementation, the run is BLOCKED and must be revised.

If legacy parity is required and endpoint/Method/stored-procedure evidence is missing without explicit blocker explanation, the run is BLOCKED and must be revised.

## Efficiency Mode (Required)

Apply these rules to reduce unnecessary scanning and runtime while preserving correctness.

### Fast-path rule

- Skip Pass B when Pass A finds compile-branch equivalent coverage for all acceptance criteria and confidence is High for each criterion.
- If any criterion remains unmatched or confidence is Medium/Low, run Pass B only for those unresolved criteria.

### Deterministic discovery order

For every criterion, search in this fixed order and stop when sufficient evidence is found:
1. Compile branch equivalent implementation and usage pattern.
2. SOA wrapper mapped from stored procedure names.
3. VB6/ASP parity for business rules and user-visible messages.
4. SQL scripts for validation cross-check.

### Search budgets

- Ticket links: inspect at most 3 linked issues unless current AC explicitly requires more.
- Pass A: scan up to 25 candidate files per criterion before escalating.
- Pass B: scan up to 60 additional candidate files total for unresolved criteria.
- If budgets are exceeded, stop and report BLOCKED with required follow-up.

### AC-driven stop condition

- Stop discovery as soon as every acceptance criterion has at least one evidence candidate with confidence High or Medium.
- Continue deeper discovery only for criteria with Low confidence or conflicting evidence.

### Confidence-based escalation

Use confidence levels per acceptance criterion:
- High: direct compile/SOA equivalent + matching behavior evidence.
- Medium: partial equivalent with small mapped adaptation.
- Low: inferred path with gaps, ambiguity, or conflicting signals.

Escalation rules:
- Any Low confidence criterion requires Pass B for that criterion.
- Any unresolved criterion after Pass B is BLOCKED.

### Scoped validation shortcuts

- Prefer focused build/test runs for changed projects first.
- Run full solution build and full test suite only when:
   - focused validation fails, or
   - shared/cross-cutting modules are touched, or
   - ticket explicitly requires full regression.

## Security and Vulnerability Guardrails (Required)

Apply these controls for all implementation and review workflows.

### Secure implementation rules

- Never introduce hardcoded secrets, tokens, credentials, connection strings, or private keys.
- Validate and sanitize all external inputs before use (UI inputs, query/payload parameters, file metadata, XML fields).
- Use parameterized framework/SOA data access paths only; never introduce string-concatenated SQL.
- Preserve authorization and access checks for sensitive actions and records.
- Avoid logging sensitive data (PII, credentials, security tokens, full payload dumps).
- Fail closed for authorization or validation failures and return safe user-facing errors.

### Legacy migration security rules

- Do not port insecure VB6-era patterns (implicit trust of client input, broad exception suppression, unrestricted document/file operations).
- When legacy behavior conflicts with security best practices, implement secure behavior and document parity impact in follow-up notes.

### Vulnerability gate

- Any newly introduced Critical or High vulnerability is an automatic BLOCKED result.
- Any newly introduced Medium vulnerability requires explicit mitigation plan and owner before approval.
- If a vulnerability cannot be verified due to tooling/environment limits, mark as NEEDS REVISION with required follow-up.

### Security review scope

For touched code paths, explicitly review:
- Input validation and output encoding needs.
- Authorization checks and data exposure boundaries.
- Exception handling safety (no hidden failures, no sensitive leakage).
- Dependency and package risk changes in touched projects.
- File/document handling constraints (type, path, size, permissions) where applicable.

## RTW Coding Standards Alignment (Required)

All implementation and review workflows must align new/changed code with compile-branch and framework patterns.

### Service and UI layering rules

- UI forms must not perform raw backend access; call service-layer methods only.
- Service methods must remain async for I/O paths and follow existing naming conventions.
- Prefer existing framework wrappers (`RHH.Framework.*`, `RTWI.Framework.*`, `RHH.SOA.*`, `RTWI.SOA.*`) over custom integration code.
- Reuse compile-branch patterns before introducing new abstractions.

### Error handling and observability rules

- Do not swallow exceptions.
- Ensure catch paths in changed code report via standardized application error handling patterns used in this repo.
- Keep user-facing messages safe and actionable; avoid exposing internals.

### Data contracts and compatibility rules

- Preserve established XML/DataTable/DataSet field names unless ticket explicitly requires contract change.
- If mapping/adaptation is required, keep it in service layer and document the rationale.
- Maintain pipe-delimited parameter conventions where existing interfaces require them.

### Test and verification rules

- Add/update tests following existing project layering conventions (behavioral vs contract vs metadata tests).
- Prefer focused validation first, then full validation when required by shared gates.
- Every net-new public contract change must have explicit test evidence.

### Standards deviation handling

- If a net-new standards deviation is required, record:
   - What deviates
   - Why it is required
   - Risk
   - Approval owner/follow-up

## Fallback Policy

### Hard-stop conditions

Stop and report blocker immediately when any of the following applies:
- Jira authentication/authorization failure (401/403).
- Ticket/resource not found (404).
- Missing acceptance criteria text.
- Required prerequisite sources/branches unavailable after prerequisite workflow steps.
- No approved framework/SOA equivalent exists and implementation would require bypassing architecture constraints.
- A relevant compile-branch equivalent exists but was not evaluated first.
- The workflow requires reading prohibited sensitive data to continue.

### Soft-fallback conditions

Continue with explicit disclosure when any of the following applies:
- Partial metadata is available but acceptance criteria are complete.
- Equivalent framework behavior is clear even if VB6 reference coverage is partial.
- Build/test failures are environment or baseline related and unrelated to changed scope.
- Small data-shape differences can be safely adapted via service-layer mapping.

### Retry rules

- 429: retry up to 3x, wait Retry-After header or 10s default.
- 500/503: retry up to 3x with backoff 2s, 5s, 10s.
- Timeout/MCP unreachable: retry up to 3x with 5s wait.
- After 3 consecutive failures for a call, stop and report blocker.

### Resume behavior after recoverable failure

- Recoverable failures include: MCP timeout/unreachable, 429, 500, 503, and transient tool cancellation.
- Persist a step checkpoint in output whenever a recoverable failure pauses execution:
   - Last successful step
   - Current failed step
   - Remaining steps
   - Next immediate action on resume
- On resume, continue from the failed step after prerequisite re-validation. Do not repeat earlier completed stages unless evidence is stale or conflicting.

## Mandatory Post-Hook Release Gate

1. Evidence completeness gate
   - Every acceptance criterion must be PASS with evidence or FAIL/BLOCKED with explicit gap reason.
2. Regression gate
   - Distinguish baseline failures from net-new failures.
   - Net-new build or test failures block completion.
3. Architecture gate
   - No prohibited direct dependency patterns introduced.
   - Required async/error-handling standards remain enforced.
4. Delivery transparency gate
   - Report fallbacks invoked, assumptions, risks, and required follow-ups.
5. Ecosystem coverage gate
   - Confirm Pass A and Pass B outcomes are documented.
   - Confirm source-of-truth precedence was followed.
   - Confirm compile-branch equivalent evaluation evidence is present.
6. Legacy trace evidence gate
   - When legacy parity is in scope, confirm endpoint file, `Method` value, stored procedure(s), and compile equivalent decision are present.
   - Confirm reuse-vs-new rationale references the `GetEmployerByCheckNumber` pattern where applicable.
7. Efficiency compliance gate
   - Confirm fast-path was used when eligible.
   - Confirm search budgets and stop conditions were respected.
   - Confirm confidence levels are reported per criterion.
8. Security gate
   - Confirm secure implementation rules were applied.
   - Confirm no new Critical/High vulnerabilities were introduced.
   - Confirm security findings, mitigations, and residual risks are documented.
9. Coding standards gate
   - Confirm RTW coding standards alignment checks were applied.
   - Confirm compile-branch equivalent patterns were reused where applicable.
   - Confirm net-new standards deviations are documented with owner and follow-up.
10. Sensitive data handling gate
   - Confirm no prohibited sensitive files or secret-bearing values were read.
   - Confirm any accidental exposure was stopped, sanitized, and documented.
11. Prerequisite and resume gate
   - Confirm MCP/Jira prerequisite validation is present for the active run.
   - Confirm paused runs resumed from checkpoint instead of restarting full workflow.
12. Execution telemetry gate
   - Confirm final output includes iteration count and token usage (or explicit runtime-unavailable disclosure with proxy metrics).

## Required Fallback Disclosure

When any soft-fallback is used, include:
- Assumption
- Reason
- Evidence
- Risk
- Follow-up

## Shared Output Evidence Schema

Use this schema for final delivery output in both Dev Agent and QA Agent.

### 0. Ecosystem Discovery Log

| Area | Pass | Location Searched | Match Found | Selected Source | Why Selected |
|---|---|---|---|---|---|
| [policy/cancel/notes/etc.] | A / B | [path or namespace] | Yes / No | [Compile/SOA/VB6/SQL] | [short rationale] |

### 0.1 Legacy Trace Summary (when in scope)

| Item | Evidence |
|---|---|
| VB6 file + procedure | [path + method/sub] |
| ASP endpoint file | [path/file.asp] |
| Method parameter value | [value] |
| Stored procedure(s) | [name(s)] |
| Compile equivalent | [namespace.class.method(signature)] |
| Reuse-vs-new decision | [decision + rationale] |
| GetEmployerByCheckNumber comparison | [match/delta summary] |

### 1. Acceptance Criteria Coverage

| # | Acceptance Criterion | Status | Evidence / Gap |
|---|---|---|---|
| 1 | [criterion text] | PASS / FAIL / BLOCKED | [file + line evidence, or explicit gap] |

### 1.1 Confidence by Criterion

| # | Confidence | Why |
|---|---|---|
| 1 | High / Medium / Low | [brief rationale] |

### 2. Fallbacks Invoked

| Area | Fallback Type | Assumption | Risk | Follow-up |
|---|---|---|---|---|
| [ticket fetch/build/tests/diff/implementation] | Hard-stop / Soft-fallback / None | [text] | [text] | [text] |

### 3. Baseline vs Net-New Failures

| Area | Baseline | Net-New | Notes |
|---|---:|---:|---|
| Build | [count] | [count] | [text] |
| Tests | [count] | [count] | [text] |

### 3.1 Security and Vulnerability Review

| Area | Baseline | Net-New | Severity | Mitigation / Follow-up |
|---|---:|---:|---|---|
| Security findings | [count] | [count] | [Critical/High/Medium/Low] | [text] |
| Dependency vulnerabilities | [count] | [count] | [Critical/High/Medium/Low] | [text] |

### 3.2 RTW Coding Standards Compliance

| Area | Baseline Deviations | Net-New Deviations | Status | Notes / Owner |
|---|---:|---:|---|---|
| Service/UI layering | [count] | [count] | PASS / NEEDS REVISION | [text] |
| Error handling pattern | [count] | [count] | PASS / NEEDS REVISION | [text] |
| Data contract compatibility | [count] | [count] | PASS / NEEDS REVISION | [text] |
| Test coverage for net-new contracts | [count] | [count] | PASS / NEEDS REVISION | [text] |

### 4. Decision Summary

- Overall result: [APPROVED / NEEDS REVISION / BLOCKED]
- Key blockers (if any): [bullet list]
- Required follow-ups: [bullet list]

### 4.2 Resume Checkpoint (when applicable)

| Field | Value |
|---|---|
| Last successful step | [text] |
| Failed step | [text] |
| Resume action | [text] |
| Revalidated prerequisites | Yes / No |

### 4.1 Sensitive Data Handling

| Check | Result | Notes |
|---|---|---|
| Prohibited sensitive data access avoided | PASS / NEEDS REVISION / BLOCKED | [text] |
| Any accidental exposure sanitized and documented | PASS / NEEDS REVISION / BLOCKED | [text] |
