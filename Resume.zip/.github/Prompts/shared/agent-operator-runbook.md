# Agent Operator Runbook

Purpose: one-page operating guide for the Dev/QA multi-agent workflow during SVN-to-Git transition.

## Scope

- Repository migration target: https://github.ent.stateauto.com/StateAuto/rtw-xcam
- Current mode: transition period (SVN history may still exist; Git-first workflow required).

## Architecture map

| Layer | Files | Purpose |
|---|---|---|
| Orchestrator | .github/Prompts/agents/orchestrator-agent.md | Sequences Pre-Hook -> Dev -> Post-Hook -> Jira handoff -> Build+Launch Gate -> Pre-Hook -> QA -> Post-Hook -> branch, for one ticket end-to-end |
| Hooks | .github/Prompts/hooks/shared-preflight.md (pre), .github/Prompts/hooks/shared-posthook.md (post) | Reusable gate checks run at the start and end of every agent stage |
| Agents | .github/Prompts/agents/dev-agent.md, .github/Prompts/agents/qa-agent.md | Specialist implementation / review workflows |
| Skills | .github/Prompts/skills/*.md | Reusable knowledge modules referenced by multiple agents (Jira evidence extraction, visual comparison protocol, multi-agent handoff contract) |
| Guardrails | .github/Prompts/shared/shared-agent-guardrails.md | Single source of truth for gate definitions, fallback policy, security/standards rules |

## Standard execution order (manual, single agent)

Kickoff contract (preferred)
- `Parent branch: <branch-name>`
- `Ticket: <JIRA-ID>`
- `Run workflow.`

Branch behavior
- Use the provided parent branch as base.
- If parent branch is omitted, default to `Phase2`.
- Use Jira key as feature branch name.

P. Pre-Implementation Plan gate (required — Dev only)
- Before any state-changing execution, the Dev Agent must present a structured Pre-Implementation Plan (see `dev-agent.md` Step P):
  - Objective (one sentence)
  - Acceptance Criteria (numbered list from Jira)
  - Affected Files with one-line reasons
  - Implementation Approach per file (VB.NET pattern mapping)
  - Legacy VB6 Trace (VB6 source file, ASP endpoint, method, stored procedure — when applicable)
  - Framework Repository Check (required RHH and/or RTWI repository verified on `dev`)
  - Test Plan (tests added/updated per AC)
  - Risks / Assumptions
  - Estimated Steps
- User reviews and requests revisions until satisfied, then types `Approve`.
- This is a HARD STOP — no source file changes until explicit approval is given.

0. Run MCP/Jira prerequisite handshake
- Validate MCP connectivity and Jira access before any ticket operation:
  - `getAccessibleAtlassianResources`
  - `atlassianUserInfo`
  - lightweight ticket read (`getJiraIssue` summary/status)
- On transient failure, apply retry rules from shared guardrails.

1. Run Shared Preflight (Pre-Hook)
- Prompt: .github/Prompts/hooks/shared-preflight.md
- Required result: Proceed: Yes
- Required evidence: automated machine-readiness output from .github/Prompts/hooks/run-machine-readiness.ps1

2. Run primary agent
- Development work: .github/Prompts/agents/dev-agent.md
- QA validation: .github/Prompts/agents/qa-agent.md
- Require a commit/push review checkpoint before any branch push (files, summary, commit message, explicit Approve/Revise).

3. Run Shared Post-Hook
- Prompt: .github/Prompts/hooks/shared-posthook.md
- Required result: Overall: RELEASE (not HOLD) before treating the agent's output as final
- Confirm machine-readiness evidence and baseline classification are included and traceable

4. Publish evidence
- QA must post verdict and evidence tables to Jira comments.
- Screenshot upload to Jira is a known, permanent tooling limitation (no attachment tool available) - see skill-visual-comparison-protocol.md. Include the "Visual Comparison Not Performed - Tooling Limitation" section instead of retrying.

4.5. Build + Launch Gate (required before QA starts)
- After Dev Post-Hook RELEASE, build the full solution and launch the application.
- See `orchestrator-agent.md` Stage 4.5 for exact commands and gate decision table.
- Net-new build errors or crash on startup → HOLD → return to Dev.
- Known baseline DLL failures → classify, note, and proceed to QA.
- Leave the application running for QA functional verification.

4.6. QA Test Plan gate (required before QA executes)
- QA Agent must present a QA Test Plan (see `qa-agent.md` Step P) before executing any checks:
  - Every AC with verification method and expected evidence
  - Positive and negative functional scenarios per AC
  - Regression areas
  - Known limitations (what cannot be tested)
  - Build + Launch status confirmation
- User must approve the test plan before QA execution begins.

4.7. PR publish checkpoint (when PR submission is in scope)
- PR automation is the default after QA approval.
- Present base/head, title, body, and file-scope preview.
- Ask one follow-up question: "PR preview is ready. Raise PR now, or defer?"
  - `Raise PR` (default): publish PR.
  - `Defer`: stop with branch-only delivery.
- Never auto-merge after PR publish.

5. Completion telemetry (required)
- Every completed agent run must report:
  - iteration count
  - tool-call count
  - files changed count (or issues changed count for Jira-only runs)
  - token usage input/output/total if runtime exposes it
  - otherwise: `Token usage: UNAVAILABLE IN THIS RUNTIME` and proxy metrics

## Standard execution order (orchestrated, full ticket)

Run .github/Prompts/agents/orchestrator-agent.md with the ticket number. It sequences the same
Pre-Hook -> Agent -> Post-Hook cycle for both Dev and QA, applies the Multi-Agent Handoff
contract (skill-multi-agent-handoff.md) between stages, performs the Jira status transitions,
and produces one final Orchestration Report. Use this instead of running Dev/QA manually
whenever you want the full ticket lifecycle handled in one pass.

Do not let the orchestrator loop QA -> Dev -> QA more than once automatically - a second
revision cycle requires explicit user confirmation.

If a run pauses due to recoverable tooling failure, resume from the failed step/stage checkpoint
after revalidating MCP/Jira prerequisites; do not restart the full workflow.

## Fast-stop rules

Stop and report NEEDS REVISION or BLOCKED when:
- Jira issue cannot be read with current permissions.
- Acceptance criteria are missing or not testable.
- Required guardrail evidence is missing.
- Build or tests fail due to net-new change.
- A compile-branch equivalent was required but not evaluated first.
- Legacy-parity evidence is required but missing (ASP endpoint file, `Method` value,
  stored procedure(s), and reuse-vs-new equivalent-call decision).

## Git transition rules

- Use Git-first discovery for change evidence.
- If local Git history is unavailable, use Jira-linked evidence and mark confidence Medium/Low.
- Do not require SVN CLI setup for routine agent execution.
- Legacy SVN helper prompt remains reference-only for VB6 source tracing:
  - .github/Prompts/bootstraps/ensure-vb6-source.md
  - .github/Prompts/bootstraps/ensure-compile-branch.md (retired for .NET framework source)
- Use `.github/Prompts/bootstraps/ensure-framework-repositories.md` for RHH and RTWI framework source.

## Minimum QA evidence package

- Verdict: APPROVED or NEEDS REVISION
- Executive Summary
- AC Coverage table
- Legacy Trace Summary (when in scope): endpoint, `Method`, stored procedure, equivalent-call decision
- Functional Test Evidence table
- Visual Comparison Evidence table (or the tooling-limitation disclosure)
- Jira Publication Status
- Fallback disclosures and risks
- Post-Hook result (Overall: RELEASE / HOLD)
- Multi-Agent Handoff block (QA -> Orchestrator) per skill-multi-agent-handoff.md

## Weekly operating metrics

Track these from QA outputs:
- Time to first defect found
- Re-test cycle count
- Targeted tests executed
- Full-suite run required (Yes/No)

## Owner checklist

- Keep shared guardrails, preflight (pre-hook), and post-hook current together - they must reference the same gate names.
- Keep the readiness script and checklist aligned with hook/guardrail requirements:
  - .github/Prompts/hooks/run-machine-readiness.ps1
  - .github/XCAM-BUILD-MACHINE-READINESS-CHECKLIST.md
- Keep skills (.github/Prompts/skills/*.md) as the single source of truth for logic shared by Dev and QA; update the skill, not each agent, when that logic changes.
- Keep orchestrator-agent.md's stage table in sync if any prompt file is renamed or moved.
- Retire legacy SVN helper prompts after Git migration cutover.
- Revisit skill-visual-comparison-protocol.md once Jira attachment upload/download tooling becomes available - this is currently a hard tooling limitation, not a placeholder.
