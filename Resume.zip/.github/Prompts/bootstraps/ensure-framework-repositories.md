---
agent: "agent"
name: "Ensure Framework Repositories"
argument-hint: "Run to verify the RHH and RTWI Git repositories are cloned and current on dev"
tools: ['terminal']
description: Clone or update the RHH and RTWI framework source repositories from Git
---

# Ensure Framework Repositories

Verify the framework source repositories are available and current on their `dev` branches:

- `https://github.ent.stateauto.com/StateAuto/RTW-RHH` for RHH framework domains.
- `https://github.ent.stateauto.com/StateAuto/RTW-RTWI` for RTWI framework domains.

Use local paths from `.vscode/xcam-dev-config.json` when `frameworkSource.rhh` and `frameworkSource.rtwi` are configured. Otherwise, clone missing repositories as sibling folders of the XCAM Git checkout.

## Step P — Execution preview and approval gate

Before clone, fetch, checkout, or pull actions, present an **Execution Preview** including:
- Objective summary
- Planned commands
- Paths to be touched
- Risks/assumptions/blockers
- Estimated iterations and token budget/range

Then ask for `Approve` or `Revise`. Do not run state-changing commands until approved.

## Step 1 — Resolve paths and inspect repository state

For each required repository, determine its local path and confirm that it is a Git working tree with an `origin` remote pointing to the expected repository.

## Step 2 — Clone or synchronize the `dev` branch

**If absent** — clone the repository on its `dev` branch:

```powershell
git clone --branch dev --single-branch "<repository URL>" "<local path>"
```

**If already present** — synchronize it without discarding local work:

```powershell
git -C "<local path>" fetch origin dev
git -C "<local path>" checkout dev
git -C "<local path>" pull --ff-only origin dev
```

If checkout or fast-forward is blocked by local changes, stop and report the repository and its Git status. Do not stash, reset, or discard changes.

## Step 3 — Confirm

For each repository, report:
- Local path
- `origin` URL
- Current branch, which must be `dev`
- Current commit SHA
- Working-tree status

## Step 4 — Completion telemetry (mandatory)

Report:
- Iterations performed
- Tool-call count
- Paths changed count
- Token usage if available, otherwise `Token usage: UNAVAILABLE IN THIS RUNTIME` + proxy metrics