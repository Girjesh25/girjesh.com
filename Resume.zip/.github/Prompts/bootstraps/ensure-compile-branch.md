---
agent: "agent"
name: "Ensure Compile Branch"
argument-hint: "Run to verify the compile branch exists and is updated"
tools: ['terminal']
description: Check out or update the .NET compile branch from SVN
---

> LEGACY PROMPT (SVN-ERA): Use only before Git migration is complete. Prefer Git-era branch sync once repository migration to StateAuto/rtw-xcam is finalized.

# Ensure Compile Branch — SVN Checkout Utility

Verify the compile branch is checked out at `C:\Users\n1646072\Development\Source\.NET\Branches\Compile\` and up to date.

## Step P — Execution preview and approval gate

Before checkout/update actions, present an **Execution Preview** including:
- Objective summary
- Planned commands
- Paths to be touched
- Risks/assumptions/blockers
- Estimated iterations and token budget/range

Then ask for `Approve` or `Revise`. Do not run state-changing commands until approved.

## Step 1 — Check folder state

Run:

```powershell
$compileBranch = "C:\Users\n1646072\Development\Source\.NET\Branches\Compile"
$isEmpty = -not (Test-Path $compileBranch) -or (Get-ChildItem $compileBranch -Recurse -File | Measure-Object).Count -eq 0
Write-Host "Compile branch ready: $(-not $isEmpty)"
```

## Step 2 — Check out or update

**If empty or absent** — check out from SVN:

```powershell
svn checkout "https://svnprod.corp.stateauto.com/svn/RTW/.NET/Branches/Compile" "C:\Users\n1646072\Development\Source\.NET\Branches\Compile"
```

**If already present** — update to latest:

```powershell
svn update "C:\Users\n1646072\Development\Source\.NET\Branches\Compile"
```

> **If `svn` is not recognised** — stop and tell the user: *"Install TortoiseSVN with command-line tools enabled (or Apache Subversion), add it to the PATH, then re-run this prompt."*

## Step 3 — Confirm

Re-run the check from Step 1 and report the final file count in `C:\Users\n1646072\Development\Source\.NET\Branches\Compile`.

## Step 4 — Completion telemetry (mandatory)

Report:
- Iterations performed
- Tool-call count
- Paths changed count
- Token usage if available, otherwise `Token usage: UNAVAILABLE IN THIS RUNTIME` + proxy metrics
