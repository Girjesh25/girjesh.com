---
agent: "agent"
name: "Ensure VB6 Source"
argument-hint: "Run to verify the VB6 source folders are present"
tools: ['terminal']
description: Clone or update VB6 source folders from Git if missing or empty
---

# Ensure VB6 Source — Git Checkout Utility

Verify both required VB6 source folders exist under `XCAM.UI\XCAM VB6 Source\` and are current from `StateAuto/RTW-VB6`:

- VB6 client test source: `RTWI/XCAM`
- ASP backend trunk source: `trunk/XCAM`

## Step P — Execution preview and approval gate

Before checkout actions, present an **Execution Preview** including:
- Objective summary
- Planned commands
- Paths to be touched
- Risks/assumptions/blockers
- Estimated iterations and token budget/range

Then ask for `Approve` or `Revise`. Do not run state-changing commands until approved.

## Step 1 — Check folder state

Run:

```powershell
$xcamVb6Repo   = "XCAM.UI\XCAM VB6 Source\XCAM VB6"
$trunkXcamRepo = "XCAM.UI\XCAM VB6 Source\Trunk XCAM"
$xcamVb6       = Join-Path $xcamVb6Repo "XCAM"
$trunkXcam     = Join-Path $trunkXcamRepo "XCAM"

$vb6Empty   = -not (Test-Path $xcamVb6)   -or (Get-ChildItem $xcamVb6   -Recurse -File | Measure-Object).Count -eq 0
$trunkEmpty = -not (Test-Path $trunkXcam) -or (Get-ChildItem $trunkXcam -Recurse -File | Measure-Object).Count -eq 0

Write-Host "XCAM VB6 source ready:   $(-not $vb6Empty)"
Write-Host "Trunk XCAM source ready: $(-not $trunkEmpty)"
```

## Step 2 — Clone or update missing folders

| Folder | Status condition | Git source |
|---|---|---|
| `XCAM VB6` | absent or empty | `https://github.ent.stateauto.com/StateAuto/RTW-VB6`, ref `RTWI`, path `XCAM` |
| `Trunk XCAM` | absent or empty | `https://github.ent.stateauto.com/StateAuto/RTW-VB6`, ref `trunk`, path `XCAM` |

For a missing folder, clone the required ref and use sparse checkout to materialize only its `XCAM` path:

```powershell
git clone --branch RTWI --single-branch --no-checkout "https://github.ent.stateauto.com/StateAuto/RTW-VB6.git" "XCAM.UI\XCAM VB6 Source\XCAM VB6"
git -C "XCAM.UI\XCAM VB6 Source\XCAM VB6" sparse-checkout set XCAM
git -C "XCAM.UI\XCAM VB6 Source\XCAM VB6" checkout RTWI

git clone --branch trunk --single-branch --no-checkout "https://github.ent.stateauto.com/StateAuto/RTW-VB6.git" "XCAM.UI\XCAM VB6 Source\Trunk XCAM"
git -C "XCAM.UI\XCAM VB6 Source\Trunk XCAM" sparse-checkout set XCAM
git -C "XCAM.UI\XCAM VB6 Source\Trunk XCAM" checkout trunk
```

For an existing checkout, verify its expected branch (`RTWI` or `trunk`) and update its enclosing repository without discarding local changes:

```powershell
git -C "<repository folder>" fetch origin <branch>
git -C "<repository folder>" checkout <branch>
git -C "<repository folder>" pull --ff-only origin <branch>
```

If checkout or fast-forward is blocked by local changes, stop and report the repository and its Git status. Do not stash, reset, or discard changes.

## Step 3 — Confirm

Re-run the check from Step 1 and report the final ready state of both folders.

## Step 4 — Completion telemetry (mandatory)

Report:
- Iterations performed
- Tool-call count
- Paths changed count
- Token usage if available, otherwise `Token usage: UNAVAILABLE IN THIS RUNTIME` + proxy metrics
