# XCAM Developer Notes

Captured from Copilot Chat session � 2026-07-10.
Use this file with `#file:.github/dev-notes.md` to restore context in a new chat session.

---
## Session: 2026-08-03 Phase2 pull — OnAccount + PolicyService + frmPolicy history

### What was pulled (Phase2 branch)
New files:
- `XCAM.Core/OnAccountModels.vb`: 7 model classes for Account tab on-account workflow (`OnAccountItem`, `OnAccountStatement`, `OnAccountResult`, `RevenueDetailLine`, `RevenueDetailHeader`, `OnAccountCheckDetail`, `OnAccountCheck`).
- `XCAM.Services/PolicyDetailModel.vb`: `PolicyDetailModel` class (in `XCAM.Core` namespace) — strongly-typed model parsed from POLICY XML with POLICY / POLICYEVENT / POLICYSTATE attributes.
- `XCAM.Services/PolicyService.vb`: `PolicyService` wrapping `RTWI.Framework.Policies.Policy` — `GetPolicyByTrIDAsync` (→ DataSet) and `GetPolicyDetailAsync` (→ PolicyDetailModel).
- `XCAM.Test/Core/OnAccountModelsTests.cs`: behavioral tests for OnAccount model classes.
- `XCAM.Test/UI/FrmPolicyContractTests.cs`: contract tests for frmPolicy constructor/property signatures.

Major updates:
- `AccountingService.vb`: added `LoadEmployersByStatementNumberAsync`, `LoadEmployersByCheckNumberAsync`, `LoadOnAccountAsync`, `LoadOnAccountLedgerAsync`, `LoadRevenueDetailsAsync`, `LoadAgencySearchAsync`, `LoadPolicySearchInformationAsync`. **Removed `CheckUserAccessAsync`** — access check moved to `Program.vb` using `userProfile.IsApplicationAccessible(33)`.
- `InsuredService.vb`: added `GetPolicyDataSetAsync`, `GetPolicyCompleteAsync`, `GetPaymentPlanDescriptionAsync`, `GetEmployerBillingAsync`, `UpdateEmployerBillingCommentAsync`, `UpdateEmployerBillingDueDayAsync`, `GetEmployerBillingDueDayAsync`, `GetPolicyEventsAsync`, `GetAgencyCommissionPercentAsync`.
- `frmPolicy.vb`: constructor now takes `PolicyService` as 5th param; `_policyDetail As PolicyDetailModel` added; `LoadPolicyHistoryAsync` fully implemented via `_insuredSvc.GetPolicyEventsAsync` (resolves prior stub).
- `frmEmployer.vb`: constructor now takes `AccountingService` + `MasterTablesService`; Account tab implemented with `_onAccountResult As OnAccountResult`.
- `frmNote.vb`: `UpdateNoteDocumentAsync` now wired — save is functional (resolves prior TODO).
- `frmMain.vb`: `_policySvc = New PolicyService(_userProfile)` added; `_searchLoader As SearchGridLoader` added.

### Build status
Full solution build **currently fails** — new calls to `EmployersFramework.GetOnAccountBalance`, `GetStatementDisplayRevenues`, `GetOnAccount`, `GetPolicyRevenueDetails`, `GetAgencyOrAssociationInformation`, and `Policy.GetPolicyByTrID` are not in the DLLs at `C:\Program Files\RTWApps\`. Framework DLL update required before the solution compiles.

### Test status (stale binary run)
- Total: 141 | Passed: 140 | Failed: 1
- Failing test: `AccountingServiceContractTests.CheckUserAccessAsync_TakesUserId_ReturnsTaskOfBoolean` — method removed from service, contract test not yet deleted.
- **Action needed**: remove or update that contract test.

---
## Session: 2026-07-14 Copilot instructions refresh for RTWC-2292

### What was done
- Analysed the entire XCAM codebase across all projects:
  - XCAM.Core, XCAM.Services, XCAM.UI, XCAM.Test, XCAM.Installer
  - Config and solution metadata: XCAM.sln, *.vbproj, *.csproj, App.config, Package.wxs
  - Incomplete marker scan: .vb, .cs, .ps1, .md, .wxs, .config (excluding bin/obj/.git/.vs/.tmp)
- Regenerated `.github/copilot-instructions.md` from verified source only.
- No content was guessed or invented � every entry traces to a real source file.

### What the file covers
1. PROJECT IDENTITY � app purpose, users, tech stack, key dependencies.
2. SOLUTION STRUCTURE � every project/folder with responsibility, entry points.
3. ARCHITECTURE & DATA FLOW � layer connections, startup flow, XML handling, key patterns.
4. CODING CONVENTIONS � naming, async/sync, error handling, dependency passing.
5. KNOWN INCOMPLETE AREAS � 44 TODO/STUB/FIXME markers across the codebase (table: File | Line | What).
6. DOMAIN TERMINOLOGY � glossary of all business/domain identifiers found in code.
7. WORKFLOWS � end-to-end feature flow examples, test structure and execution.

### Key facts confirmed from source
- Entry point: `XCAM.UI/Program.vb`, `Module Program`, `Main()`.
- Host resolution: registry `HKLM\SOFTWARE\RTW\Host`, fallback to `App.config` key `XcamHost`.
- Access gate: `userProfile.IsApplicationAccessible(33)` in `Program.vb` — exits if userId = 0 or denied. (`CheckUserAccessAsync` removed from `AccountingService`.)
- Global state: `AppState` module (host, userId, userName, HttpClient, ErrorHandler, GL constants).
- Test count at time of scan: **80 tests, 80 passed, 0 failed** (as of 2026-07-14 initial scan; see session 2026-08-03 for current count).
- Test command: `dotnet test XCAM.Test/XCAM.Test.csproj`

---

## Session: 2026-07-14 Copilot instructions refresh for RTWC-2292

- **Copilot Chat history is NOT persisted** across Visual Studio sessions.
- Switching solutions or reopening VS the next day resets chat context.
- The `.github/copilot-instructions.md` file IS automatically injected into every
  Copilot request and is the most reliable way to carry forward project knowledge.

### Recommended workflow for restoring context in a new session
1. Reference the instructions file at the start of a new chat:
1. Store reusable prompts in `.github/Prompts/` and reference with `#file:`.

---

## Known Incomplete Areas (summary � full table in copilot-instructions.md)

High-priority TODOs identified in source code (not documentation):

| File | Line | What is missing |
|--- | ---: | --- |
| `XCAM.Core/AppState.vb` | 8 | Refactor global module state into DI services. |
| `XCAM.Services/NotesService.vb` | 23�28 | Replace ImageManagerII COM control / implement image handling in .NET. |
| `XCAM.Services/NotesService.vb` | 103 | GetNotesByCategory placeholder not yet implemented. |
| `XCAM.UI/Forms/frmMain.vb` | 344 | Tree selection navigation behavior. |
| `XCAM.UI/Forms/frmMain.vb` | 376 | Load inbox items via MessagingService. |
| `XCAM.UI/Forms/frmGLPost.vb` | 26 | Load pending GL entries into grid. |
| `XCAM.UI/Forms/frmRunCommissions.vb` | 54 | Call commission service logic. |
| `XCAM.UI/Forms/frmCancelRevenues.vb` | 25 | Use real policy id inload call. |
| `XCAM.UI/Forms/frmSuspenseApplication.vb` | 23, 27 | Load suspense items; apply selected suspense amount. |
| `XCAM.UI/Forms/frmSuspensePendingMatch.vb` | 22 | Load pending match items for employer id. |
| `XCAM.UI/Forms/frmTransfer.vb` | 42| Call transfer service for revenue header transfer. |
| `XCAM.UI/Forms/frmCollections.vb` | 31 | Open collection detail behavior. |
| `XCAM.UI/Forms/frmPaymentTypes.vb` | 25 | Populate payment-types grid from loaded data. |

---

## Quick Reference � How to start a new Copilot session for XCAM

Paste the following at the top of any new Copilot Chat to restorefull context:
#file:.github/copilot-instructions.md 
#file:.github/dev-notes.md
I am continuing development on the XCAM WinForms application 
(.NET Framework 4.8, VB.NET). 
Please use the above files as my project context before answering.