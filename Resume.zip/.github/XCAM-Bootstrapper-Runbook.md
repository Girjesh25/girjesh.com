# XCAM & RTWBootstrapper � Operations Runbook

> **Document type:** Confluence Technical Runbook  
> **Application:** XCAM (Expert Claims Accounting Manager) � .NET 4.8 Windows Forms  
> **Bootstrapper:** RTWBootstrapper � .NET 4.0 Windows Forms  
> **Audience:** Development, DevOps, Application Support  
> **Last updated:** 2026

---

## Table of Contents

1. [Overview](#1-overview)
2. [Component Inventory](#2-component-inventory)
3. [How RTWBootstrapper Fits Into the RTW App Suite](#3-how-rtwbootstrapper-fits-into-the-rtw-app-suite)
4. [How the Bootstrapper Works � Step by Step](#4-how-the-bootstrapper-works--step-by-step)
5. [Bootstrapper Sequence Diagram](#5-bootstrapper-sequence-diagram)
6. [What the Bootstrapper Copies to the Client Machine](#6-what-the-bootstrapper-copies-to-the-client-machine)
7. [Local Folder Structure on the Client Machine](#7-local-folder-structure-on-the-client-machine)
8. [Assembly Versioning and Update Logic](#8-assembly-versioning-and-update-logic)
9. [Error Handling � BootstrapperFailed Form](#9-error-handling--bootstrapperfailed-form)
10. [XCAM Startup After Launch](#10-xcam-startup-after-launch)
11. [XCAM App.config � Web Service Endpoints](#11-xcam-appconfig--web-service-endpoints)
12. [Framework DLL Dependency Map](#12-framework-dll-dependency-map)
13. [Server-Side Prerequisites](#13-server-side-prerequisites)
14. [Client-Side Prerequisites](#14-client-side-prerequisites)
15. [Deployment Checklist](#15-deployment-checklist)
16. [Troubleshooting Guide](#16-troubleshooting-guide)

---

## 1. Overview

XCAM is a .NET 4.8 Windows Forms desktop application for Expert Claims Accounting management. Like all RTW Windows applications (e.g. XCM � Case Manager), **XCAM is installed onto each user machine via an MSI installer** as part of the RTW application suite. The MSI deploys the application binaries to `C:\Program Files\RTWApps\XCAM\` and includes `RTWBootstrapper.exe` co-located in the same folder.

However, **users never launch the application EXE directly**. The Start Menu shortcut points to `RTWBootstrapper.exe` with the application's `RTWApplicationListTrID` as a command-line argument. Every time a user opens the app, the bootstrapper runs first and is responsible for:

- Looking up the application and assembly records in the **RTW Master database** using the `RTWApplicationListTrID`
- Comparing the server version of the EXE and all framework DLLs against what is locally installed
- Syncing any outdated or missing files by copying from the server share to the local `C:\Program Files\RTWApps\` folder
- Launching the actual application EXE via `Process.Start` once all files are confirmed up to date

This self-updating launch pattern ensures every user always runs the latest version of both the application and its shared framework dependencies, without requiring a new MSI deployment for every release.

---

## 2. Component Inventory

| Component | Project | Technology | Role |
|---|---|---|---|
| `RTWBootstrapper.exe` | `RTWBootStrapper` | .NET 4.0 WinForms | Launcher � validates, syncs and starts the target app |
| `RTWBootstrapper.exe.config` | `RTWBootStrapper` | XML config | Holds `MasterWS` endpoint URL |
| `XCAM.exe` | `XCAM.UI` | .NET 4.8 WinForms | Main application |
| `XCAM.Core.dll` | `XCAM.Core` | .NET 4.8 Class Library | Global state, error handling, abstractions |
| `XCAM.Services.dll` | `XCAM.Services` | .NET 4.8 Class Library | Service layer � calls RTW web services |
| `RHH.Framework.*.dll` | Shared Framework | .NET | RTW shared libraries (profiles, contacts, diary, etc.) |
| `RTWI.Framework.*.dll` | Shared Framework | .NET | RTW insurance domain libraries (claims, policies, etc.) |
| `RTWI.Windows.*.dll` | Shared Framework | .NET | RTW UI component libraries |
| `MasterWS` | Web Service Proxy | ASMX | Returns application and assembly master data from DB |

---

## 3. How RTWBootstrapper Fits Into the RTW App Suite

All RTW Windows applications follow the same deployment and launch pattern. The bootstrapper is not unique to XCAM � it is the standard launcher for all RTW desktop apps.

### Installation

Each application is **installed via an MSI** as part of the RTW application suite package. The MSI:

- Deploys the application EXE and its config to `C:\Program Files\RTWApps\<AppName>\`
- Deploys `RTWBootstrapper.exe` and `RTWBootstrapper.exe.config` **into the same folder**
- Creates a Start Menu shortcut under `RTW\RTW Applications\`

### The Shortcut Does Not Point to the App EXE

The Start Menu shortcut for every RTW app targets the **bootstrapper**, not the application EXE. For example, for XCM (Case Manager):

```
Target:    C:\Program Files\RTWApps\XCM\RTWBootstrapper.exe
Arguments: 1
```

For XCAM it would be:

```
Target:    C:\Program Files\RTWApps\XCAM\RTWBootstrapper.exe
Arguments: <RTWApplicationListTrID>
```

The integer argument (`1` for XCM, and the appropriate TrID for XCAM) is the **primary key** in the RTW master database that identifies the application record.

### Why This Pattern Exists

| Benefit | Detail |
|---|---|
| **Zero-touch updates** | When a new EXE or DLL is deployed to the server share, every user gets the update on their next launch � no new MSI needed |
| **Shared framework management** | All RTW apps share the same RHH/RTWI framework DLLs in `C:\Program Files\RTWApps\RHH\` and `RTWI\`. The bootstrapper keeps them current for all apps simultaneously |
| **Centrally controlled deprecation** | Old DLL versions are retired by setting `PreferredFlag = 0` in the DB � the bootstrapper deletes them from client machines automatically |
| **Consistent launch experience** | Every RTW app shows the same bootstrapper splash screen with real-time sync progress before the app opens |

---

## 4. How the Bootstrapper Works � Step by Step

### Step 1 � Invocation

The bootstrapper is invoked from a web page, portal link, or shortcut with a single mandatory command-line argument:

```
RTWBootstrapper.exe <RTWApplicationListTrID>
```

**Example:**
```
RTWBootstrapper.exe 3032
```

`RTWApplicationListTrID` is an integer primary key stored in the RTW master database that uniquely identifies the XCAM application record.

---

### Step 2 � Argument Validation (`MainModule.vb`)

`Main()` parses the first command-line argument using `Integer.TryParse`. If parsing fails, a message box is shown:

> *"Invalid command line arguments, pass RTWApplicationListTrID on the command line."*

If valid, a `BootStrapperMain` form is created and passed the ID:

```vb
_bsMain = New BootStrapperMain(_rtwApplicationListTrID)
Application.Run(New ApplicationContext(_bsMain))
```

---

### Step 3 � Database Lookup (`LoadData` in `BootStrapperMain.vb`)

On construction, `LoadData()` calls the **MasterWS web service** to retrieve:

| Call | Returns | Purpose |
|---|---|---|
| `GetApplications(3032)` | `DataSet` | Full application record including `ExeName`, `ApplicationName`, `SetupPath` |
| `GetAssemblyMasters(Executable)` | `DataSet` | EXE assembly records with `ServerPath`, `AssemblyPath`, `RevisionID` |
| `GetAssemblyMasters(Framework)` | `DataSet` | RHH/RTWI Framework DLL records |
| `GetAssemblyMasters(Windows)` | `DataSet` | RHH/RTWI Windows DLL records |

The application record is filtered by `RTWApplicationListTrID` to extract:
- `_exeName` � the EXE file name (e.g. `XCAM`)
- `_applicationName` � display name shown in the splash screen
- `_setupPath` � the server path where the application binaries are deployed

---

### Step 4 � Splash Screen Shown (`BootstrapperMain_Shown`)

Once the form is visible, it executes sequentially:

```
1. GetApplicationFiles()   ? Syncs XCAM.exe + XCAM.exe.config
2. GetAssemblies()         ? Syncs all Framework and Windows DLLs
```

The status strip updates in real time showing the current action (`Validating:` / `Copying:`) and the file name being processed.

---

### Step 5 � EXE Sync (`GetApplicationFiles`)

For `XCAM.exe`:

1. Confirms the local destination folder exists (creates it if not)
2. Loads `AssemblyName` from both the **server path** and the **local path**
3. Compares `Version` � if the client copy is missing or outdated, it copies the EXE from server to client
4. **Always** copies `XCAM.exe.config` from server to client (config is always refreshed, no version check)

---

### Step 6 � Framework DLL Sync (`GetAssemblies`)

For every row in both `_frameworkAssembliesDS` (RHH Framework) and `_windowsAssembliesDS` (RTWI Windows):

1. Reads `RevisionID` (server) and `PreferredFlag` from the DB record
2. If `PreferredFlag = 0` � the DLL is **obsolete**: delete local copy if it exists
3. If `PreferredFlag = 1`:
   - Reads the local file's `ProductPrivatePart` (revision) from `FileVersionInfo`
   - If server `RevisionID ?` local revision ? copies from server to local
4. Updates `LocalRevisionID` column in memory for the error report

Local destination paths follow the pattern defined in `My.Resources.LocalPath`:
- Framework DLLs ? `C:\Program Files\RTWApps\RTWI\Framework\`
- Windows DLLs ? `C:\Program Files\RTWApps\RTWI\Windows\`

---

### Step 7 � Launch or Fail

**If no file errors occurred:**

```vb
Process.Start(
    String.Format("{0}{1}\{2}.exe", LocalPath, _exeName, _exeName),
    String.Format("{0}", _RTWapplicationListTrID)
)
```

XCAM is launched with `RTWApplicationListTrID` as its own command-line argument.

The bootstrapper then fires `DoneLoading(errors:=False)` ? `Application.ExitThread()` and closes itself.

**If file errors occurred:**

The `BootstrapperFailed` dialog is shown (see [Section 9](#9-error-handling--bootstrapperfailed-form)).

---

## 5. Bootstrapper Sequence Diagram

```
User / Portal
    ?
    ?  RTWBootstrapper.exe 3032
    ?
???????????????????????????????????????
?  MainModule.Main()                  ?
?  Parse RTWApplicationListTrID       ?
???????????????????????????????????????
               ? new BootStrapperMain(3032)
               ?
???????????????????????????????????????
?  BootStrapperMain.LoadData()        ?
?  ? MasterWS.GetApplications()      ? ??? RTW MasterWS (DB)
?  ? MasterWS.GetAssemblyMasters()   ? ??? Returns DataSets
???????????????????????????????????????
               ? Form.Shown
               ?
???????????????????????????????????????
?  GetApplicationFiles()              ?
?  Compare server vs local XCAM.exe  ?
?  Copy EXE if version differs       ?
?  Always copy XCAM.exe.config       ?
???????????????????????????????????????
               ?
               ?
???????????????????????????????????????
?  GetAssemblies()                    ?
?  For each Framework DLL:           ?
?    PreferredFlag=0 ? delete local  ?
?    PreferredFlag=1 ? version check ?
?    Copy from server if outdated    ?
?  Repeat for Windows DLLs           ?
???????????????????????????????????????
               ?
       ??????????????????
       ? errors?        ?
      No               Yes
       ?                ?
       ?                ?
Process.Start       BootstrapperFailed
XCAM.exe 3032       dialog shown
       ?
       ?
   XCAM Starts
```

---

## 6. What the Bootstrapper Copies to the Client Machine

### Application Files

| File | Source | Destination | Copy Condition |
|---|---|---|---|
| `XCAM.exe` | Server `ServerPath` | `C:\Program Files\RTWApps\XCAM\XCAM.exe` | Version mismatch only |
| `XCAM.exe.config` | Server `ServerPath` | `C:\Program Files\RTWApps\XCAM\XCAM.exe.config` | Always |

### RHH Framework DLLs (copied to `C:\Program Files\RTWApps\RHH\Framework\`)

| DLL | Purpose |
|---|---|
| `RHH.Framework.Common.dll` | Shared utilities, logging (`Logger.WriteExceptionLogFile`) |
| `RHH.Framework.Common.Exceptions.dll` | Common exception types |
| `RHH.Framework.Common.MasterTables.dll` | Master table cache |
| `RHH.Framework.Common.SpecialHandling.dll` | Special handling rules |
| `RHH.Framework.Common.TimeTracking.dll` | Time tracking domain |
| `RHH.Framework.Contacts.dll` | Contacts domain |
| `RHH.Framework.Employers.dll` | Employers domain |
| `RHH.Framework.FileDocuments.dll` | File/document management |
| `RHH.Framework.FileDocuments.Abstracts.dll` | Abstracts sub-domain |
| `RHH.Framework.FileDocuments.Faxing.dll` | Faxing sub-domain |
| `RHH.Framework.FileDocuments.Letters.dll` | Letters sub-domain |
| `RHH.Framework.Messaging.Diary.dll` | Diary messaging |
| `RHH.Framework.Messaging.Tasks.dll` | Tasks messaging |
| `RHH.Framework.Messaging.SystemNotifications.dll` | System notifications |
| `RHH.Framework.Profiles.dll` | User profile, master client profile access |
| `RHH.Framework.Reports.dll` | Reporting |

### RTWI Windows DLLs (copied to `C:\Program Files\RTWApps\RTWI\Windows\`)

| DLL | Purpose |
|---|---|
| `RTWI.Windows.BaseForms.dll` | Base Windows form classes |
| `RTWI.Windows.Claims.dll` | Claims UI components |
| `RTWI.Windows.Claims.Additional.dll` | Additional claims UI |
| `RTWI.Windows.Claims.AGWW.dll` | AGWW UI |
| `RTWI.Windows.Claims.Authorizations.dll` | Authorizations UI |
| `RTWI.Windows.Claims.Contacts.dll` | Contacts UI |
| `RTWI.Windows.Claims.ControlLibrary.dll` | Shared control library |
| `RTWI.Windows.Claims.Diagnosis.dll` | Diagnosis UI |
| `RTWI.Windows.Claims.Employee.dll` | Employee UI |
| *(and additional Windows DLLs as registered in AssemblyMasters DB)* | |

### RTWI Framework DLLs (copied to `C:\Program Files\RTWApps\RTWI\Framework\`)

| DLL | Purpose |
|---|---|
| `RTWI.Framework.Claims.dll` | Claims domain |
| `RTWI.Framework.Claims.Additional.dll` | Additional claims |
| `RTWI.Framework.Claims.AGWW.dll` | AGWW domain |
| `RTWI.Framework.Claims.Authorizations.dll` | Authorizations |
| `RTWI.Framework.Claims.Contacts.dll` | Claim contacts |
| `RTWI.Framework.Claims.Employee.dll` | Claim employees |
| `RTWI.Framework.Claims.Payments.dll` | Payments |
| `RTWI.Framework.Claims.Reserves.dll` | Reserves |
| `RTWI.Framework.Claims.SettlementRecovery.dll` | Settlement/Recovery |
| `RTWI.Framework.Policies.dll` | Policy domain |
| `RTWI.Framework.Accounting.Payables.dll` | Accounting payables |
| *(and additional framework DLLs as registered in AssemblyMasters DB)* | |

---

## 7. Local Folder Structure on the Client Machine

```
C:\Program Files\RTWApps\
?
??? XCAM\
?   ??? XCAM.exe
?   ??? XCAM.exe.config          ? always refreshed by bootstrapper
?
??? RHH\
?   ??? Framework\
?       ??? RHH.Framework.Common.dll
?       ??? RHH.Framework.Profiles.dll
?       ??? ... (all RHH Framework DLLs)
?
??? RTWI\
    ??? Framework\
    ?   ??? RTWI.Framework.Claims.dll
    ?   ??? RTWI.Framework.Policies.dll
    ?   ??? ... (all RTWI Framework DLLs)
    ?
    ??? Windows\
        ??? RTWI.Windows.BaseForms.dll
        ??? RTWI.Windows.Claims.dll
        ??? ... (all RTWI Windows DLLs)
```

> **Note:** `XCAM.exe.config` uses `<codeBase>` bindings to resolve all framework DLLs from these fixed local paths at runtime. This means `XCAM.exe` itself does not need to sit alongside the DLLs.

---

## 8. Assembly Versioning and Update Logic

The bootstrapper uses two different versioning strategies depending on file type:

| File | Strategy | Source of truth |
|---|---|---|
| `XCAM.exe` | `AssemblyName.Version` comparison (4-part: Major.Minor.Build.Revision) | `AssemblyName.GetAssemblyName()` |
| Framework / Windows DLLs | `FileVersionInfo.ProductPrivatePart` (4th part of file version = Revision) compared against `RevisionID` in DB | `FileVersionInfo.GetVersionInfo()` |
| `XCAM.exe.config` | Always overwritten | No version check |

**`PreferredFlag` in AssemblyMasters DB:**

| Value | Meaning |
|---|---|
| `1` | Active � copy to client if revision differs |
| `0` | Deprecated � delete from client if present |

This allows the RTW team to centrally retire old DLL versions by setting `PreferredFlag = 0` in the database.

---

## 9. Error Handling � BootstrapperFailed Form

If any file operation (copy, folder creation, version read) throws an exception, an `ALFileError` is added to the `_fileErrors` collection.

After all sync steps complete, if `_fileErrors.Count > 0`, the `BootstrapperFailed` dialog is shown displaying:

| Field | Content |
|---|---|
| Title bar | `Error Launching: <ApplicationName>` |
| Host label | `Host: <MasterWS.hostName>` (the web service host) |
| EXE grid | Server vs. client version comparison for `XCAM.exe` |
| Config grid | Server vs. client path for `XCAM.exe.config` |
| Exceptions grid | All `ALFileError` entries � file name + exception message |

**This is a read-only diagnostic dialog.** The user cannot retry from it; they must contact application support.

---

## 10. XCAM Startup After Launch

After `Process.Start` hands off to `XCAM.exe`, the bootstrapper exits. XCAM's own startup sequence (`Program.vb`) then:

1. **Reads the RTW host** from `HKLM\SOFTWARE\RTW\Host` (registry) � falls back to `XcamHost` in `App.config` if the key is absent
2. **Resolves `UserProfile`** from `RHH.Framework.Profiles` using the current Windows identity
3. **Checks application access** via `AccountingService` � redirects or blocks if unauthorized
4. **Launches `frmMain`** � the XCAM main window

XCAM does **not** re-download any DLLs. It relies entirely on what the bootstrapper placed in `C:\Program Files\RTWApps\` and the `<codeBase>` bindings in `XCAM.exe.config`.

---

## 11. XCAM App.config � Web Service Endpoints

`XCAM.exe.config` holds all runtime configuration. It is **always overwritten by the bootstrapper** on each launch, ensuring clients pick up endpoint changes without a re-install.

### Key Settings

| Key | Example Value | Purpose |
|---|---|---|
| `XcamHost` | *(blank � uses registry)* | Fallback host if registry key absent |
| `ServerEnvironment` | `Dev` | Current environment label |
| `LogfilePath` | `\\SADC1SLMTD1.CORP.STATEAUTO.COM\AppLogs` | UNC path for log files |
| `UseUtcDates` | `true` | Date handling |
| `AppTimeZone` | `UTC` | Application timezone |

### Web Service Endpoints (all pointing to `SADC1SLMTD1.CORP.STATEAUTO.COM`)

| Key | Service |
|---|---|
| `AbstractWS` | AbstractService.asmx |
| `CommonWS` | CommonService.asmx |
| `DiaryWS` | DiaryService.asmx |
| `ContactsWS` | ContactsService.asmx |
| `MasterClientProfileWS` | MasterClientProfileService.asmx |
| `PolicyWS` | PolicyService.asmx |
| `CancellationWS` | CancellationService.asmx |
| `PaymentWS` | PaymentService.asmx |
| `ClaimWS` | ClaimService.asmx |
| `ReservesWS` | ReservesService.asmx |
| `UserProfileWS` | UserProfileService.asmx |
| `BanksWS` | BanksService.asmx |
| `MasterTableWS` | MasterTableService.asmx |
| *(+ 20 more � see full `App.config`)* | |

### Assembly Binding Redirects (`<codeBase>`)

All RHH and RTWI framework assemblies are resolved from fixed local paths via `<codeBase>` entries, for example:

```xml
<dependentAssembly>
  <assemblyIdentity name="RHH.Framework.Common"
                    publicKeyToken="b0670cf1af0d2d21" culture="neutral"/>
  <codeBase version="2.0.0.0"
            href="file:///C:\Program Files\RTWApps\RHH\Framework\RHH.Framework.Common.dll"/>
</dependentAssembly>
```

> **Important:** These paths must exist and be populated by the bootstrapper before XCAM starts. If the bootstrapper did not run first, XCAM will throw assembly load exceptions on startup.

---

## 12. Framework DLL Dependency Map

```
XCAM.exe
 ??? XCAM.Core.dll
 ?    ??? RHH.Framework.Common.dll       (logging, utilities)
 ?
 ??? XCAM.Services.dll
 ?    ??? RHH.Framework.Profiles.dll     (user/client profiles)
 ?    ??? RHH.Framework.Contacts.dll
 ?    ??? RHH.Framework.Employers.dll
 ?    ??? RHH.Framework.FileDocuments.dll
 ?    ??? RHH.Framework.Messaging.Diary.dll
 ?    ??? RHH.Framework.Messaging.Tasks.dll
 ?    ??? RHH.Framework.Messaging.SystemNotifications.dll
 ?    ??? RTWI.Framework.Policies.dll
 ?    ??? RTWI.Framework.Accounting.Payables.dll
 ?
 ??? (resolved via codeBase at runtime)
      ??? RTWI.Framework.Claims.*.dll    (claims domain)
      ??? RTWI.Windows.*.dll             (claims UI)
      ??? RHH.Windows.Common.dll
```

---

## 13. Server-Side Prerequisites

The following must be in place on the **application server** before the bootstrapper can work:

| Requirement | Details |
|---|---|
| **MasterWS deployed** | `http://<host>/RTWI/RHH/MasterWS/MasterService.asmx` must be reachable |
| **AssemblyMasters DB records** | `XCAM.exe`, all RHH/RTWI DLLs must be registered in the `AssemblyMasters` table with correct `ServerPath`, `AssemblyPath`, `RevisionID`, and `PreferredFlag` |
| **Application record** | An `RTWApplicationList` row must exist with the correct `RTWApplicationListTrID` (e.g. `3032`), `ExeName=XCAM`, and `SetupPath` |
| **XCAM binaries on server share** | `XCAM.exe`, `XCAM.exe.config` must be on the `ServerPath` registered in DB |
| **Framework DLLs on server share** | All RHH/RTWI DLLs must be on their respective `ServerPath` values in the DB |
| **RTW Web Services running** | All `*WS` endpoints listed in `XCAM.exe.config` must be accessible from client machines |

---

## 14. Client-Side Prerequisites

| Requirement | Details |
|---|---|
| **.NET Framework 4.0+** | Required for `RTWBootstrapper.exe` |
| **.NET Framework 4.8** | Required for `XCAM.exe` |
| **Write access to `C:\Program Files\RTWApps\`** | Bootstrapper must be able to create folders and copy files |
| **Network access to MasterWS** | `http://SADC1SLMTD1.CORP.STATEAUTO.COM/RTWI/RHH/MasterWS/...` |
| **Network access to all `*WS` endpoints** | As listed in Section 10 |
| **`HKLM\SOFTWARE\RTW\Host`** | Registry key set to the RTW server hostname (e.g. `sadc1slmtt1.CORP.STATEAUTO.COM`) � written by the RTW platform installer |

---

## 15. Deployment Checklist

### New Environment Setup

- [ ] Deploy all RTW Web Services to IIS on the application server
- [ ] Register `RTWApplicationListTrID` record for XCAM in the master DB
- [ ] Register all assembly records in `AssemblyMasters` with correct paths and revision IDs
- [ ] Place `XCAM.exe` and `XCAM.exe.config` on the server share (`ServerPath`)
- [ ] Place all RHH/RTWI framework DLLs on server shares matching DB `ServerPath` values
- [ ] Update `XCAM.exe.config` endpoint URLs to point to the correct environment
- [ ] Set `HKLM\SOFTWARE\RTW\Host` on all client machines (via Group Policy or RTW platform installer)
- [ ] Distribute `RTWBootstrapper.exe` to client machines (shortcut / portal link)

### New XCAM Version Release

- [ ] Build XCAM in Release (`XCAM.UI\bin\Release\`)
- [ ] Copy `XCAM.exe` to the server share (`ServerPath` in DB)
- [ ] Copy updated `XCAM.exe.config` to the server share
- [ ] Increment `RevisionID` in the `AssemblyMasters` DB record for `XCAM.exe`
- [ ] Test by running `RTWBootstrapper.exe 3032` � confirm it detects the version mismatch and copies the new EXE
- [ ] Verify XCAM launches correctly after bootstrapper sync

### New Framework DLL Release

- [ ] Copy updated DLL to server share
- [ ] Increment `RevisionID` for that DLL in `AssemblyMasters`
- [ ] Test with bootstrapper � confirm `Copying:` status appears for that DLL

### Retiring a Framework DLL

- [ ] Set `PreferredFlag = 0` in `AssemblyMasters` for the obsolete DLL
- [ ] Bootstrapper will automatically delete it from client machines on next run

---

## 16. Troubleshooting Guide

### Bootstrapper shows "Invalid command line arguments"

**Cause:** `RTWBootstrapper.exe` was launched without a valid integer argument, or launched by double-clicking.  
**Fix:** Ensure the shortcut or portal link includes the `RTWApplicationListTrID` argument, e.g. `RTWBootstrapper.exe 3032`.

---

### BootstrapperFailed dialog appears

**Cause:** One or more file operations failed during sync.  
**Steps:**
1. Note the **Host** shown � confirm MasterWS is reachable at that host
2. Check the **Exceptions grid** � the file name and exception message identify the failing operation
3. Common causes:
   - Server share path in DB is wrong or inaccessible
   - Client has no write access to `C:\Program Files\RTWApps\`
   - Network share is offline
   - DLL is locked by a running process

---

### XCAM crashes immediately on startup with assembly load error

**Cause:** The bootstrapper did not run, or a `<codeBase>` path does not exist.  
**Steps:**
1. Check `C:\Program Files\RTWApps\RHH\Framework\` and `C:\Program Files\RTWApps\RTWI\Framework\` � folders and DLLs must exist
2. Run `RTWBootstrapper.exe 3032` to re-sync all files
3. If the path in the error message differs from `C:\Program Files\RTWApps\`, compare against `<codeBase>` entries in `XCAM.exe.config`

---

### XCAM shows "Access Denied" or blank screen on startup

**Cause:** `HKLM\SOFTWARE\RTW\Host` is missing or incorrect, or the user has no profile in the RTW system.  
**Steps:**
1. Verify registry: `HKLM\SOFTWARE\RTW` ? `Host` value = correct server hostname
2. Verify the user exists in `UserProfile` in the RTW database
3. Check `\\SADC1SLMTD1.CORP.STATEAUTO.COM\AppLogs` for exception log files written by `RHH.Framework.Common.Logger`

---

### XCAM is running an old version after a release

**Cause:** `RevisionID` in `AssemblyMasters` was not incremented after copying the new EXE to the server.  
**Fix:** Update `RevisionID` in the DB for `XCAM.exe` � the bootstrapper will detect the mismatch on next launch and copy the new version.

---

### Config endpoint is pointing to wrong environment

**Cause:** `XCAM.exe.config` on the server share has the wrong `ServerEnvironment` or `*WS` URLs.  
**Fix:** Update the server-side `XCAM.exe.config`. The bootstrapper always overwrites the client copy � no client-side change is needed.

---

*End of Runbook*
